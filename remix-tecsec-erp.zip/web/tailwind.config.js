/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        cobalt: {
          DEFAULT: '#0052CC',
          dark: '#003D99',
          light: '#D9E6FF',
          ink: '#001A4D'
        },
        cyanTech: {
          DEFAULT: '#0284C7',
          light: '#E0F2FE',
          ink: '#082F49'
        },
        bench: {
          bg: '#F3F6FB',
          surface: '#FFFFFF',
          surfaceAlt: '#E6ECF5',
          dark: '#040E18',
          navy: '#0F172A',
          ink: '#0F172A',
          muted: '#475569',
          outline: '#CBD5E1'
        }
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace']
      }
    }
  },
  plugins: []
};
