const ENV_URL = (import.meta.env.VITE_SUPABASE_URL as string | undefined) || '';
const ENV_KEY = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) || '';

const LS_CUSTOM_URL = 'rterp_supabase_url';
const LS_CUSTOM_KEY = 'rterp_supabase_anon_key';

export const DEFAULT_SUPABASE_HEADERS: Record<string, string> = {
  Accept: 'application/json',
  Prefer: 'return=representation'
};

export function getSupabaseConfig(): { url: string; anonKey: string; isConfigured: boolean; source: 'env' | 'localStorage' | 'none' } {
  const cleanEnvUrl = ENV_URL.trim().replace(/\/+$/, '');
  const cleanEnvKey = ENV_KEY.trim();

  const envValid =
    cleanEnvUrl.startsWith('http') &&
    !cleanEnvUrl.includes('seu-projeto.supabase.co') &&
    cleanEnvKey.length > 12 &&
    !cleanEnvKey.includes('SUA_CHAVE_ANON_SUPABASE');

  if (envValid) {
    return { url: cleanEnvUrl, anonKey: cleanEnvKey, isConfigured: true, source: 'env' };
  }

  if (typeof window !== 'undefined') {
    const lsUrl = (localStorage.getItem(LS_CUSTOM_URL) || '').trim().replace(/\/+$/, '');
    const lsKey = (localStorage.getItem(LS_CUSTOM_KEY) || '').trim();
    if (lsUrl.startsWith('http') && lsKey.length > 12) {
      return { url: lsUrl, anonKey: lsKey, isConfigured: true, source: 'localStorage' };
    }
  }

  return { url: cleanEnvUrl, anonKey: cleanEnvKey, isConfigured: false, source: 'none' };
}

export function saveRuntimeSupabaseConfig(url: string, anonKey: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(LS_CUSTOM_URL, url.trim().replace(/\/+$/, ''));
  localStorage.setItem(LS_CUSTOM_KEY, anonKey.trim());
}

export function clearRuntimeSupabaseConfig(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(LS_CUSTOM_URL);
  localStorage.removeItem(LS_CUSTOM_KEY);
}

export interface SupabaseErrorPayload {
  message?: string;
  error?: string;
  error_description?: string;
  msg?: string;
  details?: string;
  hint?: string;
}

export function translateSupabaseMessage(msg: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes('limite máximo de 4')) {
    return 'Limite máximo de 4 acessos de funcionários por oficina atingido.';
  }
  if (lower.includes('invalid login credentials')) {
    return 'E-mail ou senha inválidos.';
  }
  if (lower.includes('email not confirmed')) {
    return 'Confirme seu e-mail antes de fazer login.';
  }
  if (lower.includes('user already registered')) {
    return 'Este e-mail já está cadastrado.';
  }
  if (lower.includes('password should be at least')) {
    return 'A senha deve ter pelo menos 6 caracteres.';
  }
  if (lower.includes('relation') && lower.includes('does not exist')) {
    return 'Tabelas não encontradas no Supabase. Execute o arquivo supabase_schema.sql atualizado no SQL Editor.';
  }
  if (lower.includes('registrar_venda_completa') || lower.includes('cancelar_venda_completa')) {
    return 'Função de Vendas não encontrada no Supabase. Execute o arquivo supabase_schema.sql atualizado no SQL Editor.';
  }
  if (lower.includes('bucket not found')) {
    return "Bucket 'tecsec-midias' não encontrado no Supabase Storage. Execute o supabase_schema.sql atualizado.";
  }
  return msg;
}

export class SupabaseHttpError extends Error {
  status: number;
  unauthorized: boolean;

  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.unauthorized = status === 401;
  }
}

const RETRYABLE_HTTP_STATUS = new Set([429, 502, 503, 504]);

function waitWithJitter(attempt: number): Promise<void> {
  const baseMs = 260 * Math.pow(2, attempt);
  const jitterMs = Math.floor(Math.random() * 180);
  return new Promise((resolve) => window.setTimeout(resolve, baseMs + jitterMs));
}

export async function supabaseFetch<T>(
  path: string,
  options: {
    method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
    bearerToken?: string;
    body?: unknown;
    extraHeaders?: Record<string, string>;
    isRest?: boolean;
  } = {}
): Promise<T> {
  const cfg = getSupabaseConfig();
  if (!cfg.isConfigured) {
    throw new SupabaseHttpError(
      'Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no arquivo .env ou na configuração do login.',
      0
    );
  }

  const headers: Record<string, string> = {
    apikey: cfg.anonKey,
    Accept: 'application/json',
    ...((options.isRest ?? path.startsWith('/rest/v1/'))
      ? { Prefer: 'return=representation' }
      : {}),
    ...options.extraHeaders
  };

  if (options.bearerToken) {
    headers.Authorization = `Bearer ${options.bearerToken}`;
  }

  let payloadBody: BodyInit | undefined;
  if (options.body !== undefined) {
    if (options.body instanceof Blob || options.body instanceof FormData) {
      payloadBody = options.body;
    } else {
      headers['Content-Type'] = 'application/json';
      payloadBody = JSON.stringify(options.body);
    }
  }

  const maxAttempts = 3;
  let lastNetworkError: unknown = null;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    let response: Response;
    try {
      response = await fetch(`${cfg.url}${path}`, {
        method: options.method ?? 'GET',
        headers,
        body: payloadBody
      });
    } catch (err) {
      lastNetworkError = err;
      if (attempt < maxAttempts - 1) {
        await waitWithJitter(attempt);
        continue;
      }
      throw new SupabaseHttpError(
        err instanceof Error ? err.message : 'Falha de rede ao conectar ao Supabase.',
        0
      );
    }

    if (RETRYABLE_HTTP_STATUS.has(response.status) && attempt < maxAttempts - 1) {
      await waitWithJitter(attempt);
      continue;
    }

    const text = await response.text();

    if (!response.ok) {
      let parsedMsg = '';
      if (text) {
        try {
          const err = JSON.parse(text) as SupabaseErrorPayload;
          parsedMsg = err.error_description || err.message || err.msg || err.error || '';
        } catch {
          parsedMsg = text;
        }
      }
      const finalMsg = parsedMsg
        ? translateSupabaseMessage(parsedMsg)
        : `Erro ao comunicar com o banco Supabase (HTTP ${response.status}).`;
      throw new SupabaseHttpError(finalMsg, response.status);
    }

    if (!text) {
      return undefined as T;
    }
    try {
      return JSON.parse(text) as T;
    } catch {
      return undefined as T;
    }
  }

  throw new SupabaseHttpError(
    lastNetworkError instanceof Error
      ? lastNetworkError.message
      : 'Não foi possível concluir a requisição ao Supabase.',
    0
  );
}
