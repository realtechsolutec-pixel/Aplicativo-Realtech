import {
  ClienteDto,
  ConfiguracaoOficinaDto,
  CotacaoPrecoDto,
  FuncionarioDto,
  MetaDiariaDto,
  OrdemServicoDto,
  PecaEstoqueDto,
  PedidoPecaDto,
  RegistrarVendaInput,
  TransacaoFinanceiraDto,
  UserRole,
  UserSession,
  VendaDto
} from '../types/models';
import { nowIsoTimestamp, todayIsoDate } from '../utils/formatters';
import {
  CompressionPresetCode,
  compressImageFileToWebP
} from '../utils/imageCompressor';
import { getSupabaseConfig, supabaseFetch, SupabaseHttpError } from './supabaseClient';

const LS_SESSION_KEY = 'rterp_web_session';
const LS_PRESET_KEY = 'rterp_compression_preset';

interface SupabaseUser {
  id: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
}

interface SupabaseAuthResponse {
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
  token_type?: string;
  user?: SupabaseUser;
}

export interface UploadedMediaResult {
  publicUrl: string;
  originalBytes: number;
  compressedBytes: number;
}

export function loadStoredSession(): UserSession | null {
  try {
    const raw = localStorage.getItem(LS_SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as UserSession;
    if (!parsed?.accessToken || !parsed?.userId) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveStoredSession(session: UserSession | null): void {
  if (!session) {
    localStorage.removeItem(LS_SESSION_KEY);
  } else {
    localStorage.setItem(LS_SESSION_KEY, JSON.stringify(session));
  }
}

export function loadStoredPreset(): CompressionPresetCode {
  const val = localStorage.getItem(LS_PRESET_KEY);
  if (val === 'ECONOMIA_MAXIMA' || val === 'EQUILIBRADO' || val === 'ALTA_NITIDEZ') {
    return val;
  }
  return 'EQUILIBRADO';
}

export function saveStoredPreset(preset: CompressionPresetCode): void {
  localStorage.setItem(LS_PRESET_KEY, preset);
}

export async function getValidSession(): Promise<UserSession | null> {
  const current = loadStoredSession();
  if (!current) return null;
  const nowSec = Math.floor(Date.now() / 1000);
  if (nowSec < current.expiresAtEpochSec - 60) {
    return current;
  }
  try {
    const res = await supabaseFetch<SupabaseAuthResponse>(
      '/auth/v1/token?grant_type=refresh_token',
      {
        method: 'POST',
        isRest: false,
        body: { refresh_token: current.refreshToken }
      }
    );
    if (res?.access_token && res?.refresh_token && res?.user) {
      const updated: UserSession = {
        ...current,
        accessToken: res.access_token,
        refreshToken: res.refresh_token,
        expiresAtEpochSec: nowSec + (res.expires_in ?? 3600)
      };
      saveStoredSession(updated);
      return updated;
    }
    return current;
  } catch (err) {
    if (err instanceof SupabaseHttpError && (err.status === 400 || err.status === 401)) {
      saveStoredSession(null);
      return null;
    }
    return current;
  }
}

async function requireSession(): Promise<UserSession> {
  const session = await getValidSession();
  if (!session) {
    throw new SupabaseHttpError('Sessão expirada. Faça login novamente.', 401);
  }
  return session;
}

export async function signInWithEmail(
  email: string,
  password: string,
  requestedRole: UserRole
): Promise<UserSession> {
  const cleanEmail = email.trim();
  const res = await supabaseFetch<SupabaseAuthResponse>('/auth/v1/token?grant_type=password', {
    method: 'POST',
    isRest: false,
    body: { email: cleanEmail, password }
  });

  if (!res?.access_token || !res?.refresh_token || !res?.user) {
    throw new Error('Resposta de autenticação incompleta do Supabase.');
  }

  const token = res.access_token;
  const user = res.user;
  const userEmail = (user.email || cleanEmail).toLowerCase();
  const metaName =
    (typeof user.user_metadata?.full_name === 'string' && user.user_metadata.full_name) ||
    cleanEmail.split('@')[0];
  const metaRole =
    typeof user.user_metadata?.role === 'string' ? user.user_metadata.role : undefined;
  const metaOwnerId =
    typeof user.user_metadata?.owner_id === 'string' && user.user_metadata.owner_id.trim()
      ? user.user_metadata.owner_id.trim()
      : undefined;

  let funcRecord: FuncionarioDto | undefined;
  try {
    const funcs = await supabaseFetch<FuncionarioDto[]>(
      `/rest/v1/funcionarios?email=eq.${encodeURIComponent(userEmail)}&select=*`,
      { bearerToken: token }
    );
    funcRecord = funcs?.[0];
  } catch {
    funcRecord = undefined;
  }

  if (funcRecord && !funcRecord.ativo) {
    throw new Error('Seu acesso de funcionário foi desativado pelo proprietário da oficina.');
  }

  if (funcRecord?.id && !funcRecord.funcionario_user_id) {
    try {
      await supabaseFetch<FuncionarioDto[]>(
        `/rest/v1/funcionarios?id=eq.${encodeURIComponent(funcRecord.id)}`,
        {
          method: 'PATCH',
          bearerToken: token,
          body: { funcionario_user_id: user.id }
        }
      );
    } catch {
      // ignore non-fatal claim error
    }
  }

  let resolvedRole: UserRole;
  let resolvedOwnerId: string;

  if (funcRecord) {
    resolvedRole = 'FUNCIONARIO';
    resolvedOwnerId = funcRecord.owner_id?.trim() || metaOwnerId || user.id;
  } else if (metaRole?.toUpperCase() === 'FUNCIONARIO') {
    resolvedRole = 'FUNCIONARIO';
    resolvedOwnerId = metaOwnerId || user.id;
  } else if (requestedRole === 'FUNCIONARIO') {
    resolvedRole = 'FUNCIONARIO';
    resolvedOwnerId = user.id;
  } else {
    resolvedRole = 'ADMIN';
    resolvedOwnerId = user.id;
  }

  const nowSec = Math.floor(Date.now() / 1000);
  const session: UserSession = {
    accessToken: token,
    refreshToken: res.refresh_token,
    userId: user.id,
    email: user.email || cleanEmail,
    fullName: funcRecord?.nome?.trim() || metaName,
    expiresAtEpochSec: nowSec + (res.expires_in ?? 3600),
    role: resolvedRole,
    workshopOwnerId: resolvedOwnerId
  };
  saveStoredSession(session);
  return session;
}

export async function signUpOwner(
  fullName: string,
  email: string,
  password: string
): Promise<'AUTHENTICATED' | 'CONFIRM_EMAIL'> {
  const cleanEmail = email.trim();
  const res = await supabaseFetch<SupabaseAuthResponse>('/auth/v1/signup', {
    method: 'POST',
    isRest: false,
    body: {
      email: cleanEmail,
      password,
      data: {
        full_name: fullName.trim(),
        role: 'ADMIN'
      }
    }
  });

  if (res?.access_token && res?.refresh_token && res?.user) {
    const nowSec = Math.floor(Date.now() / 1000);
    saveStoredSession({
      accessToken: res.access_token,
      refreshToken: res.refresh_token,
      userId: res.user.id,
      email: res.user.email || cleanEmail,
      fullName: fullName.trim() || cleanEmail.split('@')[0],
      expiresAtEpochSec: nowSec + (res.expires_in ?? 3600),
      role: 'ADMIN',
      workshopOwnerId: res.user.id
    });
    return 'AUTHENTICATED';
  }
  return 'CONFIRM_EMAIL';
}

export async function signUpEmployee(
  fullName: string,
  email: string,
  password: string,
  workshopCode: string
): Promise<'AUTHENTICATED' | 'CONFIRM_EMAIL'> {
  const ownerId = workshopCode.trim();
  const cleanEmail = email.trim().toLowerCase();

  const res = await supabaseFetch<SupabaseAuthResponse>('/auth/v1/signup', {
    method: 'POST',
    isRest: false,
    body: {
      email: cleanEmail,
      password,
      data: {
        full_name: fullName.trim(),
        role: 'FUNCIONARIO',
        owner_id: ownerId
      }
    }
  });

  if (res?.access_token && res?.refresh_token && res?.user) {
    const token = res.access_token;
    const user = res.user;
    try {
      const existing = await supabaseFetch<FuncionarioDto[]>(
        `/rest/v1/funcionarios?email=eq.${encodeURIComponent(cleanEmail)}&select=*`,
        { bearerToken: token }
      );
      const row = existing?.[0];
      if (row?.id) {
        await supabaseFetch<FuncionarioDto[]>(
          `/rest/v1/funcionarios?id=eq.${encodeURIComponent(row.id)}`,
          {
            method: 'PATCH',
            bearerToken: token,
            body: { funcionario_user_id: user.id }
          }
        );
      } else {
        await supabaseFetch<FuncionarioDto[]>('/rest/v1/funcionarios', {
          method: 'POST',
          bearerToken: token,
          body: {
            owner_id: ownerId,
            funcionario_user_id: user.id,
            nome: fullName.trim(),
            email: cleanEmail,
            cargo: 'Técnico Operacional',
            comissao_percentual: 50,
            ativo: true
          }
        });
      }
    } catch {
      // ignore if trigger/policy handles later
    }

    const nowSec = Math.floor(Date.now() / 1000);
    saveStoredSession({
      accessToken: token,
      refreshToken: res.refresh_token,
      userId: user.id,
      email: user.email || cleanEmail,
      fullName: fullName.trim() || cleanEmail.split('@')[0],
      expiresAtEpochSec: nowSec + (res.expires_in ?? 3600),
      role: 'FUNCIONARIO',
      workshopOwnerId: ownerId
    });
    return 'AUTHENTICATED';
  }
  return 'CONFIRM_EMAIL';
}

export async function signOutSession(): Promise<void> {
  const current = loadStoredSession();
  if (current) {
    try {
      await supabaseFetch('/auth/v1/logout', {
        method: 'POST',
        isRest: false,
        bearerToken: current.accessToken
      });
    } catch {
      // ignore logout network errors
    }
  }
  saveStoredSession(null);
}

// ============================================================================
// STORAGE (Upload WebP compactado para bucket tecsec-midias)
// ============================================================================

export async function uploadImageToSupabase(
  file: File,
  folder: 'os' | 'pecas',
  preset: CompressionPresetCode
): Promise<UploadedMediaResult> {
  const session = await requireSession();
  const cfg = getSupabaseConfig();
  const compressed = await compressImageFileToWebP(file, preset);
  const fileId =
    typeof crypto !== 'undefined' && crypto.randomUUID
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  const objectPath = `${session.workshopOwnerId}/${folder}/${fileId}.${compressed.extension}`;

  await supabaseFetch<unknown>(`/storage/v1/object/tecsec-midias/${objectPath}`, {
    method: 'POST',
    isRest: false,
    bearerToken: session.accessToken,
    extraHeaders: {
      'x-upsert': 'true',
      'Content-Type': compressed.mimeType
    },
    body: compressed.blob
  });

  return {
    publicUrl: `${cfg.url}/storage/v1/object/public/tecsec-midias/${objectPath}`,
    originalBytes: compressed.originalBytes,
    compressedBytes: compressed.compressedBytes
  };
}

// ============================================================================
// CLIENTES
// ============================================================================

export async function fetchClientes(): Promise<ClienteDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<ClienteDto[]>('/rest/v1/clientes?select=*&order=nome.asc', {
      bearerToken: session.accessToken
    })) ?? []
  );
}

export async function saveCliente(cliente: ClienteDto): Promise<ClienteDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    nome: cliente.nome,
    tipo: cliente.tipo,
    documento: cliente.documento,
    telefone: cliente.telefone,
    email: cliente.email,
    endereco: cliente.endereco,
    observacoes: cliente.observacoes
  };
  const rows = cliente.id
    ? await supabaseFetch<ClienteDto[]>(
        `/rest/v1/clientes?id=eq.${encodeURIComponent(cliente.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<ClienteDto[]>('/rest/v1/clientes', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Cliente salvo sem retorno do servidor.');
  return rows[0];
}

export async function deleteCliente(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/clientes?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// ESTOQUE DE PEÇAS
// ============================================================================

export async function fetchPecas(): Promise<PecaEstoqueDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<PecaEstoqueDto[]>('/rest/v1/pecas_estoque?select=*&order=nome.asc', {
      bearerToken: session.accessToken
    })) ?? []
  );
}

export async function savePeca(peca: PecaEstoqueDto): Promise<PecaEstoqueDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    codigo_sku: peca.codigo_sku,
    nome: peca.nome,
    categoria: peca.categoria,
    fornecedor: peca.fornecedor,
    localizacao: peca.localizacao,
    quantidade: peca.quantidade,
    estoque_minimo: peca.estoque_minimo,
    preco_custo: peca.preco_custo,
    preco_venda: peca.preco_venda,
    foto_url: peca.foto_url,
    descricao_detalhada: peca.descricao_detalhada
  };
  const rows = peca.id
    ? await supabaseFetch<PecaEstoqueDto[]>(
        `/rest/v1/pecas_estoque?id=eq.${encodeURIComponent(peca.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<PecaEstoqueDto[]>('/rest/v1/pecas_estoque', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Peça salva sem retorno do servidor.');
  return rows[0];
}

export async function deletePeca(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/pecas_estoque?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// ORDENS DE SERVIÇO
// ============================================================================

export async function fetchOrdensServico(): Promise<OrdemServicoDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<OrdemServicoDto[]>(
      '/rest/v1/ordens_servico?select=*&order=numero_os.desc',
      { bearerToken: session.accessToken }
    )) ?? []
  );
}

export async function saveOrdemServico(os: OrdemServicoDto): Promise<OrdemServicoDto> {
  const session = await requireSession();
  const computedTotal = Math.max(0, (os.valor_mao_obra || 0) + (os.valor_pecas || 0) - (os.desconto || 0));
  const exitDate =
    os.status === 'ENTREGUE' && !os.data_saida ? nowIsoTimestamp() : os.data_saida ?? null;

  const payload = {
    user_id: session.workshopOwnerId,
    numero_os: os.numero_os,
    cliente_id: os.cliente_id ?? null,
    cliente_nome: os.cliente_nome,
    cliente_telefone: os.cliente_telefone,
    tecnico_id: os.tecnico_id ?? null,
    tecnico_nome: os.tecnico_nome,
    tecnico_email: os.tecnico_email,
    criado_por_nome: os.criado_por_nome,
    comissao_percentual: Math.min(100, Math.max(0, os.comissao_percentual || 0)),
    categoria_equipamento: os.categoria_equipamento,
    equipamento: os.equipamento,
    marca_modelo: os.marca_modelo,
    numero_serie: os.numero_serie,
    acessorios_entregues: os.acessorios_entregues,
    defeito_relatado: os.defeito_relatado,
    diagnostico_tecnico: os.diagnostico_tecnico,
    pecas_utilizadas: os.pecas_utilizadas,
    fotos_urls: os.fotos_urls ?? [],
    status: os.status,
    prioridade: os.prioridade,
    valor_mao_obra: os.valor_mao_obra,
    valor_pecas: os.valor_pecas,
    desconto: os.desconto,
    valor_total: computedTotal,
    garantia_dias: os.garantia_dias,
    data_entrada: os.data_entrada || nowIsoTimestamp(),
    data_saida: exitDate
  };

  const rows = os.id
    ? await supabaseFetch<OrdemServicoDto[]>(
        `/rest/v1/ordens_servico?id=eq.${encodeURIComponent(os.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<OrdemServicoDto[]>('/rest/v1/ordens_servico', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('OS salva sem retorno do servidor.');
  return rows[0];
}

export async function deleteOrdemServico(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/ordens_servico?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// FINANCEIRO (Somente Admin)
// ============================================================================

export async function fetchTransacoes(): Promise<TransacaoFinanceiraDto[]> {
  const session = await requireSession();
  if (session.role !== 'ADMIN') {
    throw new Error('Acesso financeiro restrito ao proprietário.');
  }
  return (
    (await supabaseFetch<TransacaoFinanceiraDto[]>(
      '/rest/v1/transacoes_financeiras?select=*&order=data_vencimento.desc,created_at.desc',
      { bearerToken: session.accessToken }
    )) ?? []
  );
}

export async function saveTransacao(
  tx: TransacaoFinanceiraDto
): Promise<TransacaoFinanceiraDto> {
  const session = await requireSession();
  if (session.role !== 'ADMIN') {
    throw new Error('Acesso financeiro restrito ao proprietário.');
  }

  let dataPagamento: string | null = tx.data_pagamento ?? null;
  if (tx.status === 'PAGO' && !dataPagamento) {
    dataPagamento = todayIsoDate();
  } else if (tx.status === 'PENDENTE') {
    dataPagamento = null;
  }

  const payload = {
    user_id: session.workshopOwnerId,
    os_id: tx.os_id ?? null,
    descricao: tx.descricao,
    categoria: tx.categoria,
    tipo: tx.tipo,
    escopo: tx.escopo,
    status: tx.status,
    valor: tx.valor,
    forma_pagamento: tx.forma_pagamento,
    data_vencimento: tx.data_vencimento || todayIsoDate(),
    data_pagamento: dataPagamento,
    is_conta_fixa: Boolean(tx.is_conta_fixa),
    observacoes: tx.observacoes
  };

  const rows = tx.id
    ? await supabaseFetch<TransacaoFinanceiraDto[]>(
        `/rest/v1/transacoes_financeiras?id=eq.${encodeURIComponent(tx.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<TransacaoFinanceiraDto[]>('/rest/v1/transacoes_financeiras', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Lançamento salvo sem retorno do servidor.');
  return rows[0];
}

export async function deleteTransacao(id: string): Promise<void> {
  const session = await requireSession();
  if (session.role !== 'ADMIN') {
    throw new Error('Acesso financeiro restrito ao proprietário.');
  }
  await supabaseFetch(`/rest/v1/transacoes_financeiras?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// CONFIGURAÇÕES DA OFICINA
// ============================================================================

export async function fetchConfiguracaoOficina(): Promise<ConfiguracaoOficinaDto | null> {
  const session = await requireSession();
  const rows = await supabaseFetch<ConfiguracaoOficinaDto[]>(
    '/rest/v1/configuracoes_oficina?select=*',
    { bearerToken: session.accessToken }
  );
  return rows?.[0] ?? null;
}

export async function saveConfiguracaoOficina(
  config: ConfiguracaoOficinaDto
): Promise<ConfiguracaoOficinaDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    nome_loja: config.nome_loja,
    cnpj: config.cnpj,
    telefone: config.telefone,
    email: config.email,
    endereco: config.endereco,
    rodape_os: config.rodape_os,
    garantia_padrao_dias: config.garantia_padrao_dias
  };
  const rows = config.id
    ? await supabaseFetch<ConfiguracaoOficinaDto[]>(
        `/rest/v1/configuracoes_oficina?id=eq.${encodeURIComponent(config.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<ConfiguracaoOficinaDto[]>('/rest/v1/configuracoes_oficina', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Configuração salva sem retorno.');
  return rows[0];
}

// ============================================================================
// FUNCIONÁRIOS (Máximo 4 acessos)
// ============================================================================

export async function fetchFuncionarios(): Promise<FuncionarioDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<FuncionarioDto[]>('/rest/v1/funcionarios?select=*&order=nome.asc', {
      bearerToken: session.accessToken
    })) ?? []
  );
}

export async function createFuncionarioAccount(params: {
  nome: string;
  email: string;
  password: string;
  cargo: string;
  comissaoPercentual: number;
}): Promise<FuncionarioDto> {
  const session = await requireSession();
  if (session.role !== 'ADMIN') {
    throw new Error('Apenas o proprietário pode gerenciar funcionários.');
  }

  const currentList = await fetchFuncionarios();
  if (currentList.length >= 4) {
    throw new Error('Limite máximo de 4 acessos de funcionários por oficina atingido.');
  }

  const cleanEmail = params.email.trim().toLowerCase();
  const cleanNome = params.nome.trim();
  const cleanCargo = params.cargo.trim() || 'Técnico Operacional';
  const cleanComissao = Math.min(100, Math.max(0, params.comissaoPercentual));

  let createdUserId: string | null = null;
  if (params.password.length >= 6) {
    try {
      const signUpRes = await supabaseFetch<SupabaseAuthResponse>('/auth/v1/signup', {
        method: 'POST',
        isRest: false,
        body: {
          email: cleanEmail,
          password: params.password,
          data: {
            full_name: cleanNome,
            role: 'FUNCIONARIO',
            owner_id: session.workshopOwnerId
          }
        }
      });
      createdUserId = signUpRes?.user?.id ?? null;
    } catch {
      // Allow creating DB row even if email already exists in Auth
    }
  }

  const rows = await supabaseFetch<FuncionarioDto[]>('/rest/v1/funcionarios', {
    method: 'POST',
    bearerToken: session.accessToken,
    body: {
      owner_id: session.workshopOwnerId,
      funcionario_user_id: createdUserId,
      nome: cleanNome,
      email: cleanEmail,
      cargo: cleanCargo,
      comissao_percentual: cleanComissao,
      ativo: true
    }
  });
  if (!rows?.[0]) throw new Error('Funcionário salvo sem retorno do servidor.');
  return rows[0];
}

export async function updateFuncionarioPerfil(
  func: FuncionarioDto,
  cargo: string,
  comissaoPercentual: number
): Promise<FuncionarioDto> {
  const session = await requireSession();
  if (session.role !== 'ADMIN') {
    throw new Error('Apenas o proprietário pode alterar função e comissão.');
  }
  if (!func.id) throw new Error('ID de funcionário inválido.');
  const rows = await supabaseFetch<FuncionarioDto[]>(
    `/rest/v1/funcionarios?id=eq.${encodeURIComponent(func.id)}`,
    {
      method: 'PATCH',
      bearerToken: session.accessToken,
      body: {
        cargo: cargo.trim() || func.cargo || 'Técnico Operacional',
        comissao_percentual: Math.min(100, Math.max(0, comissaoPercentual))
      }
    }
  );
  if (!rows?.[0]) throw new Error('Não foi possível atualizar função e comissão.');
  return rows[0];
}

export async function toggleFuncionarioAtivo(func: FuncionarioDto): Promise<FuncionarioDto> {
  const session = await requireSession();
  if (!func.id) throw new Error('ID de funcionário inválido.');
  const rows = await supabaseFetch<FuncionarioDto[]>(
    `/rest/v1/funcionarios?id=eq.${encodeURIComponent(func.id)}`,
    {
      method: 'PATCH',
      bearerToken: session.accessToken,
      body: { ativo: !func.ativo }
    }
  );
  if (!rows?.[0]) throw new Error('Não foi possível atualizar status do funcionário.');
  return rows[0];
}

export async function deleteFuncionario(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/funcionarios?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// METAS DIÁRIAS (Somente Admin)
// ============================================================================

export async function fetchMetaDiaria(): Promise<MetaDiariaDto | null> {
  const session = await requireSession();
  const rows = await supabaseFetch<MetaDiariaDto[]>('/rest/v1/metas_oficina?select=*', {
    bearerToken: session.accessToken
  });
  return rows?.[0] ?? null;
}

export async function saveMetaDiaria(meta: MetaDiariaDto): Promise<MetaDiariaDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    meta_mensal: meta.meta_mensal,
    custos_fixos_mensais: meta.custos_fixos_mensais,
    dias_uteis_mes: meta.dias_uteis_mes,
    dias_uteis_restantes: meta.dias_uteis_restantes,
    ticket_medio_estimado: meta.ticket_medio_estimado
  };
  const rows = meta.id
    ? await supabaseFetch<MetaDiariaDto[]>(
        `/rest/v1/metas_oficina?id=eq.${encodeURIComponent(meta.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<MetaDiariaDto[]>('/rest/v1/metas_oficina', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Meta salva sem retorno.');
  return rows[0];
}

// ============================================================================
// COTAÇÕES E COMPARATIVO DE PREÇOS
// ============================================================================

export async function fetchCotacoes(): Promise<CotacaoPrecoDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<CotacaoPrecoDto[]>(
      '/rest/v1/cotacoes_precos?select=*&order=produto_nome.asc,preco_unitario.asc',
      { bearerToken: session.accessToken }
    )) ?? []
  );
}

export async function saveCotacao(cotacao: CotacaoPrecoDto): Promise<CotacaoPrecoDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    produto_nome: cotacao.produto_nome,
    codigo_sku: cotacao.codigo_sku,
    fornecedor: cotacao.fornecedor,
    preco_unitario: cotacao.preco_unitario,
    frete: cotacao.frete,
    prazo_entrega_dias: cotacao.prazo_entrega_dias,
    observacoes: cotacao.observacoes
  };
  const rows = cotacao.id
    ? await supabaseFetch<CotacaoPrecoDto[]>(
        `/rest/v1/cotacoes_precos?id=eq.${encodeURIComponent(cotacao.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<CotacaoPrecoDto[]>('/rest/v1/cotacoes_precos', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Cotação salva sem retorno.');
  return rows[0];
}

export async function deleteCotacao(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/cotacoes_precos?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// PEDIDOS DE PEÇAS FALTANTES / PARA CONCLUIR OS
// ============================================================================

export async function fetchPedidosPecas(): Promise<PedidoPecaDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<PedidoPecaDto[]>(
      '/rest/v1/pedidos_pecas?select=*&order=created_at.desc',
      { bearerToken: session.accessToken }
    )) ?? []
  );
}

export async function savePedidoPeca(pedido: PedidoPecaDto): Promise<PedidoPecaDto> {
  const session = await requireSession();
  const payload = {
    user_id: session.workshopOwnerId,
    peca_id: pedido.peca_id ?? null,
    os_id: pedido.os_id ?? null,
    numero_os: pedido.numero_os ?? null,
    nome_peca: pedido.nome_peca,
    codigo_sku: pedido.codigo_sku,
    quantidade: Math.max(1, pedido.quantidade || 1),
    motivo: pedido.motivo,
    status: pedido.status,
    prioridade: pedido.prioridade,
    solicitado_por: pedido.solicitado_por?.trim() || session.fullName,
    fornecedor_sugerido: pedido.fornecedor_sugerido,
    observacoes: pedido.observacoes
  };
  const rows = pedido.id
    ? await supabaseFetch<PedidoPecaDto[]>(
        `/rest/v1/pedidos_pecas?id=eq.${encodeURIComponent(pedido.id)}`,
        { method: 'PATCH', bearerToken: session.accessToken, body: payload }
      )
    : await supabaseFetch<PedidoPecaDto[]>('/rest/v1/pedidos_pecas', {
        method: 'POST',
        bearerToken: session.accessToken,
        body: payload
      });
  if (!rows?.[0]) throw new Error('Pedido de peça salvo sem retorno.');
  return rows[0];
}

export async function deletePedidoPeca(id: string): Promise<void> {
  const session = await requireSession();
  await supabaseFetch(`/rest/v1/pedidos_pecas?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE',
    bearerToken: session.accessToken
  });
}

// ============================================================================
// VENDAS / PDV INTEGRADO (RPC Atômico com Baixa de Estoque + Financeiro)
// ============================================================================

export async function fetchVendas(): Promise<VendaDto[]> {
  const session = await requireSession();
  return (
    (await supabaseFetch<VendaDto[]>(
      '/rest/v1/vendas?select=*&order=numero_venda.desc,data_venda.desc&limit=300',
      { bearerToken: session.accessToken }
    )) ?? []
  );
}

export async function registrarVenda(input: RegistrarVendaInput): Promise<VendaDto> {
  const session = await requireSession();
  const rows = await supabaseFetch<VendaDto[] | VendaDto>('/rest/v1/rpc/registrar_venda_completa', {
    method: 'POST',
    bearerToken: session.accessToken,
    body: {
      p_cliente_id: input.cliente_id || null,
      p_cliente_nome: input.cliente_nome.trim() || 'Consumidor Final',
      p_cliente_telefone: input.cliente_telefone.trim(),
      p_vendedor_id: input.vendedor_id || null,
      p_vendedor_nome: input.vendedor_nome.trim() || session.fullName,
      p_forma_pagamento: input.forma_pagamento.trim() || 'PIX',
      p_desconto: Math.max(0, Number(input.desconto) || 0),
      p_pagamento_pendente: Boolean(input.pagamento_pendente),
      p_observacoes: input.observacoes.trim(),
      p_itens: input.itens
    }
  });
  const saved = Array.isArray(rows) ? rows[0] : rows;
  if (!saved) throw new Error('Venda registrada sem retorno do servidor.');
  return saved;
}

export async function cancelarVenda(vendaId: string): Promise<VendaDto> {
  const session = await requireSession();
  const rows = await supabaseFetch<VendaDto[] | VendaDto>('/rest/v1/rpc/cancelar_venda_completa', {
    method: 'POST',
    bearerToken: session.accessToken,
    body: { p_venda_id: vendaId }
  });
  const saved = Array.isArray(rows) ? rows[0] : rows;
  if (!saved) throw new Error('Cancelamento sem retorno do servidor.');
  return saved;
}

export function buildPlaceholderAiDescription(
  nome: string,
  categoria: string,
  sku: string
): string {
  const skuLabel = sku.trim() ? ` (SKU: ${sku.trim()})` : '';
  return (
    `[Exemplo ilustrativo — Ficha Técnica]\n` +
    `• Componente: ${nome}${skuLabel}\n` +
    `• Categoria: ${categoria}\n` +
    `• Aplicação típica: Manutenção eletrônica de bancada, fontes chaveadas, placas de portão, centrais de alarme e sistemas CFTV.\n` +
    `• Inspeção recomendada: Verificar polaridade/pinagem, tensão de isolação e ESR/resistência antes da soldagem.`
  );
}
