export type CompressionPresetCode = 'ECONOMIA_MAXIMA' | 'EQUILIBRADO' | 'ALTA_NITIDEZ';

export interface ImageCompressionPresetInfo {
  code: CompressionPresetCode;
  label: string;
  shortLabel: string;
  description: string;
  maxDimensionPx: number;
  targetMaxBytes: number;
  initialQuality: number;
  minQuality: number;
}

export const IMAGE_COMPRESSION_PRESETS: Record<CompressionPresetCode, ImageCompressionPresetInfo> = {
  ECONOMIA_MAXIMA: {
    code: 'ECONOMIA_MAXIMA',
    label: 'Máxima (até 65 KB)',
    shortLabel: 'Máxima (65 KB)',
    description: '720px • WebP ultra leve para economizar espaço no Supabase',
    maxDimensionPx: 720,
    targetMaxBytes: 65 * 1024,
    initialQuality: 0.62,
    minQuality: 0.3
  },
  EQUILIBRADO: {
    code: 'EQUILIBRADO',
    label: 'Equilibrado (até 120 KB)',
    shortLabel: 'Equilibrado (120 KB)',
    description: '1024px • WebP recomendado: ótima nitidez e arquivo pequeno',
    maxDimensionPx: 1024,
    targetMaxBytes: 120 * 1024,
    initialQuality: 0.74,
    minQuality: 0.38
  },
  ALTA_NITIDEZ: {
    code: 'ALTA_NITIDEZ',
    label: 'Alta Nitidez (até 240 KB)',
    shortLabel: 'Nitidez (240 KB)',
    description: '1440px • WebP ideal para zoom em placas e componentes SMD',
    maxDimensionPx: 1440,
    targetMaxBytes: 240 * 1024,
    initialQuality: 0.82,
    minQuality: 0.5
  }
};

export interface CompressedImageResult {
  blob: Blob;
  mimeType: string;
  extension: string;
  originalBytes: number;
  compressedBytes: number;
  width: number;
  height: number;
}

function loadImageElement(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(err);
    };
    img.src = url;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), type, quality);
  });
}

export async function compressImageFileToWebP(
  file: File,
  presetCode: CompressionPresetCode = 'EQUILIBRADO'
): Promise<CompressedImageResult> {
  const preset = IMAGE_COMPRESSION_PRESETS[presetCode] ?? IMAGE_COMPRESSION_PRESETS.EQUILIBRADO;
  const img = await loadImageElement(file);

  const origW = img.naturalWidth || img.width;
  const origH = img.naturalHeight || img.height;

  const scale =
    origW > preset.maxDimensionPx || origH > preset.maxDimensionPx
      ? Math.min(preset.maxDimensionPx / origW, preset.maxDimensionPx / origH)
      : 1;

  let targetW = Math.max(1, Math.round(origW * scale));
  let targetH = Math.max(1, Math.round(origH * scale));

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Navegador não suporta processamento Canvas 2D.');
  }

  const drawResized = (w: number, h: number) => {
    canvas.width = w;
    canvas.height = h;
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
  };

  drawResized(targetW, targetH);

  let mimeType = 'image/webp';
  let extension = 'webp';
  let quality = preset.initialQuality;
  let blob = await canvasToBlob(canvas, mimeType, quality);

  if (!blob || (blob.type && blob.type !== 'image/webp')) {
    mimeType = 'image/jpeg';
    extension = 'jpg';
    blob = await canvasToBlob(canvas, mimeType, quality);
  }

  while (blob && blob.size > preset.targetMaxBytes && quality > preset.minQuality) {
    quality = Math.max(preset.minQuality, quality - 0.08);
    blob = await canvasToBlob(canvas, mimeType, quality);
  }

  if (blob && blob.size > preset.targetMaxBytes && (targetW > 480 || targetH > 480)) {
    targetW = Math.max(1, Math.round(targetW * 0.8));
    targetH = Math.max(1, Math.round(targetH * 0.8));
    drawResized(targetW, targetH);
    blob = await canvasToBlob(canvas, mimeType, preset.minQuality);
  }

  if (!blob) {
    throw new Error('Falha ao compactar imagem.');
  }

  return {
    blob,
    mimeType,
    extension,
    originalBytes: file.size || blob.size,
    compressedBytes: blob.size,
    width: targetW,
    height: targetH
  };
}
