const brlFormatter = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL'
});

export function formatCurrency(value: number | undefined | null): string {
  const safe = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  return brlFormatter.format(safe);
}

export function formatPercent(value: number | undefined | null): string {
  const safe = typeof value === 'number' && Number.isFinite(value) ? value : 0;
  if (Math.abs(safe - Math.round(safe)) < 0.01) {
    return `${Math.round(safe)}`;
  }
  return safe.toFixed(1).replace('.', ',');
}

export function todayIsoDate(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function nowIsoTimestamp(): string {
  return new Date().toISOString();
}

function parseDateSafe(isoDate?: string | null): Date | null {
  if (!isoDate || !isoDate.trim()) return null;
  const clean = isoDate.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    const [y, m, d] = clean.split('-').map(Number);
    return new Date(y, m - 1, d, 12, 0, 0);
  }
  const parsed = new Date(clean);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function formatDateBr(isoDate?: string | null): string {
  const d = parseDateSafe(isoDate);
  if (!d) return isoDate && isoDate.trim() ? isoDate.trim().slice(0, 10) : '—';
  return d.toLocaleDateString('pt-BR');
}

export function formatDateTimeBr(isoDate?: string | null): string {
  if (!isoDate || !isoDate.trim()) return '—';
  const clean = isoDate.trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    return formatDateBr(clean);
  }
  const d = parseDateSafe(clean);
  if (!d) return formatDateBr(clean);
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export function addDaysToDateBr(isoDate: string | null | undefined, days: number): string {
  const base = parseDateSafe(isoDate) ?? new Date();
  const copy = new Date(base.getTime());
  copy.setDate(copy.getDate() + Math.max(0, days));
  return copy.toLocaleDateString('pt-BR');
}

export function parseIsoDayMillis(isoDate?: string | null): number | null {
  const d = parseDateSafe(isoDate);
  if (!d) return null;
  const normalized = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
  return normalized.getTime();
}

export function daysBetweenIsoDates(startIso?: string | null, endIso?: string | null): number {
  const startMs = parseIsoDayMillis(startIso);
  if (startMs === null) return 0;
  const endMs = parseIsoDayMillis(endIso ?? todayIsoDate());
  if (endMs === null) return 0;
  return Math.floor((endMs - startMs) / 86_400_000);
}

export function parseDoubleInput(raw: string): number {
  const cleaned = raw.trim().replace(/R\$/gi, '').replace(/\s+/g, '');
  if (!cleaned) return 0;
  let normalized = cleaned;
  if (cleaned.includes(',') && cleaned.includes('.')) {
    normalized = cleaned.replace(/\./g, '').replace(',', '.');
  } else if (cleaned.includes(',')) {
    normalized = cleaned.replace(',', '.');
  }
  const num = Number.parseFloat(normalized);
  return Number.isFinite(num) ? num : 0;
}

export function normalizeBrazilPhone(raw?: string | null): string | null {
  if (!raw) return null;
  const digits = raw.replace(/\D/g, '');
  if (digits.length < 10) return null;
  return digits.startsWith('55') && digits.length >= 12 ? digits : `55${digits}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${Math.round(kb)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(2).replace('.', ',')} MB`;
}
