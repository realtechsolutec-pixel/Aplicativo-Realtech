import { FuncionarioDto, OrdemServicoDto, UserSession } from '../types/models';

export interface OsCommissionBreakdown {
  os: OrdemServicoDto;
  tecnicoNome: string;
  percentApplied: number;
  ganhoTecnico: number;
  valorGeradoLoja: number;
  liquidoLoja: number;
  isFinalizada: boolean;
}

export interface TechnicianPerformanceSummary {
  key: string;
  funcionario: FuncionarioDto | null;
  nome: string;
  email: string;
  cargo: string;
  ativo: boolean;
  comissaoPadraoPercent: number;
  osGeradasCount: number;
  osFinalizadasCount: number;
  osEmAndamentoCount: number;
  totalGeradoLojaFinalizado: number;
  totalGeradoLojaEmAndamento: number;
  maoObraFinalizada: number;
  pecasFinalizadas: number;
  comissaoConfirmada: number;
  comissaoPrevista: number;
  liquidoLojaConfirmado: number;
  ordensDoTecnico: OsCommissionBreakdown[];
}

export function findMatchingFuncionario(
  os: OrdemServicoDto,
  funcionarios: FuncionarioDto[]
): FuncionarioDto | undefined {
  if (os.tecnico_id) {
    const byId = funcionarios.find((f) => f.id === os.tecnico_id);
    if (byId) return byId;
  }
  if (os.tecnico_email?.trim()) {
    const email = os.tecnico_email.trim().toLowerCase();
    const byEmail = funcionarios.find((f) => f.email.trim().toLowerCase() === email);
    if (byEmail) return byEmail;
  }
  if (os.tecnico_nome?.trim()) {
    const nome = os.tecnico_nome.trim().toLowerCase();
    const byName = funcionarios.find((f) => f.nome.trim().toLowerCase() === nome);
    if (byName) return byName;
  }
  return undefined;
}

export function findFuncionarioForSession(
  session: UserSession | null,
  funcionarios: FuncionarioDto[]
): FuncionarioDto | undefined {
  if (!session) return undefined;
  const email = session.email.trim().toLowerCase();
  const fullName = session.fullName.trim().toLowerCase();
  return funcionarios.find(
    (f) =>
      (f.funcionario_user_id && f.funcionario_user_id === session.userId) ||
      f.email.trim().toLowerCase() === email ||
      f.nome.trim().toLowerCase() === fullName
  );
}

export function resolveEffectivePercent(
  os: OrdemServicoDto,
  funcionarios: FuncionarioDto[]
): number {
  if (os.comissao_percentual > 0) {
    return Math.min(100, Math.max(0, os.comissao_percentual));
  }
  const matched = findMatchingFuncionario(os, funcionarios);
  return Math.min(100, Math.max(0, matched?.comissao_percentual ?? 0));
}

export function calculateGanho(valorMaoObra: number, percentual: number): number {
  const cleanMaoObra = Math.max(0, valorMaoObra || 0);
  const cleanPct = Math.min(100, Math.max(0, percentual || 0));
  return cleanMaoObra * (cleanPct / 100);
}

export function buildCommissionBreakdown(
  os: OrdemServicoDto,
  funcionarios: FuncionarioDto[]
): OsCommissionBreakdown {
  const matched = findMatchingFuncionario(os, funcionarios);
  const percentApplied = resolveEffectivePercent(os, funcionarios);
  const ganhoTecnico = calculateGanho(os.valor_mao_obra, percentApplied);
  const valorGeradoLoja = Math.max(0, os.valor_total || 0);
  const liquidoLoja = Math.max(0, valorGeradoLoja - ganhoTecnico);
  const tecnicoNome =
    os.tecnico_nome?.trim() || matched?.nome || os.criado_por_nome?.trim() || 'Não atribuído';

  return {
    os,
    tecnicoNome,
    percentApplied,
    ganhoTecnico,
    valorGeradoLoja,
    liquidoLoja,
    isFinalizada: os.status === 'ENTREGUE'
  };
}

export function matchesEmployee(
  os: OrdemServicoDto,
  funcionario: FuncionarioDto | undefined,
  userName: string,
  userEmail: string
): boolean {
  if (funcionario) {
    if (funcionario.id && os.tecnico_id === funcionario.id) return true;
    if (os.tecnico_email?.trim().toLowerCase() === funcionario.email.trim().toLowerCase()) {
      return true;
    }
    if (os.tecnico_nome?.trim().toLowerCase() === funcionario.nome.trim().toLowerCase()) {
      return true;
    }
  }
  const cleanEmail = userEmail.trim().toLowerCase();
  const cleanName = userName.trim().toLowerCase();
  if (cleanEmail && os.tecnico_email?.trim().toLowerCase() === cleanEmail) return true;
  if (cleanName && os.tecnico_nome?.trim().toLowerCase() === cleanName) return true;
  if (
    !os.tecnico_nome?.trim() &&
    !os.tecnico_id &&
    cleanName &&
    os.criado_por_nome?.trim().toLowerCase() === cleanName
  ) {
    return true;
  }
  return false;
}

export function filterOrdensForEmployee(
  ordens: OrdemServicoDto[],
  funcionario: FuncionarioDto | undefined,
  userName: string,
  userEmail: string
): OrdemServicoDto[] {
  return ordens.filter((os) => matchesEmployee(os, funcionario, userName, userEmail));
}

export function buildTeamPerformance(
  ordens: OrdemServicoDto[],
  funcionarios: FuncionarioDto[]
): TechnicianPerformanceSummary[] {
  const summaries: TechnicianPerformanceSummary[] = [];
  const assignedOsIds = new Set<string>();

  for (const func of funcionarios) {
    const funcEmail = func.email.trim().toLowerCase();
    const funcNome = func.nome.trim().toLowerCase();

    const funcOrders = ordens.filter((os) => {
      const matchesTech =
        (Boolean(func.id) && os.tecnico_id === func.id) ||
        (Boolean(os.tecnico_email?.trim()) && os.tecnico_email.trim().toLowerCase() === funcEmail) ||
        (Boolean(os.tecnico_nome?.trim()) && os.tecnico_nome.trim().toLowerCase() === funcNome);
      if (matchesTech && os.id) {
        assignedOsIds.add(os.id);
      }
      return matchesTech;
    });

    const geradasCount = ordens.filter(
      (os) =>
        os.criado_por_nome?.trim().toLowerCase() === funcNome ||
        (Boolean(func.id) && os.tecnico_id === func.id) ||
        (Boolean(os.tecnico_email?.trim()) && os.tecnico_email.trim().toLowerCase() === funcEmail) ||
        (Boolean(os.tecnico_nome?.trim()) && os.tecnico_nome.trim().toLowerCase() === funcNome)
    ).length;

    const breakdowns = funcOrders.map((os) => buildCommissionBreakdown(os, funcionarios));
    const finalizadas = breakdowns.filter((b) => b.isFinalizada);
    const emAndamento = breakdowns.filter((b) => !b.isFinalizada);

    const totalLojaFin = finalizadas.reduce((acc, b) => acc + b.valorGeradoLoja, 0);
    const comissaoConf = finalizadas.reduce((acc, b) => acc + b.ganhoTecnico, 0);

    summaries.push({
      key: func.id || func.email,
      funcionario: func,
      nome: func.nome,
      email: func.email,
      cargo: func.cargo,
      ativo: func.ativo,
      comissaoPadraoPercent: func.comissao_percentual,
      osGeradasCount: geradasCount,
      osFinalizadasCount: finalizadas.length,
      osEmAndamentoCount: emAndamento.length,
      totalGeradoLojaFinalizado: totalLojaFin,
      totalGeradoLojaEmAndamento: emAndamento.reduce((acc, b) => acc + b.valorGeradoLoja, 0),
      maoObraFinalizada: finalizadas.reduce((acc, b) => acc + (b.os.valor_mao_obra || 0), 0),
      pecasFinalizadas: finalizadas.reduce((acc, b) => acc + (b.os.valor_pecas || 0), 0),
      comissaoConfirmada: comissaoConf,
      comissaoPrevista: emAndamento.reduce((acc, b) => acc + b.ganhoTecnico, 0),
      liquidoLojaConfirmado: Math.max(0, totalLojaFin - comissaoConf),
      ordensDoTecnico: [...breakdowns].sort((a, b) => b.os.numero_os - a.os.numero_os)
    });
  }

  const extraOrders = ordens.filter((os) => {
    const alreadyCounted = Boolean(os.id) && assignedOsIds.has(os.id as string);
    return !alreadyCounted && Boolean(os.tecnico_nome?.trim());
  });

  const groupedExtra = new Map<string, OrdemServicoDto[]>();
  for (const os of extraOrders) {
    const key = os.tecnico_nome.trim();
    const arr = groupedExtra.get(key) ?? [];
    arr.push(os);
    groupedExtra.set(key, arr);
  }

  for (const [techName, techOrders] of groupedExtra.entries()) {
    const breakdowns = techOrders.map((os) => buildCommissionBreakdown(os, funcionarios));
    const finalizadas = breakdowns.filter((b) => b.isFinalizada);
    const emAndamento = breakdowns.filter((b) => !b.isFinalizada);
    const totalLojaFin = finalizadas.reduce((acc, b) => acc + b.valorGeradoLoja, 0);
    const comissaoConf = finalizadas.reduce((acc, b) => acc + b.ganhoTecnico, 0);

    summaries.push({
      key: `custom_${techName}`,
      funcionario: null,
      nome: techName,
      email: techOrders.find((o) => o.tecnico_email?.trim())?.tecnico_email ?? '',
      cargo: 'Responsável Técnico',
      ativo: true,
      comissaoPadraoPercent: breakdowns[0]?.percentApplied ?? 0,
      osGeradasCount: techOrders.length,
      osFinalizadasCount: finalizadas.length,
      osEmAndamentoCount: emAndamento.length,
      totalGeradoLojaFinalizado: totalLojaFin,
      totalGeradoLojaEmAndamento: emAndamento.reduce((acc, b) => acc + b.valorGeradoLoja, 0),
      maoObraFinalizada: finalizadas.reduce((acc, b) => acc + (b.os.valor_mao_obra || 0), 0),
      pecasFinalizadas: finalizadas.reduce((acc, b) => acc + (b.os.valor_pecas || 0), 0),
      comissaoConfirmada: comissaoConf,
      comissaoPrevista: emAndamento.reduce((acc, b) => acc + b.ganhoTecnico, 0),
      liquidoLojaConfirmado: Math.max(0, totalLojaFin - comissaoConf),
      ordensDoTecnico: [...breakdowns].sort((a, b) => b.os.numero_os - a.os.numero_os)
    });
  }

  return summaries.sort((a, b) => {
    if (b.totalGeradoLojaFinalizado !== a.totalGeradoLojaFinalizado) {
      return b.totalGeradoLojaFinalizado - a.totalGeradoLojaFinalizado;
    }
    if (b.osFinalizadasCount !== a.osFinalizadasCount) {
      return b.osFinalizadasCount - a.osFinalizadasCount;
    }
    return a.nome.localeCompare(b.nome, 'pt-BR');
  });
}
