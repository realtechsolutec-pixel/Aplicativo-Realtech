import {
  isContaFixaEfetiva,
  isEstoqueBaixo,
  OrdemServicoDto,
  PecaEstoqueDto,
  PedidoPecaDto,
  TransacaoFinanceiraDto
} from '../types/models';
import { daysBetweenIsoDates, todayIsoDate } from './formatters';

export interface TransacaoAlertItem {
  transacao: TransacaoFinanceiraDto;
  diasEmAtraso: number;
}

export interface OsAlertItem {
  os: OrdemServicoDto;
  diasEmAberto: number;
}

export interface WorkshopAlerts {
  contasReceberMais30Dias: TransacaoAlertItem[];
  contasFixasEmAtraso: TransacaoAlertItem[];
  ordensMais30Dias: OsAlertItem[];
  pedidosPecasPendentes: PedidoPecaDto[];
  pecasEstoqueBaixoCount: number;
  totalContasReceber30Dias: number;
  totalContasFixasEmAtraso: number;
  activeAlertsCount: number;
  financeiroAlertsCount: number;
}

export function diasSemConclusao(os: OrdemServicoDto, referenceDateIso = todayIsoDate()): number {
  if (os.status === 'ENTREGUE') return 0;
  const baseDate = os.data_entrada?.trim() ? os.data_entrada : os.created_at;
  return Math.max(0, daysBetweenIsoDates(baseDate, referenceDateIso));
}

export function diasEmAtraso(
  tx: TransacaoFinanceiraDto,
  referenceDateIso = todayIsoDate()
): number {
  if (tx.status === 'PAGO') return 0;
  const baseDate = tx.data_vencimento?.trim() ? tx.data_vencimento : tx.created_at;
  return Math.max(0, daysBetweenIsoDates(baseDate, referenceDateIso));
}

export function computeWorkshopAlerts(params: {
  ordens: OrdemServicoDto[];
  transacoes: TransacaoFinanceiraDto[];
  pedidosPecas: PedidoPecaDto[];
  pecas: PecaEstoqueDto[];
  canAccessFinanceiro: boolean;
  referenceDateIso?: string;
}): WorkshopAlerts {
  const ref = params.referenceDateIso ?? todayIsoDate();

  const ordensMais30Dias: OsAlertItem[] = params.ordens
    .filter((os) => os.status !== 'ENTREGUE')
    .map((os) => ({ os, diasEmAberto: diasSemConclusao(os, ref) }))
    .filter((item) => item.diasEmAberto > 30)
    .sort((a, b) => b.diasEmAberto - a.diasEmAberto);

  const contasReceberMais30Dias: TransacaoAlertItem[] = params.canAccessFinanceiro
    ? params.transacoes
        .filter((tx) => tx.tipo === 'RECEBER' && tx.status === 'PENDENTE')
        .map((tx) => ({ transacao: tx, diasEmAtraso: diasEmAtraso(tx, ref) }))
        .filter((item) => item.diasEmAtraso > 30)
        .sort((a, b) => b.diasEmAtraso - a.diasEmAtraso)
    : [];

  const contasFixasEmAtraso: TransacaoAlertItem[] = params.canAccessFinanceiro
    ? params.transacoes
        .filter((tx) => tx.tipo === 'PAGAR' && tx.status === 'PENDENTE' && isContaFixaEfetiva(tx))
        .map((tx) => ({ transacao: tx, diasEmAtraso: diasEmAtraso(tx, ref) }))
        .filter((item) => item.diasEmAtraso >= 1)
        .sort((a, b) => b.diasEmAtraso - a.diasEmAtraso)
    : [];

  const pedidosPecasPendentes = params.pedidosPecas.filter((p) => p.status !== 'RECEBIDA');
  const pecasEstoqueBaixoCount = params.pecas.filter(isEstoqueBaixo).length;

  const totalContasReceber30Dias = contasReceberMais30Dias.reduce(
    (sum, item) => sum + item.transacao.valor,
    0
  );
  const totalContasFixasEmAtraso = contasFixasEmAtraso.reduce(
    (sum, item) => sum + item.transacao.valor,
    0
  );

  const activeAlertsCount =
    contasReceberMais30Dias.length +
    contasFixasEmAtraso.length +
    ordensMais30Dias.length +
    pedidosPecasPendentes.length +
    (pecasEstoqueBaixoCount > 0 ? 1 : 0);

  return {
    contasReceberMais30Dias,
    contasFixasEmAtraso,
    ordensMais30Dias,
    pedidosPecasPendentes,
    pecasEstoqueBaixoCount,
    totalContasReceber30Dias,
    totalContasFixasEmAtraso,
    activeAlertsCount,
    financeiroAlertsCount: contasReceberMais30Dias.length + contasFixasEmAtraso.length
  };
}
