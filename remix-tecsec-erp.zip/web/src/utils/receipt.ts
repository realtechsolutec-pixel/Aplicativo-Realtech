import {
  ConfiguracaoOficinaDto,
  DEFAULT_CONFIG_OFICINA,
  OrdemServicoDto,
  STATUS_OS_META,
  STATUS_VENDA_META,
  StatusOSCode,
  StatusVendaCode,
  VendaDto
} from '../types/models';
import {
  addDaysToDateBr,
  formatCurrency,
  formatDateTimeBr,
  normalizeBrazilPhone,
  nowIsoTimestamp
} from './formatters';

export type ReceiptKind = 'ENTRADA' | 'SAIDA' | 'GARANTIA';
export type ReceiptFormat = 'PDF_A4' | 'TERMICA_80MM';

export const RECEIPT_KIND_LABELS: Record<ReceiptKind, string> = {
  ENTRADA: 'Comprovante de Entrada',
  SAIDA: 'Comprovante de Saída',
  GARANTIA: 'Nota de Garantia'
};

export function buildThermalText(
  os: OrdemServicoDto,
  kind: ReceiptKind,
  storeConfig: ConfiguracaoOficinaDto = DEFAULT_CONFIG_OFICINA,
  columns = 38
): string {
  const sep = '='.repeat(columns);
  const dash = '-'.repeat(columns);
  const lines: string[] = [];

  const center = (text: string) => {
    const clean = text.slice(0, columns);
    const pad = Math.max(0, Math.floor((columns - clean.length) / 2));
    return ' '.repeat(pad) + clean;
  };

  const baseDelivery = os.data_saida || nowIsoTimestamp();
  const validUntil = addDaysToDateBr(baseDelivery, os.garantia_dias);
  const storeTitle = (storeConfig.nome_loja || 'RTERP ELETRÔNICA & SEGURANÇA').toUpperCase();
  const statusLabel = STATUS_OS_META[(os.status as StatusOSCode) || 'ABERTA']?.label ?? os.status;

  lines.push(sep);
  lines.push(center(storeTitle));
  if (storeConfig.cnpj?.trim()) lines.push(center(`CNPJ: ${storeConfig.cnpj}`));
  if (storeConfig.telefone?.trim()) lines.push(center(`Tel: ${storeConfig.telefone}`));
  if (storeConfig.endereco?.trim()) lines.push(storeConfig.endereco);
  lines.push(sep);
  lines.push(center(RECEIPT_KIND_LABELS[kind].toUpperCase()));
  lines.push(center(`OS Nº #${os.numero_os}`));
  lines.push(dash);
  lines.push(`Entrada: ${formatDateTimeBr(os.data_entrada)}`);
  if (kind === 'SAIDA' || kind === 'GARANTIA') {
    lines.push(`Entrega: ${formatDateTimeBr(baseDelivery)}`);
  }
  lines.push(`Status: ${statusLabel}`);
  if (os.tecnico_nome?.trim()) {
    lines.push(`Técnico Resp.: ${os.tecnico_nome}`);
  }
  lines.push(dash);
  lines.push('CLIENTE:');
  lines.push(os.cliente_nome);
  if (os.cliente_telefone?.trim()) lines.push(`Tel/Whats: ${os.cliente_telefone}`);
  lines.push(dash);
  lines.push('EQUIPAMENTO:');
  lines.push(`${os.categoria_equipamento} - ${os.equipamento}`);
  if (os.marca_modelo?.trim()) lines.push(`Modelo: ${os.marca_modelo}`);
  if (os.numero_serie?.trim()) lines.push(`Nº Série: ${os.numero_serie}`);
  if (kind === 'ENTRADA' && os.acessorios_entregues?.trim()) {
    lines.push(`Acessórios: ${os.acessorios_entregues}`);
  }
  lines.push(dash);

  if (kind === 'GARANTIA') {
    lines.push('SERVIÇO COBERTO PELA GARANTIA:');
    lines.push(os.diagnostico_tecnico?.trim() || os.defeito_relatado);
    if (os.pecas_utilizadas?.trim()) lines.push(`Peças: ${os.pecas_utilizadas}`);
    lines.push(dash);
    lines.push(`Valor Pago: ${formatCurrency(os.valor_total)}`);
    lines.push(`Prazo: ${os.garantia_dias} dias`);
    lines.push(`Válida até: ${validUntil}`);
    lines.push(dash);
    lines.push('TERMO DE GARANTIA:');
    lines.push('Cobre apenas os serviços e peças');
    lines.push('acima descritos. Não cobre mau uso,');
    lines.push('umidade, descarga elétrica ou lacre');
    lines.push('rompido.');
  } else {
    lines.push('DEFEITO RELATADO:');
    lines.push(os.defeito_relatado);

    if (kind === 'SAIDA') {
      if (os.diagnostico_tecnico?.trim()) {
        lines.push(dash);
        lines.push('DIAGNÓSTICO / SERVIÇO:');
        lines.push(os.diagnostico_tecnico);
      }
      if (os.pecas_utilizadas?.trim()) lines.push(`Peças: ${os.pecas_utilizadas}`);
      lines.push(dash);
      lines.push(`Mão de Obra: ${formatCurrency(os.valor_mao_obra)}`);
      lines.push(`Peças: ${formatCurrency(os.valor_pecas)}`);
      if (os.desconto > 0) lines.push(`Desconto: -${formatCurrency(os.desconto)}`);
      lines.push(`TOTAL: ${formatCurrency(os.valor_total)}`);
      lines.push(`Garantia: ${os.garantia_dias} dias (até ${validUntil})`);
    } else {
      if (os.valor_total > 0) {
        lines.push(dash);
        lines.push(`Orçamento Est.: ${formatCurrency(os.valor_total)}`);
      }
      lines.push(dash);
      lines.push(
        storeConfig.rodape_os?.trim() ||
          'OBS: Equipamentos não retirados em 90 dias estarão sujeitos a taxa de estadia/descarte.'
      );
    }
  }

  lines.push(dash);
  lines.push('');
  lines.push('Ass: _________________________________');
  lines.push(center(os.cliente_nome.slice(0, columns)));
  lines.push(sep);
  return lines.join('\n');
}

export function buildOsWhatsAppMessage(
  os: OrdemServicoDto,
  storeConfig: ConfiguracaoOficinaDto = DEFAULT_CONFIG_OFICINA
): string {
  const workshopName = storeConfig.nome_loja?.trim() || 'RTerp Eletrônica & Segurança';
  const statusLabel = STATUS_OS_META[(os.status as StatusOSCode) || 'ABERTA']?.label ?? os.status;
  const lines: string[] = [];

  lines.push(`*${workshopName}*`);
  if (storeConfig.cnpj?.trim()) lines.push(`CNPJ: ${storeConfig.cnpj}`);
  if (storeConfig.telefone?.trim()) lines.push(`📞 ${storeConfig.telefone}`);
  if (storeConfig.endereco?.trim()) lines.push(`📍 ${storeConfig.endereco}`);
  lines.push(`📋 *ORDEM DE SERVIÇO Nº #${os.numero_os}*`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`👤 *Cliente:* ${os.cliente_nome}`);
  if (os.tecnico_nome?.trim()) lines.push(`🛠️ *Técnico Responsável:* ${os.tecnico_nome}`);
  lines.push(`🔧 *Equipamento:* ${os.categoria_equipamento} - ${os.equipamento}`);
  if (os.marca_modelo?.trim()) lines.push(`🏷️ *Modelo:* ${os.marca_modelo}`);
  if (os.numero_serie?.trim()) lines.push(`🔢 *Nº Série:* ${os.numero_serie}`);
  if (os.acessorios_entregues?.trim()) lines.push(`🎒 *Acessórios:* ${os.acessorios_entregues}`);
  lines.push(`📌 *Status:* ${statusLabel}`);
  lines.push(`📅 *Entrada:* ${formatDateTimeBr(os.data_entrada)}`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`⚠️ *Defeito Relatado:* ${os.defeito_relatado}`);
  if (os.diagnostico_tecnico?.trim()) {
    lines.push(`🛠️ *Diagnóstico / Serviço:* ${os.diagnostico_tecnico}`);
  }
  if (os.pecas_utilizadas?.trim()) {
    lines.push(`🔩 *Peças:* ${os.pecas_utilizadas}`);
  }
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  if (os.valor_mao_obra > 0) lines.push(`Mão de Obra: ${formatCurrency(os.valor_mao_obra)}`);
  if (os.valor_pecas > 0) lines.push(`Peças: ${formatCurrency(os.valor_pecas)}`);
  if (os.desconto > 0) lines.push(`Desconto: -${formatCurrency(os.desconto)}`);
  lines.push(`💰 *VALOR TOTAL:* ${formatCurrency(os.valor_total)}`);
  lines.push(`🛡️ *Garantia:* ${os.garantia_dias} dias`);
  if (os.fotos_urls?.length) {
    lines.push(`📷 *Fotos anexadas:* ${os.fotos_urls.length}`);
  }

  return lines.join('\n').trim();
}

export function buildWarrantyWhatsAppMessage(
  os: OrdemServicoDto,
  storeConfig: ConfiguracaoOficinaDto = DEFAULT_CONFIG_OFICINA
): string {
  const workshopName = storeConfig.nome_loja?.trim() || 'RTerp Eletrônica & Segurança';
  const baseDate = os.data_saida || nowIsoTimestamp();
  const validUntil = addDaysToDateBr(baseDate, os.garantia_dias);
  const lines: string[] = [];

  lines.push(`*${workshopName}*`);
  if (storeConfig.cnpj?.trim()) lines.push(`CNPJ: ${storeConfig.cnpj}`);
  if (storeConfig.telefone?.trim()) lines.push(`📞 ${storeConfig.telefone}`);
  if (storeConfig.endereco?.trim()) lines.push(`📍 ${storeConfig.endereco}`);
  lines.push('🛡️ *NOTA / CERTIFICADO DE GARANTIA*');
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`📄 *OS Referência:* #${os.numero_os}`);
  lines.push(`👤 *Cliente:* ${os.cliente_nome}`);
  if (os.tecnico_nome?.trim()) lines.push(`🛠️ *Técnico Responsável:* ${os.tecnico_nome}`);
  lines.push(`🔧 *Equipamento:* ${`${os.equipamento} ${os.marca_modelo}`.trim()}`);
  if (os.numero_serie?.trim()) lines.push(`🔢 *Nº Série:* ${os.numero_serie}`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push('🛠️ *Serviço Executado:*');
  lines.push(os.diagnostico_tecnico?.trim() || os.defeito_relatado);
  if (os.pecas_utilizadas?.trim()) lines.push(`🔩 *Peças Substituídas:* ${os.pecas_utilizadas}`);
  lines.push(`💰 *Valor Pago:* ${formatCurrency(os.valor_total)}`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`📅 *Data de Entrega:* ${formatDateTimeBr(baseDate)}`);
  lines.push(`✅ *Prazo de Garantia:* ${os.garantia_dias} dias`);
  lines.push(`📆 *Válida até:* *${validUntil}*`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(
    '_Esta garantia cobre exclusivamente os serviços e componentes substituídos descritos nesta OS. Não cobre danos por mau uso, quedas, umidade, descarga elétrica ou violação do lacre._'
  );
  return lines.join('\n').trim();
}

export function buildSaleThermalText(
  venda: VendaDto,
  storeConfig: ConfiguracaoOficinaDto = DEFAULT_CONFIG_OFICINA,
  columns = 38
): string {
  const sep = '='.repeat(columns);
  const dash = '-'.repeat(columns);
  const lines: string[] = [];

  const center = (text: string) => {
    const clean = text.slice(0, columns);
    const pad = Math.max(0, Math.floor((columns - clean.length) / 2));
    return ' '.repeat(pad) + clean;
  };

  const storeTitle = (storeConfig.nome_loja || 'RTERP ELETRÔNICA & SEGURANÇA').toUpperCase();
  const statusLabel =
    STATUS_VENDA_META[(venda.status as StatusVendaCode) || 'CONCLUIDA']?.label ?? venda.status;

  lines.push(sep);
  lines.push(center(storeTitle));
  if (storeConfig.cnpj?.trim()) lines.push(center(`CNPJ: ${storeConfig.cnpj}`));
  if (storeConfig.telefone?.trim()) lines.push(center(`Tel: ${storeConfig.telefone}`));
  if (storeConfig.endereco?.trim()) lines.push(storeConfig.endereco);
  lines.push(sep);
  lines.push(center('CUPOM / NOTA DE VENDA'));
  lines.push(center(`VENDA Nº #${venda.numero_venda}`));
  lines.push(dash);
  lines.push(`Data: ${formatDateTimeBr(venda.data_venda || venda.created_at)}`);
  lines.push(`Status: ${statusLabel}`);
  lines.push(`Pagamento: ${venda.forma_pagamento}`);
  if (venda.vendedor_nome?.trim()) {
    lines.push(`Vendedor: ${venda.vendedor_nome}`);
  }
  lines.push(dash);
  lines.push(`Cliente: ${venda.cliente_nome || 'Consumidor Final'}`);
  if (venda.cliente_telefone?.trim()) {
    lines.push(`Tel/Whats: ${venda.cliente_telefone}`);
  }
  lines.push(dash);
  lines.push('ITENS DA VENDA:');
  (venda.itens || []).forEach((item, idx) => {
    const skuTag = item.codigo_sku ? ` [${item.codigo_sku}]` : '';
    lines.push(`${idx + 1}. ${item.nome}${skuTag}`);
    lines.push(
      `   ${item.quantidade} un x ${formatCurrency(item.preco_unitario)} = ${formatCurrency(item.subtotal)}`
    );
  });
  lines.push(dash);
  lines.push(`Subtotal: ${formatCurrency(venda.subtotal)}`);
  if (venda.desconto > 0) {
    lines.push(`Desconto: -${formatCurrency(venda.desconto)}`);
  }
  lines.push(`TOTAL PAGO/DEVIDO: ${formatCurrency(venda.valor_total)}`);
  if (venda.observacoes?.trim()) {
    lines.push(dash);
    lines.push(`Obs: ${venda.observacoes}`);
  }
  lines.push(dash);
  lines.push(center('DOCUMENTO SEM VALOR FISCAL'));
  lines.push(center('Obrigado pela preferência!'));
  lines.push(sep);
  return lines.join('\n');
}

export function buildSaleWhatsAppMessage(
  venda: VendaDto,
  storeConfig: ConfiguracaoOficinaDto = DEFAULT_CONFIG_OFICINA
): string {
  const workshopName = storeConfig.nome_loja?.trim() || 'RTerp Eletrônica & Segurança';
  const statusLabel =
    STATUS_VENDA_META[(venda.status as StatusVendaCode) || 'CONCLUIDA']?.label ?? venda.status;
  const lines: string[] = [];

  lines.push(`*${workshopName}*`);
  if (storeConfig.cnpj?.trim()) lines.push(`CNPJ: ${storeConfig.cnpj}`);
  if (storeConfig.telefone?.trim()) lines.push(`📞 ${storeConfig.telefone}`);
  if (storeConfig.endereco?.trim()) lines.push(`📍 ${storeConfig.endereco}`);
  lines.push(`🧾 *NOTA / CUPOM DE VENDA Nº #${venda.numero_venda}*`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`👤 *Cliente:* ${venda.cliente_nome || 'Consumidor Final'}`);
  if (venda.vendedor_nome?.trim()) lines.push(`🧑‍💼 *Vendedor:* ${venda.vendedor_nome}`);
  lines.push(`📅 *Data:* ${formatDateTimeBr(venda.data_venda || venda.created_at)}`);
  lines.push(`💳 *Pagamento:* ${venda.forma_pagamento} (${statusLabel})`);
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push('🛒 *Itens:*');
  (venda.itens || []).forEach((item, idx) => {
    lines.push(
      `${idx + 1}. *${item.nome}* — ${item.quantidade}x ${formatCurrency(item.preco_unitario)} = *${formatCurrency(item.subtotal)}*`
    );
  });
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push(`Subtotal: ${formatCurrency(venda.subtotal)}`);
  if (venda.desconto > 0) lines.push(`Desconto: -${formatCurrency(venda.desconto)}`);
  lines.push(`💰 *TOTAL:* *${formatCurrency(venda.valor_total)}*`);
  if (venda.observacoes?.trim()) {
    lines.push(`📝 *Obs:* ${venda.observacoes}`);
  }
  lines.push('━━━━━━━━━━━━━━━━━━━━');
  lines.push('_Comprovante de venda não fiscal emitido pelo RTerp._');
  return lines.join('\n').trim();
}

export function openWhatsAppWeb(phoneRaw: string | null | undefined, message: string): void {
  const cleanPhone = normalizeBrazilPhone(phoneRaw);
  const encoded = encodeURIComponent(message);
  const url = cleanPhone
    ? `https://wa.me/${cleanPhone}?text=${encoded}`
    : `https://wa.me/?text=${encoded}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}
