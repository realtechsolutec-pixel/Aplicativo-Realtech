import React from 'react';
import { LayoutShell } from './components/LayoutShell';
import { useWorkshop, WorkshopProvider } from './context/WorkshopContext';
import { ClientesPage } from './pages/ClientesPage';
import { ComissoesPage } from './pages/ComissoesPage';
import { ComparativoPrecosPage } from './pages/ComparativoPrecosPage';
import { ConfiguracaoOficinaPage } from './pages/ConfiguracaoOficinaPage';
import { DashboardPage } from './pages/DashboardPage';
import { EstoquePage } from './pages/EstoquePage';
import { FinanceiroPage } from './pages/FinanceiroPage';
import { LoginPage } from './pages/LoginPage';
import { MetasPage } from './pages/MetasPage';
import { OrdensServicoPage } from './pages/OrdensServicoPage';
import { PedidosPecasPage } from './pages/PedidosPecasPage';
import { VendasPage } from './pages/VendasPage';

const AppRouter: React.FC = () => {
  const { session, authChecking, isAdmin, currentRoute } = useWorkshop();

  if (authChecking) {
    return (
      <div className="min-h-screen bg-bench-bg flex flex-col items-center justify-center gap-3 p-6">
        <img
          src="/rterp-logo.png"
          alt="RTerp"
          className="w-16 h-16 rounded-2xl object-cover shadow-lg border border-slate-200 animate-pulse"
        />
        <p className="text-sm font-semibold text-slate-600">Carregando sessão RTerp...</p>
      </div>
    );
  }

  if (!session) {
    return <LoginPage />;
  }

  const renderPage = () => {
    switch (currentRoute) {
      case 'dashboard':
        return <DashboardPage />;
      case 'vendas':
        return <VendasPage />;
      case 'clientes':
        return <ClientesPage />;
      case 'ordens_servico':
        return <OrdensServicoPage />;
      case 'comissoes':
        return <ComissoesPage />;
      case 'pedidos_pecas':
        return <PedidosPecasPage />;
      case 'estoque':
        return <EstoquePage />;
      case 'precos':
        return <ComparativoPrecosPage />;
      case 'financeiro':
        return isAdmin ? <FinanceiroPage /> : <DashboardPage />;
      case 'metas':
        return isAdmin ? <MetasPage /> : <DashboardPage />;
      case 'config_oficina':
        return isAdmin ? <ConfiguracaoOficinaPage /> : <DashboardPage />;
      default:
        return <DashboardPage />;
    }
  };

  return <LayoutShell>{renderPage()}</LayoutShell>;
};

export function App() {
  return (
    <WorkshopProvider>
      <AppRouter />
    </WorkshopProvider>
  );
}

export default App;
