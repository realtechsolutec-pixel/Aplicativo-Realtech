export type UserRole = 'ADMIN' | 'FUNCIONARIO';

export type TipoCliente = 'PF' | 'PJ';

export type StatusOSCode =
  | 'ABERTA'
  | 'EM_ANALISE'
  | 'AGUARDANDO_PECA'
  | 'APROVADA'
  | 'PRONTA'
  | 'ENTREGUE';

export type PrioridadeOSCode = 'BAIXA' | 'NORMAL' | 'ALTA' | 'URGENTE';

export type TipoTransacaoCode = 'RECEBER' | 'PAGAR';
export type EscopoFinanceiroCode = 'LOJA' | 'PESSOAL';
export type StatusFinanceiroCode = 'PENDENTE' | 'PAGO';

export type PedidoPecaMotivoCode = 'FALTANTE' | 'PARA_OS';
export type PedidoPecaStatusCode = 'PENDENTE' | 'PEDIDO_FEITO' | 'RECEBIDA';

export type StatusVendaCode = 'CONCLUIDA' | 'PENDENTE' | 'CANCELADA';

export type OsViewMode = 'LISTA' | 'KANBAN';

export type AppRoute =
  | 'dashboard'
  | 'vendas'
  | 'clientes'
  | 'ordens_servico'
  | 'comissoes'
  | 'pedidos_pecas'
  | 'estoque'
  | 'precos'
  | 'financeiro'
  | 'metas'
  | 'config_oficina';

export interface UserSession {
  accessToken: string;
  refreshToken: string;
  userId: string;
  email: string;
  fullName: string;
  expiresAtEpochSec: number;
  role: UserRole;
  workshopOwnerId: string;
}

export interface ClienteDto {
  id?: string | null;
  user_id?: string | null;
  nome: string;
  tipo: TipoCliente | string;
  documento: string;
  telefone: string;
  email: string;
  endereco: string;
  observacoes: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface PecaEstoqueDto {
  id?: string | null;
  user_id?: string | null;
  codigo_sku: string;
  nome: string;
  categoria: string;
  fornecedor: string;
  localizacao: string;
  quantidade: number;
  estoque_minimo: number;
  preco_custo: number;
  preco_venda: number;
  foto_url: string;
  descricao_detalhada: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface OrdemServicoDto {
  id?: string | null;
  user_id?: string | null;
  numero_os: number;
  cliente_id?: string | null;
  cliente_nome: string;
  cliente_telefone: string;
  tecnico_id?: string | null;
  tecnico_nome: string;
  tecnico_email: string;
  criado_por_nome: string;
  comissao_percentual: number;
  categoria_equipamento: string;
  equipamento: string;
  marca_modelo: string;
  numero_serie: string;
  acessorios_entregues: string;
  defeito_relatado: string;
  diagnostico_tecnico: string;
  pecas_utilizadas: string;
  fotos_urls: string[];
  status: StatusOSCode | string;
  prioridade: PrioridadeOSCode | string;
  valor_mao_obra: number;
  valor_pecas: number;
  desconto: number;
  valor_total: number;
  garantia_dias: number;
  data_entrada?: string | null;
  data_saida?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface TransacaoFinanceiraDto {
  id?: string | null;
  user_id?: string | null;
  os_id?: string | null;
  venda_id?: string | null;
  descricao: string;
  categoria: string;
  tipo: TipoTransacaoCode | string;
  escopo: EscopoFinanceiroCode | string;
  status: StatusFinanceiroCode | string;
  valor: number;
  forma_pagamento: string;
  data_vencimento: string;
  data_pagamento?: string | null;
  is_conta_fixa: boolean;
  observacoes: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface VendaItemDto {
  peca_id?: string | null;
  codigo_sku: string;
  nome: string;
  quantidade: number;
  preco_unitario: number;
  subtotal: number;
}

export interface VendaDto {
  id?: string | null;
  user_id?: string | null;
  numero_venda: number;
  cliente_id?: string | null;
  cliente_nome: string;
  cliente_telefone: string;
  vendedor_id?: string | null;
  vendedor_nome: string;
  forma_pagamento: string;
  status: StatusVendaCode | string;
  subtotal: number;
  desconto: number;
  valor_total: number;
  observacoes: string;
  itens: VendaItemDto[];
  data_venda?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface RegistrarVendaInput {
  cliente_id?: string | null;
  cliente_nome: string;
  cliente_telefone: string;
  vendedor_id?: string | null;
  vendedor_nome: string;
  forma_pagamento: string;
  desconto: number;
  pagamento_pendente: boolean;
  observacoes: string;
  itens: Array<{
    peca_id?: string | null;
    codigo_sku: string;
    nome: string;
    quantidade: number;
    preco_unitario: number;
  }>;
}

export interface ConfiguracaoOficinaDto {
  id?: string | null;
  user_id?: string | null;
  nome_loja: string;
  cnpj: string;
  telefone: string;
  email: string;
  endereco: string;
  rodape_os: string;
  garantia_padrao_dias: number;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface FuncionarioDto {
  id?: string | null;
  owner_id: string;
  funcionario_user_id?: string | null;
  nome: string;
  email: string;
  cargo: string;
  comissao_percentual: number;
  ativo: boolean;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface MetaDiariaDto {
  id?: string | null;
  user_id?: string | null;
  meta_mensal: number;
  custos_fixos_mensais: number;
  dias_uteis_mes: number;
  dias_uteis_restantes: number;
  ticket_medio_estimado: number;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface CotacaoPrecoDto {
  id?: string | null;
  user_id?: string | null;
  produto_nome: string;
  codigo_sku: string;
  fornecedor: string;
  preco_unitario: number;
  frete: number;
  prazo_entrega_dias: number;
  observacoes: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export interface PedidoPecaDto {
  id?: string | null;
  user_id?: string | null;
  peca_id?: string | null;
  os_id?: string | null;
  numero_os?: number | null;
  nome_peca: string;
  codigo_sku: string;
  quantidade: number;
  motivo: PedidoPecaMotivoCode | string;
  status: PedidoPecaStatusCode | string;
  prioridade: PrioridadeOSCode | string;
  solicitado_por: string;
  fornecedor_sugerido: string;
  observacoes: string;
  created_at?: string | null;
  updated_at?: string | null;
}

export const STATUS_OS_META: Record<
  StatusOSCode,
  {
    code: StatusOSCode;
    label: string;
    shortLabel: string;
    badgeBg: string;
    badgeText: string;
    barColor: string;
  }
> = {
  ABERTA: {
    code: 'ABERTA',
    label: 'Aberta / Triagem',
    shortLabel: 'Aberta',
    badgeBg: 'bg-sky-100',
    badgeText: 'text-sky-700',
    barColor: '#0284C7'
  },
  EM_ANALISE: {
    code: 'EM_ANALISE',
    label: 'Em Análise',
    shortLabel: 'Análise',
    badgeBg: 'bg-violet-100',
    badgeText: 'text-violet-700',
    barColor: '#7C3AED'
  },
  AGUARDANDO_PECA: {
    code: 'AGUARDANDO_PECA',
    label: 'Aguardando Peça',
    shortLabel: 'Ag. Peça',
    badgeBg: 'bg-amber-100',
    badgeText: 'text-amber-700',
    barColor: '#D97706'
  },
  APROVADA: {
    code: 'APROVADA',
    label: 'Em Reparo',
    shortLabel: 'Em Reparo',
    badgeBg: 'bg-cobalt-light',
    badgeText: 'text-cobalt',
    barColor: '#0052CC'
  },
  PRONTA: {
    code: 'PRONTA',
    label: 'Pronta p/ Retirada',
    shortLabel: 'Pronta',
    badgeBg: 'bg-teal-100',
    badgeText: 'text-teal-700',
    barColor: '#0D9488'
  },
  ENTREGUE: {
    code: 'ENTREGUE',
    label: 'Entregue / Concluída',
    shortLabel: 'Entregue',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-emerald-700',
    barColor: '#059669'
  }
};

export const STATUS_OS_ORDER: StatusOSCode[] = [
  'ABERTA',
  'EM_ANALISE',
  'AGUARDANDO_PECA',
  'APROVADA',
  'PRONTA',
  'ENTREGUE'
];

export function getNextStatusOS(status: string): StatusOSCode | null {
  const idx = STATUS_OS_ORDER.indexOf((status as StatusOSCode) || 'ABERTA');
  if (idx >= 0 && idx < STATUS_OS_ORDER.length - 1) {
    return STATUS_OS_ORDER[idx + 1];
  }
  return null;
}

export const PRIORIDADE_OS_META: Record<
  PrioridadeOSCode,
  { code: PrioridadeOSCode; label: string; badgeBg: string; badgeText: string }
> = {
  BAIXA: { code: 'BAIXA', label: 'Baixa', badgeBg: 'bg-slate-100', badgeText: 'text-slate-600' },
  NORMAL: { code: 'NORMAL', label: 'Normal', badgeBg: 'bg-sky-100', badgeText: 'text-sky-700' },
  ALTA: { code: 'ALTA', label: 'Alta', badgeBg: 'bg-amber-100', badgeText: 'text-amber-700' },
  URGENTE: { code: 'URGENTE', label: 'Urgente', badgeBg: 'bg-red-100', badgeText: 'text-red-700' }
};

export const PEDIDO_PECA_STATUS_META: Record<
  PedidoPecaStatusCode,
  { code: PedidoPecaStatusCode; label: string; badgeBg: string; badgeText: string }
> = {
  PENDENTE: { code: 'PENDENTE', label: 'Pendente', badgeBg: 'bg-red-100', badgeText: 'text-red-700' },
  PEDIDO_FEITO: { code: 'PEDIDO_FEITO', label: 'Pedido Feito', badgeBg: 'bg-amber-100', badgeText: 'text-amber-700' },
  RECEBIDA: { code: 'RECEBIDA', label: 'Recebida', badgeBg: 'bg-emerald-100', badgeText: 'text-emerald-700' }
};

export const PEDIDO_PECA_MOTIVO_META: Record<
  PedidoPecaMotivoCode,
  { code: PedidoPecaMotivoCode; label: string }
> = {
  FALTANTE: { code: 'FALTANTE', label: 'Falta no Estoque' },
  PARA_OS: { code: 'PARA_OS', label: 'P/ Concluir Serviço (OS)' }
};

export const STATUS_VENDA_META: Record<
  StatusVendaCode,
  { code: StatusVendaCode; label: string; badgeBg: string; badgeText: string }
> = {
  CONCLUIDA: {
    code: 'CONCLUIDA',
    label: 'Concluída',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-emerald-700'
  },
  PENDENTE: {
    code: 'PENDENTE',
    label: 'A Receber',
    badgeBg: 'bg-amber-100',
    badgeText: 'text-amber-700'
  },
  CANCELADA: {
    code: 'CANCELADA',
    label: 'Cancelada',
    badgeBg: 'bg-red-100',
    badgeText: 'text-red-700'
  }
};

export const PAYMENT_METHODS = [
  'PIX',
  'Dinheiro',
  'Cartão de Débito',
  'Cartão de Crédito',
  'Transferência / Boleto',
  'Crediário / Fiado'
];

export const EQUIPMENT_CATEGORIES = [
  'Eletrônica Geral',
  'CFTV / Câmeras & DVR',
  'Alarme / Cerca Elétrica',
  'Automatizador / Portão',
  'Nobreak / Fonte',
  'Controle de Acesso'
];

export const PART_CATEGORIES = [
  'Componentes Eletrônicos',
  'CFTV & Cabos',
  'Alarmes & Sensores',
  'Fontes & Baterias',
  'Automatizadores'
];

export const DEFAULT_CONFIG_OFICINA: ConfiguracaoOficinaDto = {
  nome_loja: 'RTerp Eletrônica & Segurança',
  cnpj: '',
  telefone: '',
  email: '',
  endereco: '',
  rodape_os:
    'Equipamentos não retirados em até 90 dias após aviso estarão sujeitos à taxa de estadia/descarte.',
  garantia_padrao_dias: 90
};

export const DEFAULT_META_DIARIA: MetaDiariaDto = {
  meta_mensal: 15000,
  custos_fixos_mensais: 3500,
  dias_uteis_mes: 22,
  dias_uteis_restantes: 15,
  ticket_medio_estimado: 250
};

export function isContaFixaEfetiva(tx: TransacaoFinanceiraDto): boolean {
  const cat = (tx.categoria || '').toLowerCase();
  return (
    Boolean(tx.is_conta_fixa) ||
    cat.includes('aluguel') ||
    cat.includes('fixa') ||
    cat.includes('moradia / contas')
  );
}

export function isEstoqueBaixo(peca: PecaEstoqueDto): boolean {
  return peca.quantidade <= peca.estoque_minimo;
}
