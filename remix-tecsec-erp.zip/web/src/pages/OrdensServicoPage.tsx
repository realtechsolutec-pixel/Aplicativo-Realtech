import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Camera,
  ChevronRight,
  Columns3,
  DollarSign,
  Edit3,
  List,
  MessageCircle,
  Plus,
  Printer,
  Search,
  ShoppingCart,
  Trash2,
  UserCheck,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { PhotoLightbox } from '../components/PhotoLightbox';
import { ReceiptModal } from '../components/ReceiptModal';
import { useWorkshop } from '../context/WorkshopContext';
import {
  ClienteDto,
  EQUIPMENT_CATEGORIES,
  FuncionarioDto,
  getNextStatusOS,
  OrdemServicoDto,
  PedidoPecaDto,
  PRIORIDADE_OS_META,
  PrioridadeOSCode,
  STATUS_OS_META,
  STATUS_OS_ORDER,
  StatusOSCode
} from '../types/models';
import { diasSemConclusao } from '../utils/alerts';
import { calculateGanho, findFuncionarioForSession } from '../utils/commission';
import {
  formatCurrency,
  formatDateTimeBr,
  formatPercent,
  nowIsoTimestamp,
  parseDoubleInput
} from '../utils/formatters';
import {
  CompressionPresetCode,
  IMAGE_COMPRESSION_PRESETS
} from '../utils/imageCompressor';
import {
  buildOsWhatsAppMessage,
  buildWarrantyWhatsAppMessage,
  openWhatsAppWeb
} from '../utils/receipt';
import { PedidoPecaFormModal } from './PedidosPecasPage';

export const OrdensServicoPage: React.FC = () => {
  const {
    session,
    isAdmin,
    ordens,
    clientes,
    funcionarios,
    configuracaoOficina,
    osViewMode,
    setOsViewMode,
    alerts,
    osOverdue30dFilterRequested,
    clearOsNavRequests,
    isSubmitting,
    saveOrdemServico,
    updateOsStatus,
    deleteOrdemServico,
    lancarOsNoFinanceiro,
    savePedidoPeca
  } = useWorkshop();

  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'TODAS' | StatusOSCode>('TODAS');
  const [onlyOverdue30d, setOnlyOverdue30d] = useState(false);

  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editingOs, setEditingOs] = useState<OrdemServicoDto | null>(null);
  const [receiptOs, setReceiptOs] = useState<OrdemServicoDto | null>(null);
  const [lightboxPhoto, setLightboxPhoto] = useState<{ url: string; caption: string } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<OrdemServicoDto | null>(null);
  const [pedidoTargetOs, setPedidoTargetOs] = useState<OrdemServicoDto | null>(null);

  useEffect(() => {
    if (osOverdue30dFilterRequested) {
      setOnlyOverdue30d(true);
      setStatusFilter('TODAS');
      clearOsNavRequests();
    }
  }, [clearOsNavRequests, osOverdue30dFilterRequested]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ordens.filter((os) => {
      if (onlyOverdue30d && !(os.status !== 'ENTREGUE' && diasSemConclusao(os) > 30)) {
        return false;
      }
      if (statusFilter !== 'TODAS' && os.status !== statusFilter) return false;
      if (!q) return true;
      return (
        String(os.numero_os).includes(q) ||
        os.cliente_nome.toLowerCase().includes(q) ||
        os.equipamento.toLowerCase().includes(q) ||
        os.marca_modelo.toLowerCase().includes(q) ||
        os.tecnico_nome.toLowerCase().includes(q)
      );
    });
  }, [onlyOverdue30d, ordens, query, statusFilter]);

  const openNewOs = () => {
    const matchingFunc = findFuncionarioForSession(session, funcionarios);
    setEditingOs({
      numero_os: 0,
      cliente_id: null,
      cliente_nome: '',
      cliente_telefone: '',
      tecnico_id: matchingFunc?.id ?? null,
      tecnico_nome: matchingFunc?.nome ?? session?.fullName ?? '',
      tecnico_email: matchingFunc?.email ?? session?.email ?? '',
      criado_por_nome: session?.fullName ?? '',
      comissao_percentual: matchingFunc?.comissao_percentual ?? 0,
      categoria_equipamento: EQUIPMENT_CATEGORIES[0],
      equipamento: '',
      marca_modelo: '',
      numero_serie: '',
      acessorios_entregues: '',
      defeito_relatado: '',
      diagnostico_tecnico: '',
      pecas_utilizadas: '',
      fotos_urls: [],
      status: 'ABERTA',
      prioridade: 'NORMAL',
      valor_mao_obra: 0,
      valor_pecas: 0,
      desconto: 0,
      valor_total: 0,
      garantia_dias: configuracaoOficina.garantia_padrao_dias || 90,
      data_entrada: nowIsoTimestamp(),
      data_saida: null
    });
    setFormModalOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Alert Banner for +30d Open OS */}
      {alerts.ordensMais30Dias.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5 text-amber-950">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs sm:text-sm font-bold">
                {alerts.ordensMais30Dias.length} OS com mais de 30 dias sem conclusão
              </p>
              <p className="text-xs text-amber-800">
                Verifique pendências de aprovação, peças ou retirada com o cliente.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOnlyOverdue30d((prev) => !prev)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors ${
              onlyOverdue30d
                ? 'bg-amber-700 text-white'
                : 'bg-white border border-amber-300 text-amber-900 hover:bg-amber-100'
            }`}
          >
            {onlyOverdue30d ? 'Mostrando +30d (Limpar)' : 'Filtrar +30d Abertas'}
          </button>
        </div>
      )}

      {/* Search & View Switch */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar Nº OS, cliente, equipamento ou técnico..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-slate-200/70 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setOsViewMode('LISTA')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                osViewMode === 'LISTA' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              Lista
            </button>
            <button
              type="button"
              onClick={() => setOsViewMode('KANBAN')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                osViewMode === 'KANBAN' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              <Columns3 className="w-3.5 h-3.5" />
              Kanban
            </button>
          </div>

          <button
            type="button"
            onClick={openNewOs}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            Nova OS
          </button>
        </div>
      </div>

      {/* Status Filter Chips */}
      {osViewMode === 'LISTA' && (
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => {
              setStatusFilter('TODAS');
              setOnlyOverdue30d(false);
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === 'TODAS' && !onlyOverdue30d
                ? 'bg-bench-navy text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            Todas ({ordens.length})
          </button>
          {STATUS_OS_ORDER.map((code) => {
            const meta = STATUS_OS_META[code];
            const count = ordens.filter((o) => o.status === code).length;
            return (
              <button
                key={code}
                type="button"
                onClick={() => {
                  setStatusFilter(code);
                  setOnlyOverdue30d(false);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  statusFilter === code
                    ? 'bg-cobalt text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {meta.shortLabel} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* Content */}
      {osViewMode === 'KANBAN' ? (
        <div className="overflow-x-auto pb-4">
          <div className="grid grid-cols-6 gap-4 min-w-[1200px]">
            {STATUS_OS_ORDER.map((code) => {
              const meta = STATUS_OS_META[code];
              const colOrdens = filtered.filter((o) => o.status === code);
              const nextStatus = getNextStatusOS(code);
              return (
                <div
                  key={code}
                  className="bg-slate-100/90 border border-slate-200 rounded-2xl p-3 flex flex-col gap-3 min-h-[420px]"
                >
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-bold text-slate-800">{meta.shortLabel}</span>
                    <span className="font-mono-num text-[11px] font-bold px-2 py-0.5 rounded-full bg-white text-slate-700 border border-slate-200">
                      {colOrdens.length}
                    </span>
                  </div>
                  <div className="space-y-2.5">
                    {colOrdens.map((os) => {
                      const days = diasSemConclusao(os);
                      return (
                        <div
                          key={os.id || os.numero_os}
                          className="bg-white border border-slate-200 rounded-xl p-3 shadow-sm space-y-2"
                        >
                          <div className="flex items-center justify-between gap-1">
                            <span className="font-mono-num text-xs font-bold text-cobalt">
                              #{os.numero_os}
                            </span>
                            {days > 30 && (
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                                +{days}d
                              </span>
                            )}
                          </div>
                          <div className="text-xs font-bold text-slate-900 line-clamp-2">
                            {os.equipamento}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {os.cliente_nome}
                          </div>
                          {os.tecnico_nome && (
                            <div className="text-[11px] text-cobalt font-medium truncate">
                              Téc: {os.tecnico_nome}
                            </div>
                          )}
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-1">
                            <span className="font-mono-num text-xs font-bold text-slate-900">
                              {formatCurrency(os.valor_total)}
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingOs({ ...os });
                                  setFormModalOpen(true);
                                }}
                                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600"
                                title="Editar OS"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              {nextStatus && (
                                <button
                                  type="button"
                                  onClick={() => updateOsStatus(os, nextStatus)}
                                  className="p-1.5 rounded-lg bg-cobalt-light text-cobalt hover:bg-cobalt hover:text-white transition-colors"
                                  title={`Avançar para ${STATUS_OS_META[nextStatus].shortLabel}`}
                                >
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
          Nenhuma Ordem de Serviço encontrada com os filtros atuais.
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((os) => {
            const stMeta =
              STATUS_OS_META[(os.status as StatusOSCode) || 'ABERTA'] ?? STATUS_OS_META.ABERTA;
            const prMeta =
              PRIORIDADE_OS_META[(os.prioridade as PrioridadeOSCode) || 'NORMAL'] ??
              PRIORIDADE_OS_META.NORMAL;
            const daysOpen = diasSemConclusao(os);
            const comissaoVal = calculateGanho(os.valor_mao_obra, os.comissao_percentual);

            return (
              <div
                key={os.id || os.numero_os}
                className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono-num text-sm font-bold text-cobalt">
                        OS #{os.numero_os}
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${stMeta.badgeBg} ${stMeta.badgeText}`}
                      >
                        {stMeta.label}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${prMeta.badgeBg} ${prMeta.badgeText}`}
                      >
                        {prMeta.label}
                      </span>
                      {daysOpen > 30 && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700">
                          {daysOpen} dias aberta
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-slate-900">
                      {os.categoria_equipamento} — {os.equipamento}
                      {os.marca_modelo ? ` (${os.marca_modelo})` : ''}
                    </h3>

                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-600">
                      <span>
                        <strong>Cliente:</strong> {os.cliente_nome}
                        {os.cliente_telefone ? ` (${os.cliente_telefone})` : ''}
                      </span>
                      <span>
                        <strong>Entrada:</strong> {formatDateTimeBr(os.data_entrada)}
                      </span>
                      {os.tecnico_nome && (
                        <span className="inline-flex items-center gap-1 text-cobalt font-semibold">
                          <UserCheck className="w-3.5 h-3.5" />
                          Técnico Resp.: {os.tecnico_nome}
                          {os.comissao_percentual > 0 &&
                            ` (${formatPercent(os.comissao_percentual)}% = ${formatCurrency(
                              comissaoVal
                            )})`}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-[11px] uppercase font-semibold text-slate-500">
                      Valor Total
                    </div>
                    <div className="font-mono-num text-xl font-bold text-slate-900">
                      {formatCurrency(os.valor_total)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      M.O: {formatCurrency(os.valor_mao_obra)} • Peças:{' '}
                      {formatCurrency(os.valor_pecas)}
                    </div>
                  </div>
                </div>

                {os.defeito_relatado && (
                  <p className="text-xs text-slate-700 bg-slate-50 rounded-xl px-3 py-2 border border-slate-100">
                    <strong>Defeito:</strong> {os.defeito_relatado}
                    {os.diagnostico_tecnico ? ` • Diagnóstico: ${os.diagnostico_tecnico}` : ''}
                  </p>
                )}

                {/* Photos strip */}
                {os.fotos_urls && os.fotos_urls.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {os.fotos_urls.map((url, idx) => (
                      <button
                        key={`${url}-${idx}`}
                        type="button"
                        onClick={() =>
                          setLightboxPhoto({
                            url,
                            caption: `OS #${os.numero_os} — Foto ${idx + 1}`
                          })
                        }
                        className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 hover:ring-2 hover:ring-cobalt transition-all"
                      >
                        <img
                          src={url}
                          alt={`Foto OS #${os.numero_os}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}

                {/* Actions Footer */}
                <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <label className="text-[11px] font-bold text-slate-500">Status:</label>
                    <select
                      value={os.status}
                      onChange={(e) => updateOsStatus(os, e.target.value as StatusOSCode)}
                      className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-800"
                    >
                      {STATUS_OS_ORDER.map((code) => (
                        <option key={code} value={code}>
                          {STATUS_OS_META[code].label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        openWhatsAppWeb(
                          os.cliente_telefone,
                          buildOsWhatsAppMessage(os, configuracaoOficina)
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 text-xs font-semibold"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      WhatsApp OS
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        openWhatsAppWeb(
                          os.cliente_telefone,
                          buildWarrantyWhatsAppMessage(os, configuracaoOficina)
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-sky-50 border border-sky-200 text-sky-700 hover:bg-sky-100 text-xs font-semibold"
                    >
                      Garantia WhatsApp
                    </button>

                    <button
                      type="button"
                      onClick={() => setPedidoTargetOs(os)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      Pedir Peça
                    </button>

                    <button
                      type="button"
                      onClick={() => setReceiptOs(os)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      Comprovante / PDF
                    </button>

                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => lancarOsNoFinanceiro(os)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-cobalt-light text-cobalt hover:bg-cobalt hover:text-white text-xs font-semibold transition-colors"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        Lançar Caixa
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setEditingOs({ ...os });
                        setFormModalOpen(true);
                      }}
                      className="p-1.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                      title="Editar OS"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeleteTarget(os)}
                      className="p-1.5 rounded-xl border border-red-200 text-red-600 hover:bg-red-50"
                      title="Excluir OS"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {formModalOpen && editingOs && (
        <OrdemServicoFormModal
          initial={editingOs}
          clientes={clientes}
          funcionarios={funcionarios}
          submitting={isSubmitting}
          onClose={() => setFormModalOpen(false)}
          onSave={async (payload, files) => {
            const saved = await saveOrdemServico(payload, files);
            if (saved) setFormModalOpen(false);
          }}
        />
      )}

      {pedidoTargetOs && (
        <PedidoPecaFormModal
          initial={{
            os_id: pedidoTargetOs.id ?? null,
            numero_os: pedidoTargetOs.numero_os,
            nome_peca: '',
            codigo_sku: '',
            quantidade: 1,
            motivo: 'PARA_OS',
            status: 'PENDENTE',
            prioridade: pedidoTargetOs.prioridade || 'NORMAL',
            solicitado_por: session?.fullName || '',
            fornecedor_sugerido: '',
            observacoes: `Para OS #${pedidoTargetOs.numero_os} (${pedidoTargetOs.equipamento})`
          }}
          ordens={ordens}
          submitting={isSubmitting}
          onClose={() => setPedidoTargetOs(null)}
          onSave={async (payload: PedidoPecaDto) => {
            const ok = await savePedidoPeca(payload);
            if (ok) setPedidoTargetOs(null);
          }}
        />
      )}

      <ReceiptModal
        os={receiptOs}
        storeConfig={configuracaoOficina}
        onClose={() => setReceiptOs(null)}
      />

      <PhotoLightbox
        url={lightboxPhoto?.url ?? null}
        caption={lightboxPhoto?.caption}
        onClose={() => setLightboxPhoto(null)}
      />

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Excluir Ordem de Serviço"
        message={`Deseja excluir a OS #${deleteTarget?.numero_os ?? ''}?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deleteOrdemServico(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

interface OrdemServicoFormModalProps {
  initial: OrdemServicoDto;
  clientes: ClienteDto[];
  funcionarios: FuncionarioDto[];
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: OrdemServicoDto, localFiles: File[]) => Promise<void>;
}

const OrdemServicoFormModal: React.FC<OrdemServicoFormModalProps> = ({
  initial,
  clientes,
  funcionarios,
  submitting,
  onClose,
  onSave
}) => {
  const { compressionPreset, setCompressionPreset } = useWorkshop();

  const [form, setForm] = useState<OrdemServicoDto>(initial);
  const [maoObraRaw, setMaoObraRaw] = useState(String(initial.valor_mao_obra || ''));
  const [pecasRaw, setPecasRaw] = useState(String(initial.valor_pecas || ''));
  const [descontoRaw, setDescontoRaw] = useState(String(initial.desconto || ''));
  const [comissaoRaw, setComissaoRaw] = useState(String(initial.comissao_percentual || '0'));
  const [localFiles, setLocalFiles] = useState<File[]>([]);

  const maoObraVal = parseDoubleInput(maoObraRaw);
  const pecasVal = parseDoubleInput(pecasRaw);
  const descontoVal = parseDoubleInput(descontoRaw);
  const comissaoPct = Math.min(100, Math.max(0, parseDoubleInput(comissaoRaw)));
  const totalEstimado = Math.max(0, maoObraVal + pecasVal - descontoVal);
  const ganhoPreview = calculateGanho(maoObraVal, comissaoPct);

  const handleSelectCliente = (clienteId: string) => {
    const c = clientes.find((item) => item.id === clienteId);
    if (c) {
      setForm((f) => ({
        ...f,
        cliente_id: c.id ?? null,
        cliente_nome: c.nome,
        cliente_telefone: c.telefone
      }));
    } else {
      setForm((f) => ({ ...f, cliente_id: null }));
    }
  };

  const handleSelectFuncionario = (funcId: string) => {
    const fn = funcionarios.find((item) => item.id === funcId);
    if (fn) {
      setForm((f) => ({
        ...f,
        tecnico_id: fn.id ?? null,
        tecnico_nome: fn.nome,
        tecnico_email: fn.email,
        comissao_percentual: fn.comissao_percentual
      }));
      setComissaoRaw(String(fn.comissao_percentual));
    }
  };

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = Array.from(e.target.files ?? []);
    if (picked.length > 0) {
      setLocalFiles((prev) => [...prev, ...picked]);
    }
    e.target.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.cliente_nome.trim() || !form.equipamento.trim() || !form.defeito_relatado.trim()) {
      return;
    }
    await onSave(
      {
        ...form,
        valor_mao_obra: maoObraVal,
        valor_pecas: pecasVal,
        desconto: descontoVal,
        valor_total: totalEstimado,
        comissao_percentual: comissaoPct
      },
      localFiles
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-3xl bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold">
              {form.id ? `Editar OS #${form.numero_os}` : 'Nova Ordem de Serviço'}
            </h3>
            <p className="text-xs text-slate-300">
              Preencha cliente, técnico responsável, equipamento, fotos WebP e valores.
            </p>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5 overflow-y-auto">
          {/* Cliente */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <h4 className="text-xs font-bold uppercase text-slate-600">Cliente</h4>
            {clientes.length > 0 && (
              <select
                value={form.cliente_id || ''}
                onChange={(e) => handleSelectCliente(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                <option value="">Selecionar cliente cadastrado (opcional)...</option>
                {clientes.map((c) => (
                  <option key={c.id || c.nome} value={c.id || ''}>
                    {c.nome} {c.telefone ? `— ${c.telefone}` : ''}
                  </option>
                ))}
              </select>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nome do Cliente *
                </label>
                <input
                  type="text"
                  required
                  value={form.cliente_nome}
                  onChange={(e) => setForm((f) => ({ ...f, cliente_nome: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Telefone / WhatsApp
                </label>
                <input
                  type="text"
                  value={form.cliente_telefone}
                  onChange={(e) => setForm((f) => ({ ...f, cliente_telefone: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
            </div>
          </div>

          {/* Técnico Responsável & Comissão */}
          <div className="p-4 rounded-2xl bg-cobalt-light/40 border border-cobalt/20 space-y-3">
            <h4 className="text-xs font-bold uppercase text-cobalt-ink">
              Técnico / Funcionário Responsável
            </h4>
            {funcionarios.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {funcionarios
                  .filter((fn) => fn.ativo)
                  .map((fn) => (
                    <button
                      key={fn.id || fn.email}
                      type="button"
                      onClick={() => fn.id && handleSelectFuncionario(fn.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
                        form.tecnico_id === fn.id ||
                        form.tecnico_nome.toLowerCase() === fn.nome.toLowerCase()
                          ? 'bg-cobalt text-white border-cobalt'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {fn.nome} ({fn.cargo} • {formatPercent(fn.comissao_percentual)}%)
                    </button>
                  ))}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nome do Técnico Responsável
                </label>
                <input
                  type="text"
                  value={form.tecnico_nome}
                  onChange={(e) => setForm((f) => ({ ...f, tecnico_nome: e.target.value }))}
                  placeholder="Nome do técnico"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Comissão M.O (%)
                </label>
                <input
                  type="text"
                  value={comissaoRaw}
                  onChange={(e) => setComissaoRaw(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-mono-num text-sm"
                />
              </div>
            </div>
            <div className="text-xs text-cobalt-ink font-semibold flex items-center gap-1.5">
              <ArrowRight className="w-3.5 h-3.5" />
              Ganho estimado do técnico nesta OS: {formatCurrency(ganhoPreview)} (
              {formatPercent(comissaoPct)}% de {formatCurrency(maoObraVal)})
            </div>
          </div>

          {/* Equipamento */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-700">
              Categoria do Equipamento
            </label>
            <div className="flex flex-wrap gap-1.5">
              {EQUIPMENT_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, categoria_equipamento: cat }))}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border ${
                    form.categoria_equipamento === cat
                      ? 'bg-bench-navy text-white border-bench-navy'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Equipamento *
                </label>
                <input
                  type="text"
                  required
                  value={form.equipamento}
                  onChange={(e) => setForm((f) => ({ ...f, equipamento: e.target.value }))}
                  placeholder="Ex: DVR Intelbras 8 canais / Placa Portão"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Marca / Modelo
                </label>
                <input
                  type="text"
                  value={form.marca_modelo}
                  onChange={(e) => setForm((f) => ({ ...f, marca_modelo: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nº de Série
                </label>
                <input
                  type="text"
                  value={form.numero_serie}
                  onChange={(e) => setForm((f) => ({ ...f, numero_serie: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Acessórios Entregues
                </label>
                <input
                  type="text"
                  value={form.acessorios_entregues}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, acessorios_entregues: e.target.value }))
                  }
                  placeholder="Fonte, controle, cabos..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Defeito Relatado *
              </label>
              <textarea
                rows={2}
                required
                value={form.defeito_relatado}
                onChange={(e) => setForm((f) => ({ ...f, defeito_relatado: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Diagnóstico / Serviço Executado
              </label>
              <textarea
                rows={2}
                value={form.diagnostico_tecnico}
                onChange={(e) => setForm((f) => ({ ...f, diagnostico_tecnico: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Peças Utilizadas
              </label>
              <input
                type="text"
                value={form.pecas_utilizadas}
                onChange={(e) => setForm((f) => ({ ...f, pecas_utilizadas: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
          </div>

          {/* Fotos com compactacao WebP */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                <Camera className="w-4 h-4 text-cobalt" />
                <span>Fotos da OS (Compactação WebP automática)</span>
              </div>
              <select
                value={compressionPreset}
                onChange={(e) => setCompressionPreset(e.target.value as CompressionPresetCode)}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
              >
                {Object.values(IMAGE_COMPRESSION_PRESETS).map((p) => (
                  <option key={p.code} value={p.code}>
                    {p.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold cursor-pointer">
                <Plus className="w-3.5 h-3.5" />
                Adicionar Fotos
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleFilePick}
                  className="hidden"
                />
              </label>

              {form.fotos_urls?.map((url, idx) => (
                <div
                  key={`${url}-${idx}`}
                  className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-300"
                >
                  <img src={url} alt="Anexo OS" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        fotos_urls: f.fotos_urls.filter((_, i) => i !== idx)
                      }))
                    }
                    className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-red-600 text-white text-[10px] flex items-center justify-center"
                  >
                    ×
                  </button>
                </div>
              ))}

              {localFiles.map((file, idx) => (
                <div
                  key={`${file.name}-${idx}`}
                  className="px-2.5 py-1.5 rounded-xl bg-white border border-cobalt text-xs font-medium text-cobalt flex items-center gap-1.5"
                >
                  <span className="max-w-[120px] truncate">{file.name}</span>
                  <button
                    type="button"
                    onClick={() => setLocalFiles((prev) => prev.filter((_, i) => i !== idx))}
                    className="text-red-600 font-bold"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Status, Prioridade e Valores */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Status</label>
              <select
                value={form.status}
                onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                {STATUS_OS_ORDER.map((code) => (
                  <option key={code} value={code}>
                    {STATUS_OS_META[code].label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Prioridade</label>
              <select
                value={form.prioridade}
                onChange={(e) => setForm((f) => ({ ...f, prioridade: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                {(['BAIXA', 'NORMAL', 'ALTA', 'URGENTE'] as PrioridadeOSCode[]).map((p) => (
                  <option key={p} value={p}>
                    {PRIORIDADE_OS_META[p].label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mão de Obra (R$)
              </label>
              <input
                type="text"
                value={maoObraRaw}
                onChange={(e) => setMaoObraRaw(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Peças (R$)
              </label>
              <input
                type="text"
                value={pecasRaw}
                onChange={(e) => setPecasRaw(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Desconto (R$)
              </label>
              <input
                type="text"
                value={descontoRaw}
                onChange={(e) => setDescontoRaw(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Garantia (dias)
              </label>
              <input
                type="number"
                min={0}
                value={form.garantia_dias}
                onChange={(e) =>
                  setForm((f) => ({ ...f, garantia_dias: Math.max(0, Number(e.target.value) || 0) }))
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-bench-navy text-white flex items-center justify-between">
            <span className="text-xs uppercase font-bold text-slate-300">Total Estimado da OS</span>
            <span className="font-mono-num text-xl font-bold">{formatCurrency(totalEstimado)}</span>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Ordem de Serviço'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
