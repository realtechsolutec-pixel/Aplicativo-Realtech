import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Edit3,
  Plus,
  Trash2,
  Wallet,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { KpiCard } from '../components/KpiCard';
import { useWorkshop } from '../context/WorkshopContext';
import {
  EscopoFinanceiroCode,
  isContaFixaEfetiva,
  StatusFinanceiroCode,
  TipoTransacaoCode,
  TransacaoFinanceiraDto
} from '../types/models';
import { diasEmAtraso } from '../utils/alerts';
import {
  formatCurrency,
  formatDateBr,
  parseDoubleInput,
  todayIsoDate
} from '../utils/formatters';

export const FinanceiroPage: React.FC = () => {
  const {
    transacoes,
    alerts,
    saldoLoja,
    aReceberPendenteLoja,
    aPagarPendenteLoja,
    gastosPessoaisPagos,
    gastosPessoaisPendentes,
    financeContasFixasTabRequested,
    financeOverdue30dFilterRequested,
    clearFinanceNavRequests,
    isSubmitting,
    saveTransacao,
    toggleTransacaoStatus,
    deleteTransacao
  } = useWorkshop();

  const [tab, setTab] = useState<'MOVIMENTACOES' | 'CONTAS_FIXAS'>('MOVIMENTACOES');
  const [escopoFilter, setEscopoFilter] = useState<'TODOS' | EscopoFinanceiroCode>('TODOS');
  const [tipoFilter, setTipoFilter] = useState<'TODOS' | TipoTransacaoCode>('TODOS');
  const [statusFilter, setStatusFilter] = useState<'TODOS' | StatusFinanceiroCode>('TODOS');
  const [onlyOverdue30d, setOnlyOverdue30d] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<TransacaoFinanceiraDto | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<TransacaoFinanceiraDto | null>(null);

  useEffect(() => {
    if (financeContasFixasTabRequested) {
      setTab('CONTAS_FIXAS');
      setOnlyOverdue30d(false);
      clearFinanceNavRequests();
    } else if (financeOverdue30dFilterRequested) {
      setTab('MOVIMENTACOES');
      setOnlyOverdue30d(true);
      setTipoFilter('RECEBER');
      setStatusFilter('PENDENTE');
      clearFinanceNavRequests();
    }
  }, [clearFinanceNavRequests, financeContasFixasTabRequested, financeOverdue30dFilterRequested]);

  const contasFixas = useMemo(() => transacoes.filter(isContaFixaEfetiva), [transacoes]);

  const filteredMovimentacoes = useMemo(() => {
    return transacoes.filter((tx) => {
      if (onlyOverdue30d) {
        return tx.tipo === 'RECEBER' && tx.status === 'PENDENTE' && diasEmAtraso(tx) > 30;
      }
      if (escopoFilter !== 'TODOS' && tx.escopo !== escopoFilter) return false;
      if (tipoFilter !== 'TODOS' && tx.tipo !== tipoFilter) return false;
      if (statusFilter !== 'TODOS' && tx.status !== statusFilter) return false;
      return true;
    });
  }, [escopoFilter, onlyOverdue30d, statusFilter, tipoFilter, transacoes]);

  const openNewTx = (preset?: Partial<TransacaoFinanceiraDto>) => {
    setEditing({
      descricao: '',
      categoria: preset?.is_conta_fixa ? 'Aluguel / Contas Fixas' : 'Serviço / Venda',
      tipo: preset?.is_conta_fixa ? 'PAGAR' : 'RECEBER',
      escopo: 'LOJA',
      status: 'PENDENTE',
      valor: 0,
      forma_pagamento: 'PIX',
      data_vencimento: todayIsoDate(),
      data_pagamento: null,
      is_conta_fixa: false,
      observacoes: '',
      ...preset
    });
    setModalOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* +30d overdue receivables alert */}
      {alerts.contasReceberMais30Dias.length > 0 && (
        <div className="p-4 rounded-2xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5 text-red-900">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs sm:text-sm font-bold">
                {alerts.contasReceberMais30Dias.length} conta(s) a receber com mais de 30 dias em aberto ({formatCurrency(alerts.totalContasReceber30Dias)})
              </p>
              <p className="text-xs text-red-700">
                Realize a cobrança ou dê baixa após o recebimento.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setTab('MOVIMENTACOES');
              setOnlyOverdue30d((prev) => !prev);
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors ${
              onlyOverdue30d
                ? 'bg-red-700 text-white'
                : 'bg-white border border-red-300 text-red-700 hover:bg-red-100'
            }`}
          >
            {onlyOverdue30d ? 'Mostrando +30d (Limpar)' : 'Filtrar +30d sem receber'}
          </button>
        </div>
      )}

      {/* Summary KPIs: Loja vs Pessoal */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Saldo Caixa da Loja"
          value={formatCurrency(saldoLoja)}
          subtitle={`A receber: ${formatCurrency(aReceberPendenteLoja)}`}
          icon={DollarSign}
          accentColor={saldoLoja >= 0 ? 'emerald' : 'red'}
        />
        <KpiCard
          title="Contas a Pagar (Loja)"
          value={formatCurrency(aPagarPendenteLoja)}
          subtitle="Lançamentos pendentes"
          icon={AlertCircle}
          accentColor="amber"
        />
        <KpiCard
          title="Gastos Pessoais (Pagos)"
          value={formatCurrency(gastosPessoaisPagos)}
          subtitle={`Pendente pessoal: ${formatCurrency(gastosPessoaisPendentes)}`}
          icon={Wallet}
          accentColor="violet"
        />
        <KpiCard
          title="Contas Fixas em Atraso"
          value={String(alerts.contasFixasEmAtraso.length)}
          subtitle={formatCurrency(alerts.totalContasFixasEmAtraso)}
          icon={AlertTriangle}
          accentColor={alerts.contasFixasEmAtraso.length > 0 ? 'red' : 'emerald'}
          onClick={() => setTab('CONTAS_FIXAS')}
        />
      </div>

      {/* Tabs + Add button */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-2 p-1 rounded-2xl bg-slate-200/70">
          <button
            type="button"
            onClick={() => setTab('MOVIMENTACOES')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
              tab === 'MOVIMENTACOES' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            Movimentações ({transacoes.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('CONTAS_FIXAS')}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
              tab === 'CONTAS_FIXAS' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
            }`}
          >
            <span>Contas Fixas ({contasFixas.length})</span>
            {alerts.contasFixasEmAtraso.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[10px]">
                {alerts.contasFixasEmAtraso.length}
              </span>
            )}
          </button>
        </div>

        <button
          type="button"
          onClick={() => openNewTx({ is_conta_fixa: tab === 'CONTAS_FIXAS' })}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm"
        >
          <Plus className="w-4 h-4" />
          {tab === 'CONTAS_FIXAS' ? 'Nova Conta Fixa' : 'Novo Lançamento'}
        </button>
      </div>

      {tab === 'CONTAS_FIXAS' && alerts.contasFixasEmAtraso.length > 0 && (
        <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-xs text-red-900 space-y-1">
          <p className="font-bold">
            Atenção: {alerts.contasFixasEmAtraso.length} conta(s) fixa(s) vencida(s) totalizando{' '}
            {formatCurrency(alerts.totalContasFixasEmAtraso)}!
          </p>
        </div>
      )}

      {/* Movimentações Filters */}
      {tab === 'MOVIMENTACOES' && (
        <div className="flex flex-wrap gap-2">
          {(['TODOS', 'LOJA', 'PESSOAL'] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => {
                setEscopoFilter(s);
                setOnlyOverdue30d(false);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                escopoFilter === s && !onlyOverdue30d
                  ? 'bg-bench-navy text-white'
                  : 'bg-white border border-slate-200 text-slate-600'
              }`}
            >
              {s === 'TODOS' ? 'Todos Escopos' : s === 'LOJA' ? 'Oficina / Loja' : 'Pessoal'}
            </button>
          ))}

          {(['TODOS', 'RECEBER', 'PAGAR'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => {
                setTipoFilter(t);
                setOnlyOverdue30d(false);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                tipoFilter === t && !onlyOverdue30d
                  ? 'bg-cobalt text-white'
                  : 'bg-white border border-slate-200 text-slate-600'
              }`}
            >
              {t === 'TODOS' ? 'Entradas & Saídas' : t === 'RECEBER' ? 'A Receber' : 'A Pagar'}
            </button>
          ))}

          {(['TODOS', 'PENDENTE', 'PAGO'] as const).map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => {
                setStatusFilter(st);
                setOnlyOverdue30d(false);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold ${
                statusFilter === st && !onlyOverdue30d
                  ? 'bg-slate-800 text-white'
                  : 'bg-white border border-slate-200 text-slate-600'
              }`}
            >
              {st === 'TODOS' ? 'Todos Status' : st === 'PENDENTE' ? 'Pendente' : 'Pago'}
            </button>
          ))}
        </div>
      )}

      {/* List */}
      <div className="space-y-3">
        {(tab === 'CONTAS_FIXAS' ? contasFixas : filteredMovimentacoes).length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
            Nenhum lançamento encontrado nesta visualização.
          </div>
        ) : (
          (tab === 'CONTAS_FIXAS' ? contasFixas : filteredMovimentacoes).map((tx) => {
            const atraso = diasEmAtraso(tx);
            const isReceber = tx.tipo === 'RECEBER';
            const isPago = tx.status === 'PAGO';
            const isFixedLate = !isPago && !isReceber && isContaFixaEfetiva(tx) && atraso >= 1;
            const isReceber30d = !isPago && isReceber && atraso > 30;

            return (
              <div
                key={tx.id || `${tx.descricao}-${tx.data_vencimento}`}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        tx.escopo === 'LOJA'
                          ? 'bg-cobalt-light text-cobalt'
                          : 'bg-violet-100 text-violet-700'
                      }`}
                    >
                      {tx.escopo}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isReceber
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isReceber ? 'RECEBER' : 'PAGAR'}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isPago ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-800'
                      }`}
                    >
                      {isPago ? 'PAGO' : 'PENDENTE'}
                    </span>
                    {isReceber30d && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-600 text-white">
                        +{atraso}d SEM RECEBER
                      </span>
                    )}
                    {isFixedLate && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-600 text-white">
                        ATRASADA {atraso}d
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-slate-900">{tx.descricao}</h4>
                  <p className="text-xs text-slate-500">
                    {tx.categoria} • {tx.forma_pagamento} • Venc.: {formatDateBr(tx.data_vencimento)}
                    {tx.data_pagamento ? ` • Pago em: ${formatDateBr(tx.data_pagamento)}` : ''}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <div
                    className={`font-mono-num text-base font-bold mr-2 ${
                      isReceber ? 'text-emerald-700' : 'text-red-600'
                    }`}
                  >
                    {isReceber ? '+' : '-'} {formatCurrency(tx.valor)}
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleTransacaoStatus(tx)}
                    className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                      isPago
                        ? 'border border-slate-200 text-slate-700 hover:bg-slate-50'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {isPago ? 'Reabrir' : 'Dar Baixa (Pago)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEditing({ ...tx });
                      setModalOpen(true);
                    }}
                    className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(tx)}
                    className="p-2 rounded-xl border border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {modalOpen && editing && (
        <TransacaoFormModal
          initial={editing}
          submitting={isSubmitting}
          onClose={() => setModalOpen(false)}
          onSave={async (payload) => {
            const ok = await saveTransacao(payload);
            if (ok) setModalOpen(false);
          }}
        />
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Excluir Lançamento"
        message={`Deseja excluir "${deleteTarget?.descricao ?? ''}"?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deleteTransacao(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

const TransacaoFormModal: React.FC<{
  initial: TransacaoFinanceiraDto;
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: TransacaoFinanceiraDto) => Promise<void>;
}> = ({ initial, submitting, onClose, onSave }) => {
  const [form, setForm] = useState<TransacaoFinanceiraDto>(initial);
  const [valorRaw, setValorRaw] = useState(String(initial.valor || ''));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.descricao.trim()) return;
    const status = form.status as StatusFinanceiroCode;
    await onSave({
      ...form,
      valor: parseDoubleInput(valorRaw),
      data_pagamento: status === 'PAGO' ? form.data_pagamento || todayIsoDate() : null
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">
            {form.id ? 'Editar Lançamento' : 'Novo Lançamento Financeiro'}
          </h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div className="grid grid-cols-2 gap-2">
            {(['LOJA', 'PESSOAL'] as EscopoFinanceiroCode[]).map((esc) => (
              <button
                key={esc}
                type="button"
                onClick={() => setForm((f) => ({ ...f, escopo: esc }))}
                className={`py-2 rounded-xl text-xs font-bold border ${
                  form.escopo === esc
                    ? 'bg-cobalt text-white border-cobalt'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                {esc === 'LOJA' ? 'Oficina / Loja' : 'Gasto Pessoal'}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2">
            {(['RECEBER', 'PAGAR'] as TipoTransacaoCode[]).map((tp) => (
              <button
                key={tp}
                type="button"
                onClick={() => setForm((f) => ({ ...f, tipo: tp }))}
                className={`py-2 rounded-xl text-xs font-bold border ${
                  form.tipo === tp
                    ? 'bg-bench-navy text-white border-bench-navy'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                {tp === 'RECEBER' ? 'Entrada / A Receber' : 'Saída / A Pagar'}
              </button>
            ))}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Descrição *</label>
            <input
              type="text"
              required
              value={form.descricao}
              onChange={(e) => setForm((f) => ({ ...f, descricao: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Valor (R$)</label>
              <input
                type="text"
                required
                value={valorRaw}
                onChange={(e) => setValorRaw(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Vencimento
              </label>
              <input
                type="date"
                value={form.data_vencimento}
                onChange={(e) => setForm((f) => ({ ...f, data_vencimento: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Categoria</label>
              <input
                type="text"
                value={form.categoria}
                onChange={(e) => setForm((f) => ({ ...f, categoria: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Forma de Pagamento
              </label>
              <select
                value={form.forma_pagamento}
                onChange={(e) => setForm((f) => ({ ...f, forma_pagamento: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                {['PIX', 'Dinheiro', 'Cartão Crédito', 'Cartão Débito', 'Boleto', 'Transferência'].map(
                  (m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  )
                )}
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={form.is_conta_fixa}
                onChange={(e) => setForm((f) => ({ ...f, is_conta_fixa: e.target.checked }))}
                className="rounded border-slate-300 text-cobalt"
              />
              Conta Fixa Mensal (alerta automático se vencer)
            </label>

            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={form.status === 'PAGO'}
                onChange={(e) =>
                  setForm((f) => ({ ...f, status: e.target.checked ? 'PAGO' : 'PENDENTE' }))
                }
                className="rounded border-slate-300 text-emerald-600"
              />
              Já está Pago / Recebido
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Lançamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
