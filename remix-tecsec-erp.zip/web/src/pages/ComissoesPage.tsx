import React, { useMemo, useState } from 'react';
import {
  Award,
  CheckCircle2,
  ClipboardList,
  DollarSign,
  Edit3,
  Filter,
  TrendingUp,
  UserCheck,
  X
} from 'lucide-react';
import { KpiCard } from '../components/KpiCard';
import { useWorkshop } from '../context/WorkshopContext';
import { FuncionarioDto, STATUS_OS_META, StatusOSCode } from '../types/models';
import {
  buildCommissionBreakdown,
  buildTeamPerformance,
  filterOrdensForEmployee,
  findFuncionarioForSession,
  TechnicianPerformanceSummary
} from '../utils/commission';
import { formatCurrency, formatPercent, parseDoubleInput } from '../utils/formatters';

export const ComissoesPage: React.FC = () => {
  const {
    session,
    isAdmin,
    ordens,
    funcionarios,
    isSubmitting,
    updateFuncionarioPerfil
  } = useWorkshop();

  const [selectedTechKey, setSelectedTechKey] = useState<string>('TODOS');
  const [statusFilter, setStatusFilter] = useState<'TODAS' | 'FINALIZADAS' | 'EM_ABERTO'>('TODAS');
  const [editingFunc, setEditingFunc] = useState<FuncionarioDto | null>(null);

  const matchingFunc = useMemo(
    () => findFuncionarioForSession(session, funcionarios),
    [funcionarios, session]
  );

  const teamPerformance = useMemo(
    () => (isAdmin ? buildTeamPerformance(ordens, funcionarios) : []),
    [funcionarios, isAdmin, ordens]
  );

  // Employee View
  if (!isAdmin) {
    const myOrders = session
      ? filterOrdensForEmployee(ordens, matchingFunc, session.fullName, session.email)
      : [];
    const breakdowns = myOrders.map((os) => buildCommissionBreakdown(os, funcionarios));
    const finalizadas = breakdowns.filter((b) => b.isFinalizada);
    const emAberto = breakdowns.filter((b) => !b.isFinalizada);
    const ganhoConfirmado = finalizadas.reduce((s, b) => s + b.ganhoTecnico, 0);
    const ganhoPrevisto = emAberto.reduce((s, b) => s + b.ganhoTecnico, 0);
    const totalGerado = finalizadas.reduce((s, b) => s + b.valorGeradoLoja, 0);
    const myPct = matchingFunc?.comissao_percentual ?? breakdowns[0]?.percentApplied ?? 0;

    const visibleBreakdowns = breakdowns.filter((b) => {
      if (statusFilter === 'FINALIZADAS') return b.isFinalizada;
      if (statusFilter === 'EM_ABERTO') return !b.isFinalizada;
      return true;
    });

    return (
      <div className="space-y-5">
        <div className="bg-bench-dark text-white rounded-2xl p-5 sm:p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              {matchingFunc?.cargo || 'Técnico / Atendente'}
            </span>
            <h2 className="font-display text-xl sm:text-2xl font-bold mt-1">
              {session?.fullName}
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Seu ganho é calculado sobre a mão de obra de cada OS atendida.
            </p>
          </div>
          <div className="px-4 py-3 rounded-2xl bg-cobalt text-white text-center">
            <div className="text-[11px] uppercase font-bold opacity-85">Sua Comissão</div>
            <div className="font-mono-num text-2xl font-bold">{formatPercent(myPct)}%</div>
            <div className="text-[10px] opacity-85">sobre mão de obra</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KpiCard
            title="Ganho Confirmado (Entregues)"
            value={formatCurrency(ganhoConfirmado)}
            subtitle={`${finalizadas.length} OS finalizada(s)`}
            icon={CheckCircle2}
            accentColor="emerald"
          />
          <KpiCard
            title="Ganho Previsto (Em Aberto)"
            value={formatCurrency(ganhoPrevisto)}
            subtitle={`${emAberto.length} OS em andamento`}
            icon={TrendingUp}
            accentColor="cobalt"
          />
          <KpiCard
            title="Total Gerado p/ Loja"
            value={formatCurrency(totalGerado)}
            subtitle="Soma das suas OS finalizadas"
            icon={DollarSign}
            accentColor="cyan"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {(['TODAS', 'FINALIZADAS', 'EM_ABERTO'] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setStatusFilter(f)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors ${
                statusFilter === f
                  ? 'bg-cobalt text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {f === 'TODAS' ? 'Todas' : f === 'FINALIZADAS' ? 'Finalizadas' : 'Em Andamento'}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {visibleBreakdowns.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-sm text-slate-500">
              Nenhuma ordem atribuída neste filtro.
            </div>
          ) : (
            visibleBreakdowns.map((b) => {
              const statusMeta =
                STATUS_OS_META[(b.os.status as StatusOSCode) || 'ABERTA'] ?? STATUS_OS_META.ABERTA;
              return (
                <div
                  key={b.os.id || b.os.numero_os}
                  className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-wrap items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono-num text-xs font-bold text-cobalt">
                        OS #{b.os.numero_os}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusMeta.badgeBg} ${statusMeta.badgeText}`}
                      >
                        {statusMeta.label}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 mt-1">
                      {b.os.equipamento} — {b.os.cliente_nome}
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Mão de obra: {formatCurrency(b.os.valor_mao_obra)} • Percentual:{' '}
                      {formatPercent(b.percentApplied)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-[11px] uppercase font-semibold text-slate-500">
                      {b.isFinalizada ? 'Ganho Confirmado' : 'Ganho Previsto'}
                    </div>
                    <div
                      className={`font-mono-num text-lg font-bold ${
                        b.isFinalizada ? 'text-emerald-700' : 'text-cobalt'
                      }`}
                    >
                      {formatCurrency(b.ganhoTecnico)}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  }

  // Admin View
  const totalLojaGerado = teamPerformance.reduce((s, t) => s + t.totalGeradoLojaFinalizado, 0);
  const totalComissoes = teamPerformance.reduce((s, t) => s + t.comissaoConfirmada, 0);
  const totalLiquidoLoja = teamPerformance.reduce((s, t) => s + t.liquidoLojaConfirmado, 0);
  const totalOsFinalizadas = teamPerformance.reduce((s, t) => s + t.osFinalizadasCount, 0);

  const allBreakdowns = useMemo(() => {
    const selectedSummary = teamPerformance.find((t) => t.key === selectedTechKey);
    const list = selectedSummary
      ? selectedSummary.ordensDoTecnico
      : teamPerformance.flatMap((t) => t.ordensDoTecnico);
    return list
      .filter((b) => {
        if (statusFilter === 'FINALIZADAS') return b.isFinalizada;
        if (statusFilter === 'EM_ABERTO') return !b.isFinalizada;
        return true;
      })
      .sort((a, b) => b.os.numero_os - a.os.numero_os);
  }, [selectedTechKey, statusFilter, teamPerformance]);

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Gerado p/ Loja (Finalizadas)"
          value={formatCurrency(totalLojaGerado)}
          subtitle={`${totalOsFinalizadas} OS concluída(s)`}
          icon={DollarSign}
          accentColor="cobalt"
        />
        <KpiCard
          title="Comissões da Equipe"
          value={formatCurrency(totalComissoes)}
          subtitle="Sobre mão de obra entregue"
          icon={Award}
          accentColor="amber"
        />
        <KpiCard
          title="Líquido da Loja"
          value={formatCurrency(totalLiquidoLoja)}
          subtitle="Gerado menos comissões"
          icon={TrendingUp}
          accentColor="emerald"
        />
        <KpiCard
          title="Equipe Monitorada"
          value={String(teamPerformance.length)}
          subtitle="Técnicos & atendentes ativos"
          icon={UserCheck}
          accentColor="cyan"
        />
      </div>

      {/* Team Cards */}
      <div>
        <h3 className="text-sm font-bold text-slate-900 mb-3">
          Rendimento Individual por Funcionário / Técnico
        </h3>
        {teamPerformance.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-sm text-slate-500">
            Cadastre funcionários em Configurações da Loja ou atribua um técnico nas OS.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {teamPerformance.map((t: TechnicianPerformanceSummary) => (
              <div
                key={t.key}
                className={`bg-white border rounded-2xl p-5 shadow-sm transition-colors ${
                  selectedTechKey === t.key ? 'border-cobalt ring-2 ring-cobalt/15' : 'border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-base font-bold text-slate-900 truncate">{t.nome}</h4>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cobalt-light text-cobalt">
                        {t.cargo} • {formatPercent(t.comissaoPadraoPercent)}%
                      </span>
                    </div>
                    {t.email && <p className="text-xs text-slate-500 mt-0.5 truncate">{t.email}</p>}
                  </div>

                  {t.funcionario && (
                    <button
                      type="button"
                      onClick={() => setEditingFunc(t.funcionario)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 shrink-0"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      Alterar % / Função
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2 mt-4 p-3 rounded-xl bg-slate-50 border border-slate-200 text-center">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-500">OS Geradas</div>
                    <div className="font-mono-num text-sm font-bold text-slate-900">
                      {t.osGeradasCount}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-500">Finalizadas</div>
                    <div className="font-mono-num text-sm font-bold text-emerald-700">
                      {t.osFinalizadasCount}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-500">Em Aberto</div>
                    <div className="font-mono-num text-sm font-bold text-amber-700">
                      {t.osEmAndamentoCount}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 mt-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-sky-50 border border-sky-100">
                    <div className="text-[10px] font-bold text-sky-800 uppercase">Gerado Loja</div>
                    <div className="font-mono-num font-bold text-slate-900 mt-0.5">
                      {formatCurrency(t.totalGeradoLojaFinalizado)}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100">
                    <div className="text-[10px] font-bold text-emerald-800 uppercase">
                      Ganho Func.
                    </div>
                    <div className="font-mono-num font-bold text-emerald-700 mt-0.5">
                      {formatCurrency(t.comissaoConfirmada)}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-100 border border-slate-200">
                    <div className="text-[10px] font-bold text-slate-700 uppercase">Líquido Loja</div>
                    <div className="font-mono-num font-bold text-slate-900 mt-0.5">
                      {formatCurrency(t.liquidoLojaConfirmado)}
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex justify-end">
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedTechKey((prev) => (prev === t.key ? 'TODOS' : t.key))
                    }
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-cobalt hover:text-cobalt-dark"
                  >
                    <Filter className="w-3.5 h-3.5" />
                    {selectedTechKey === t.key ? 'Mostrar Toda Equipe' : 'Filtrar OS deste Técnico'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Detailed OS Breakdown */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-cobalt" />
            <h3 className="text-sm font-bold text-slate-900">
              Detalhamento por Ordem de Serviço ({allBreakdowns.length})
            </h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {(['TODAS', 'FINALIZADAS', 'EM_ABERTO'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setStatusFilter(f)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  statusFilter === f
                    ? 'bg-bench-navy text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f === 'TODAS' ? 'Todas' : f === 'FINALIZADAS' ? 'Finalizadas' : 'Em Aberto'}
              </button>
            ))}
          </div>
        </div>

        {allBreakdowns.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-6">
            Nenhuma OS neste filtro.
          </p>
        ) : (
          <div className="divide-y divide-slate-100">
            {allBreakdowns.map((b) => {
              const statusMeta =
                STATUS_OS_META[(b.os.status as StatusOSCode) || 'ABERTA'] ?? STATUS_OS_META.ABERTA;
              return (
                <div
                  key={`${b.os.id || b.os.numero_os}-${b.tecnicoNome}`}
                  className="py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono-num font-bold text-cobalt">
                        OS #{b.os.numero_os}
                      </span>
                      <span className="font-bold text-slate-900">{b.tecnicoNome}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusMeta.badgeBg} ${statusMeta.badgeText}`}
                      >
                        {statusMeta.shortLabel}
                      </span>
                    </div>
                    <p className="text-slate-500 mt-0.5">
                      {b.os.equipamento} • {b.os.cliente_nome} • Mão de Obra:{' '}
                      {formatCurrency(b.os.valor_mao_obra)} ({formatPercent(b.percentApplied)}%)
                    </p>
                  </div>
                  <div className="text-right font-mono-num">
                    <div className="font-bold text-emerald-700">
                      Func.: {formatCurrency(b.ganhoTecnico)}
                    </div>
                    <div className="text-slate-500">
                      Loja: {formatCurrency(b.valorGeradoLoja)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {editingFunc && (
        <EditComissaoModal
          func={editingFunc}
          submitting={isSubmitting}
          onClose={() => setEditingFunc(null)}
          onSave={async (cargo, pct) => {
            const ok = await updateFuncionarioPerfil(editingFunc, cargo, pct);
            if (ok) setEditingFunc(null);
          }}
        />
      )}
    </div>
  );
};

export const EditComissaoModal: React.FC<{
  func: FuncionarioDto;
  submitting: boolean;
  onClose: () => void;
  onSave: (cargo: string, comissaoPercentual: number) => Promise<void>;
}> = ({ func, submitting, onClose, onSave }) => {
  const [cargo, setCargo] = useState(func.cargo || 'Técnico');
  const [pctRaw, setPctRaw] = useState(String(func.comissao_percentual));

  const presets = ['Técnico', 'Atendente', 'Técnico + Atendente'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const pct = Math.min(100, Math.max(0, parseDoubleInput(pctRaw)));
    await onSave(cargo.trim() || 'Técnico', pct);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold">Alterar Função e Comissão</h3>
            <p className="text-xs text-slate-300">{func.nome}</p>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Função / Cargo
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {presets.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setCargo(p)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                    cargo === p
                      ? 'bg-cobalt text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <input
              type="text"
              required
              value={cargo}
              onChange={(e) => setCargo(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Porcentagem sobre Mão de Obra (%)
            </label>
            <input
              type="text"
              required
              value={pctRaw}
              onChange={(e) => setPctRaw(e.target.value)}
              placeholder="Ex: 60 ou 80"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Ex.: Se a mão de obra da OS for R$ 100,00 e a comissão for {pctRaw || '0'}%, o ganho será{' '}
              <strong>
                {formatCurrency((100 * Math.min(100, Math.max(0, parseDoubleInput(pctRaw)))) / 100)}
              </strong>
              .
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Alteração'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
