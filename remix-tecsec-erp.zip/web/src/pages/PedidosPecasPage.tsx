import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ClipboardCheck,
  Edit3,
  Plus,
  RotateCcw,
  Search,
  ShoppingCart,
  Trash2,
  Truck,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { KpiCard } from '../components/KpiCard';
import { useWorkshop } from '../context/WorkshopContext';
import {
  OrdemServicoDto,
  PecaEstoqueDto,
  PEDIDO_PECA_MOTIVO_META,
  PEDIDO_PECA_STATUS_META,
  PedidoPecaDto,
  PedidoPecaMotivoCode,
  PedidoPecaStatusCode,
  PRIORIDADE_OS_META,
  PrioridadeOSCode
} from '../types/models';

export const PedidosPecasPage: React.FC = () => {
  const {
    pedidosPecas,
    pecasEstoqueBaixo,
    ordens,
    isSubmitting,
    savePedidoPeca,
    updatePedidoPecaStatus,
    deletePedidoPeca
  } = useWorkshop();

  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'TODOS' | PedidoPecaStatusCode>('TODOS');
  const [motivoFilter, setMotivoFilter] = useState<'TODOS' | PedidoPecaMotivoCode>('TODOS');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<PedidoPecaDto | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PedidoPecaDto | null>(null);

  const aguardandoCount = useMemo(
    () => pedidosPecas.filter((p) => p.status === 'PENDENTE').length,
    [pedidosPecas]
  );
  const paraOsCount = useMemo(
    () => pedidosPecas.filter((p) => p.status !== 'RECEBIDA' && p.motivo === 'PARA_OS').length,
    [pedidosPecas]
  );
  const faltantesCount = useMemo(
    () => pedidosPecas.filter((p) => p.status !== 'RECEBIDA' && p.motivo === 'FALTANTE').length,
    [pedidosPecas]
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return pedidosPecas.filter((p) => {
      if (statusFilter !== 'TODOS' && p.status !== statusFilter) return false;
      if (motivoFilter !== 'TODOS' && p.motivo !== motivoFilter) return false;
      if (!q) return true;
      return (
        p.nome_peca.toLowerCase().includes(q) ||
        p.codigo_sku.toLowerCase().includes(q) ||
        p.fornecedor_sugerido.toLowerCase().includes(q) ||
        (p.numero_os ? String(p.numero_os).includes(q) : false)
      );
    });
  }, [motivoFilter, pedidosPecas, query, statusFilter]);

  const openNew = (preset?: Partial<PedidoPecaDto>) => {
    setEditing({
      nome_peca: '',
      codigo_sku: '',
      quantidade: 1,
      motivo: 'FALTANTE',
      status: 'PENDENTE',
      prioridade: 'NORMAL',
      solicitado_por: '',
      fornecedor_sugerido: '',
      observacoes: '',
      ...preset
    });
    setModalOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <KpiCard
          title="Aguardando Pedido"
          value={String(aguardandoCount)}
          subtitle="Itens pendentes de compra"
          icon={ShoppingCart}
          accentColor="red"
        />
        <KpiCard
          title="P/ Concluir OS"
          value={String(paraOsCount)}
          subtitle="Peças necessárias em bancada"
          icon={ClipboardCheck}
          accentColor="amber"
        />
        <KpiCard
          title="Faltantes no Estoque"
          value={String(faltantesCount)}
          subtitle="Reposição de inventário"
          icon={AlertTriangle}
          accentColor="cobalt"
        />
      </div>

      {/* Low Stock Quick Request */}
      {pecasEstoqueBaixo.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2.5">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>
              Peças abaixo do mínimo no estoque ({pecasEstoqueBaixo.length}) — Clique para adicionar à lista de compras:
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {pecasEstoqueBaixo.slice(0, 6).map((peca: PecaEstoqueDto) => (
              <button
                key={peca.id || peca.nome}
                type="button"
                onClick={() =>
                  openNew({
                    peca_id: peca.id ?? null,
                    nome_peca: peca.nome,
                    codigo_sku: peca.codigo_sku,
                    quantidade: Math.max(1, peca.estoque_minimo - peca.quantidade + 1),
                    motivo: 'FALTANTE',
                    fornecedor_sugerido: peca.fornecedor,
                    prioridade: 'ALTA'
                  })
                }
                className="px-3 py-1.5 rounded-xl bg-white border border-amber-300 text-xs font-semibold text-amber-950 hover:bg-amber-100 transition-colors"
              >
                + {peca.nome} (Saldo: {peca.quantidade})
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Search & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por peça, SKU, fornecedor ou Nº OS..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
          />
        </div>

        <button
          type="button"
          onClick={() => openNew()}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          Novo Pedido de Peça
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {(['TODOS', 'PENDENTE', 'PEDIDO_FEITO', 'RECEBIDA'] as const).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              statusFilter === s
                ? 'bg-bench-navy text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {s === 'TODOS' ? 'Todos Status' : PEDIDO_PECA_STATUS_META[s].label}
          </button>
        ))}

        {(['TODOS', 'FALTANTE', 'PARA_OS'] as const).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setMotivoFilter(m)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              motivoFilter === m
                ? 'bg-cobalt text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {m === 'TODOS' ? 'Todos Motivos' : PEDIDO_PECA_MOTIVO_META[m].label}
          </button>
        ))}
      </div>

      {/* Cards */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
          Nenhum pedido de peça encontrado.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((pedido) => {
            const stMeta =
              PEDIDO_PECA_STATUS_META[(pedido.status as PedidoPecaStatusCode) || 'PENDENTE'] ??
              PEDIDO_PECA_STATUS_META.PENDENTE;
            const prMeta =
              PRIORIDADE_OS_META[(pedido.prioridade as PrioridadeOSCode) || 'NORMAL'] ??
              PRIORIDADE_OS_META.NORMAL;
            const motivoLabel =
              PEDIDO_PECA_MOTIVO_META[(pedido.motivo as PedidoPecaMotivoCode) || 'FALTANTE']?.label ??
              pedido.motivo;

            return (
              <div
                key={pedido.id || pedido.nome_peca}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${stMeta.badgeBg} ${stMeta.badgeText}`}
                    >
                      {stMeta.label}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${prMeta.badgeBg} ${prMeta.badgeText}`}
                    >
                      {prMeta.label}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                      {motivoLabel}
                    </span>
                    {pedido.numero_os && (
                      <span className="font-mono-num px-2 py-0.5 rounded-full text-[10px] font-bold bg-cobalt-light text-cobalt">
                        OS #{pedido.numero_os}
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-slate-900">
                    {pedido.nome_peca}{' '}
                    <span className="font-mono-num text-cobalt">({pedido.quantidade} un.)</span>
                  </h4>

                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500">
                    {pedido.codigo_sku && <span>SKU: {pedido.codigo_sku}</span>}
                    {pedido.fornecedor_sugerido && (
                      <span>Fornecedor: {pedido.fornecedor_sugerido}</span>
                    )}
                    {pedido.solicitado_por && <span>Solicitante: {pedido.solicitado_por}</span>}
                  </div>

                  {pedido.observacoes && (
                    <p className="text-xs text-slate-600">{pedido.observacoes}</p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  {pedido.status === 'PENDENTE' && (
                    <button
                      type="button"
                      onClick={() => updatePedidoPecaStatus(pedido, 'PEDIDO_FEITO')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold"
                    >
                      <Truck className="w-3.5 h-3.5" />
                      Pedido Feito
                    </button>
                  )}
                  {pedido.status !== 'RECEBIDA' ? (
                    <button
                      type="button"
                      onClick={() => updatePedidoPecaStatus(pedido, 'RECEBIDA')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Recebida
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => updatePedidoPecaStatus(pedido, 'PENDENTE')}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Reabrir
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setEditing({ ...pedido });
                      setModalOpen(true);
                    }}
                    className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50"
                    aria-label="Editar pedido"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(pedido)}
                    className="p-2 rounded-xl border border-red-200 text-red-600 hover:bg-red-50"
                    aria-label="Excluir pedido"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && editing && (
        <PedidoPecaFormModal
          initial={editing}
          ordens={ordens}
          submitting={isSubmitting}
          onClose={() => setModalOpen(false)}
          onSave={async (payload) => {
            const ok = await savePedidoPeca(payload);
            if (ok) setModalOpen(false);
          }}
        />
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Remover Pedido de Peça"
        message={`Deseja excluir o pedido de "${deleteTarget?.nome_peca ?? ''}"?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deletePedidoPeca(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

export const PedidoPecaFormModal: React.FC<{
  initial: PedidoPecaDto;
  ordens: OrdemServicoDto[];
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: PedidoPecaDto) => Promise<void>;
}> = ({ initial, ordens, submitting, onClose, onSave }) => {
  const [form, setForm] = useState<PedidoPecaDto>(initial);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome_peca.trim()) return;
    await onSave({
      ...form,
      quantidade: Math.max(1, Number(form.quantidade) || 1)
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">
            {form.id ? 'Editar Pedido de Peça' : 'Novo Pedido de Peça'}
          </h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nome da Peça / Componente *
            </label>
            <input
              type="text"
              required
              value={form.nome_peca}
              onChange={(e) => setForm((f) => ({ ...f, nome_peca: e.target.value }))}
              placeholder="Ex: Fonte 12V 5A / MOSFET IRF540N"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Quantidade
              </label>
              <input
                type="number"
                min={1}
                value={form.quantidade}
                onChange={(e) =>
                  setForm((f) => ({ ...f, quantidade: Math.max(1, Number(e.target.value) || 1) }))
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Código / SKU
              </label>
              <input
                type="text"
                value={form.codigo_sku}
                onChange={(e) => setForm((f) => ({ ...f, codigo_sku: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Motivo</label>
            <div className="grid grid-cols-2 gap-2">
              {(['FALTANTE', 'PARA_OS'] as PedidoPecaMotivoCode[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, motivo: m }))}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors ${
                    form.motivo === m
                      ? 'bg-cobalt text-white border-cobalt'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {PEDIDO_PECA_MOTIVO_META[m].label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Vincular a uma Ordem de Serviço (opcional)
            </label>
            <select
              value={form.os_id || ''}
              onChange={(e) => {
                const chosen = ordens.find((o) => o.id === e.target.value);
                setForm((f) => ({
                  ...f,
                  os_id: chosen?.id ?? null,
                  numero_os: chosen?.numero_os ?? null,
                  motivo: chosen ? 'PARA_OS' : f.motivo
                }));
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white"
            >
              <option value="">Sem vínculo com OS específica</option>
              {ordens
                .filter((o) => o.status !== 'ENTREGUE')
                .map((o) => (
                  <option key={o.id || o.numero_os} value={o.id || ''}>
                    OS #{o.numero_os} — {o.cliente_nome} ({o.equipamento})
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Prioridade</label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['BAIXA', 'NORMAL', 'ALTA', 'URGENTE'] as PrioridadeOSCode[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, prioridade: p }))}
                  className={`py-2 rounded-xl text-xs font-bold border ${
                    form.prioridade === p
                      ? 'bg-bench-navy text-white border-bench-navy'
                      : 'bg-white border-slate-200 text-slate-600'
                  }`}
                >
                  {PRIORIDADE_OS_META[p].label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Fornecedor Sugerido
            </label>
            <input
              type="text"
              value={form.fornecedor_sugerido}
              onChange={(e) => setForm((f) => ({ ...f, fornecedor_sugerido: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Observações</label>
            <textarea
              rows={2}
              value={form.observacoes}
              onChange={(e) => setForm((f) => ({ ...f, observacoes: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Pedido'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
