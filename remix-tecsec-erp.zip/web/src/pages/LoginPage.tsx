import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  Lock,
  Mail,
  Settings2,
  ShieldCheck,
  User,
  Wrench,
  X
} from 'lucide-react';
import { useWorkshop } from '../context/WorkshopContext';
import {
  clearRuntimeSupabaseConfig,
  getSupabaseConfig,
  saveRuntimeSupabaseConfig
} from '../services/supabaseClient';
import { UserRole } from '../types/models';

export const LoginPage: React.FC = () => {
  const {
    authLoading,
    authError,
    authInfo,
    clearAuthFeedback,
    signIn,
    signUpOwner,
    signUpEmployee
  } = useWorkshop();

  const [selectedRole, setSelectedRole] = useState<UserRole>('ADMIN');
  const [isSignUp, setIsSignUp] = useState(false);
  const [fullName, setFullName] = useState('');
  const [workshopCode, setWorkshopCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [configModalOpen, setConfigModalOpen] = useState(false);
  const currentCfg = getSupabaseConfig();
  const [cfgUrl, setCfgUrl] = useState(currentCfg.url);
  const [cfgKey, setCfgKey] = useState(currentCfg.anonKey);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignUp) {
      if (selectedRole === 'ADMIN') {
        await signUpOwner(fullName, email, password);
      } else {
        await signUpEmployee(fullName, email, password, workshopCode);
      }
    } else {
      await signIn(email, password, selectedRole);
    }
  };

  const handleSaveCfg = (e: React.FormEvent) => {
    e.preventDefault();
    saveRuntimeSupabaseConfig(cfgUrl, cfgKey);
    setConfigModalOpen(false);
    clearAuthFeedback();
  };

  const handleClearCfg = () => {
    clearRuntimeSupabaseConfig();
    const refreshed = getSupabaseConfig();
    setCfgUrl(refreshed.url);
    setCfgKey(refreshed.anonKey);
    setConfigModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-bench-bg flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Left Hero Brand Panel (Dark Navy + Cobalt + Workshop Hero) */}
        <div className="lg:col-span-5 relative bg-bench-dark text-white p-6 sm:p-8 flex flex-col justify-between overflow-hidden">
          <img
            src="/workshop-hero.jpg"
            alt="Bancada RTerp"
            className="absolute inset-0 w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-bench-dark/95 via-bench-navy/90 to-cobalt-dark/80" />

          <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3.5">
              <img
                src="/rterp-logo.png"
                alt="RTerp Logo"
                className="w-14 h-14 rounded-2xl object-cover border border-white/20 shadow-lg"
              />
              <div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-white">
                  RTerp
                </h1>
                <p className="text-xs text-cyan-300 font-semibold uppercase tracking-wider">
                  Eletrônica & Segurança
                </p>
              </div>
            </div>

            <div className="space-y-2.5">
              <h2 className="font-display text-xl font-bold leading-snug">
                ERP Completo para sua Oficina e Bancada Técnica
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Ordens de Serviço com fotos WebP, controle de comissões por técnico, pedido de peças, estoque, comparativo de preços, financeiro Loja/Pessoal e metas diárias sincronizados em nuvem.
              </p>
            </div>
          </div>

          <div className="relative z-10 mt-8 pt-4 border-t border-white/15 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="inline-flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                {currentCfg.isConfigured
                  ? `Supabase conectado (${currentCfg.source === 'env' ? '.env' : 'navegador'})`
                  : 'Supabase não configurado'}
              </span>
              <button
                type="button"
                onClick={() => {
                  const latest = getSupabaseConfig();
                  setCfgUrl(latest.url);
                  setCfgKey(latest.anonKey);
                  setConfigModalOpen(true);
                }}
                className="inline-flex items-center gap-1 text-cyan-300 hover:text-white font-semibold"
              >
                <Settings2 className="w-3.5 h-3.5" />
                Configurar
              </button>
            </div>
            <p className="text-[11px] text-slate-400">
              Desenvolvido por Realtech Soluções
            </p>
          </div>
        </div>

        {/* Right Form Panel */}
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center">
          {!currentCfg.isConfigured && (
            <div className="mb-5 p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5 text-xs text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  Defina <strong>VITE_SUPABASE_URL</strong> e{' '}
                  <strong>VITE_SUPABASE_ANON_KEY</strong> no <code className="font-mono">.env</code> ou clique em{' '}
                  <strong>Configurar</strong> ao lado.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setConfigModalOpen(true)}
                className="shrink-0 px-2.5 py-1 rounded-lg bg-amber-600 text-white text-xs font-semibold hover:bg-amber-700"
              >
                Configurar
              </button>
            </div>
          )}

          {/* Role Switcher: Proprietario vs Funcionario */}
          <div className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl bg-slate-100 mb-5">
            <button
              type="button"
              onClick={() => {
                setSelectedRole('ADMIN');
                clearAuthFeedback();
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                selectedRole === 'ADMIN'
                  ? 'bg-cobalt text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Proprietário
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedRole('FUNCIONARIO');
                clearAuthFeedback();
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                selectedRole === 'FUNCIONARIO'
                  ? 'bg-bench-navy text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wrench className="w-4 h-4" />
              Funcionário
            </button>
          </div>

          <div className="mb-5">
            <h2 className="font-display text-xl font-bold text-slate-900">
              {isSignUp
                ? selectedRole === 'ADMIN'
                  ? 'Cadastrar Proprietário da Oficina'
                  : 'Vincular Acesso de Funcionário'
                : selectedRole === 'ADMIN'
                ? 'Entrar como Proprietário'
                : 'Entrar como Funcionário'}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {selectedRole === 'ADMIN'
                ? 'Acesso completo a Clientes, OS, Estoque, Equipe, Financeiro Loja/Pessoal e Metas.'
                : 'Acesso operacional (Clientes, OS, Meus Ganhos, Pedido de Peças e Estoque). Financeiro bloqueado.'}
            </p>
          </div>

          {authError && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
              <span>{authError}</span>
            </div>
          )}

          {authInfo && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <span>{authInfo}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nome Completo
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ex: João Silva"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
                  />
                </div>
              </div>
            )}

            {isSignUp && selectedRole === 'FUNCIONARIO' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Código da Oficina (ID do Proprietário)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={workshopCode}
                    onChange={(e) => setWorkshopCode(e.target.value)}
                    placeholder="Cole o UUID informado pelo administrador"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
                  />
                </div>
                <p className="mt-1 text-[11px] text-slate-500">
                  Máximo de 4 acessos de funcionários por oficina.
                </p>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                E-mail
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contato@oficina.com.br"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Senha
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white font-bold text-sm shadow-sm transition-colors disabled:opacity-60"
            >
              {authLoading
                ? 'Conectando...'
                : isSignUp
                ? selectedRole === 'ADMIN'
                  ? 'Criar Conta de Proprietário'
                  : 'Vincular Conta de Funcionário'
                : 'Entrar no RTerp'}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
            <button
              type="button"
              onClick={() => {
                setIsSignUp((prev) => !prev);
                clearAuthFeedback();
              }}
              className="font-semibold text-cobalt hover:text-cobalt-dark"
            >
              {isSignUp
                ? 'Já tem acesso? Voltar para Login'
                : selectedRole === 'ADMIN'
                ? 'Primeira vez? Criar conta de Proprietário'
                : 'Novo técnico/atendente? Vincular acesso'}
            </button>
            <span className="text-slate-400 lg:hidden">Desenvolvido por Realtech Soluções</span>
          </div>
        </div>
      </div>

      {/* Runtime Supabase Config Modal */}
      {configModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Configuração Supabase</h3>
              <button
                type="button"
                onClick={() => setConfigModalOpen(false)}
                className="p-1.5 rounded-lg hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleSaveCfg} className="p-5 space-y-4">
              <p className="text-xs text-slate-600">
                Salve a URL e Anon Key do seu projeto Supabase localmente no navegador (ou defina via <code className="font-mono">.env</code>). Todas as requisições REST usam os headers <code className="font-mono">Accept: application/json</code> e <code className="font-mono">Prefer: return=representation</code>.
              </p>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  SUPABASE_URL
                </label>
                <input
                  type="url"
                  required
                  value={cfgUrl}
                  onChange={(e) => setCfgUrl(e.target.value)}
                  placeholder="https://xyzcompany.supabase.co"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  SUPABASE_ANON_KEY
                </label>
                <textarea
                  required
                  rows={3}
                  value={cfgKey}
                  onChange={(e) => setCfgKey(e.target.value)}
                  placeholder="eyJhbGciOi..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-xs"
                />
              </div>
              <div className="flex items-center justify-between gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleClearCfg}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50"
                >
                  Limpar local
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setConfigModalOpen(false)}
                    className="px-3.5 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-semibold"
                  >
                    Salvar
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
