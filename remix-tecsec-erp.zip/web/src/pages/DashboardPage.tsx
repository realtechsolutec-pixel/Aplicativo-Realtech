import React, { useMemo } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Award,
  CheckCircle2,
  ClipboardList,
  Clock,
  DollarSign,
  Package,
  ShoppingBag,
  ShoppingCart,
  Users,
  Wallet
} from 'lucide-react';
import { FinanceScopeChartCard, OsStatusDistributionChart } from '../components/Charts';
import { KpiCard } from '../components/KpiCard';
import { useWorkshop } from '../context/WorkshopContext';
import { STATUS_OS_META, StatusOSCode } from '../types/models';
import {
  buildCommissionBreakdown,
  buildTeamPerformance,
  filterOrdensForEmployee,
  findFuncionarioForSession
} from '../utils/commission';
import { formatCurrency, formatPercent } from '../utils/formatters';

export const DashboardPage: React.FC = () => {
  const {
    session,
    isAdmin,
    canAccessFinanceiro,
    alerts,
    ordens,
    clientes,
    pecas,
    pecasEstoqueBaixo,
    funcionarios,
    osAbertasCount,
    osProntasCount,
    faturamentoLojaRecebido,
    despesasLojaPagas,
    saldoLoja,
    gastosPessoaisPagos,
    totalVendasHoje,
    totalVendasMes,
    setCurrentRoute,
    requestFinanceOverdue30dFilter,
    requestFinanceContasFixasTab,
    requestOsOverdue30dFilter
  } = useWorkshop();

  const matchingFunc = useMemo(
    () => findFuncionarioForSession(session, funcionarios),
    [funcionarios, session]
  );

  const employeeStats = useMemo(() => {
    if (isAdmin || !session) return null;
    const myOrders = filterOrdensForEmployee(
      ordens,
      matchingFunc,
      session.fullName,
      session.email
    );
    const breakdowns = myOrders.map((os) => buildCommissionBreakdown(os, funcionarios));
    const confirmed = breakdowns
      .filter((b) => b.isFinalizada)
      .reduce((acc, b) => acc + b.ganhoTecnico, 0);
    const predicted = breakdowns
      .filter((b) => !b.isFinalizada)
      .reduce((acc, b) => acc + b.ganhoTecnico, 0);
    return {
      ordersCount: myOrders.length,
      confirmed,
      predicted,
      percent: matchingFunc?.comissao_percentual ?? 0
    };
  }, [funcionarios, isAdmin, matchingFunc, ordens, session]);

  const teamPerformance = useMemo(
    () => (isAdmin ? buildTeamPerformance(ordens, funcionarios) : []),
    [funcionarios, isAdmin, ordens]
  );

  const recentOpenOrdens = useMemo(
    () => ordens.filter((o) => o.status !== 'ENTREGUE').slice(0, 6),
    [ordens]
  );

  return (
    <div className="space-y-6">
      {/* Greeting Banner */}
      <div className="bg-bench-dark text-white rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-white/10 text-cyan-300 text-[11px] font-bold uppercase tracking-wider mb-2">
            {isAdmin ? 'Visão do Proprietário' : 'Painel Operacional'}
          </div>
          <h2 className="font-display text-xl sm:text-2xl font-bold">
            Olá, {session?.fullName || 'Técnico'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            {isAdmin
              ? 'Acompanhe a bancada, equipe, peças em falta e saúde financeira da oficina.'
              : 'Gerencie ordens de serviço, clientes, pedidos de peças e acompanhe seus ganhos.'}
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setCurrentRoute('vendas')}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
          >
            Nova Venda (PDV)
          </button>
          <button
            type="button"
            onClick={() => setCurrentRoute('ordens_servico')}
            className="px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold transition-colors"
          >
            Abrir Ordens de Serviço
          </button>
          <button
            type="button"
            onClick={() => setCurrentRoute('pedidos_pecas')}
            className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-colors"
          >
            Pedir Peças
          </button>
        </div>
      </div>

      {/* Employee restriction notice */}
      {!isAdmin && (
        <div className="p-4 rounded-2xl bg-cyanTech-light border border-cyan-200 flex items-start gap-3 text-xs sm:text-sm text-cyanTech-ink">
          <AlertCircle className="w-5 h-5 text-cyanTech shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Modo Funcionário (Acesso Operacional)</p>
            <p className="text-xs text-slate-700 mt-0.5">
              Você tem acesso a Clientes, Ordens de Serviço, Estoque, Pedido de Peças, Comparador e Meus Ganhos. O módulo Financeiro e Metas ficam restritos ao proprietário.
            </p>
          </div>
        </div>
      )}

      {/* Actionable System Alerts */}
      {alerts.activeAlertsCount > 0 && (
        <div className="space-y-2.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Alertas do Sistema ({alerts.activeAlertsCount})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {canAccessFinanceiro && alerts.contasReceberMais30Dias.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  requestFinanceOverdue30dFilter();
                  setCurrentRoute('financeiro');
                }}
                className="text-left p-4 rounded-2xl bg-red-50 border border-red-200 hover:border-red-300 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <DollarSign className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-red-900">
                      {alerts.contasReceberMais30Dias.length} conta(s) +30 dias sem receber
                    </p>
                    <p className="text-xs text-red-700 mt-0.5">
                      Total em atraso: {formatCurrency(alerts.totalContasReceber30Dias)}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-red-600 shrink-0" />
              </button>
            )}

            {canAccessFinanceiro && alerts.contasFixasEmAtraso.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  requestFinanceContasFixasTab();
                  setCurrentRoute('financeiro');
                }}
                className="text-left p-4 rounded-2xl bg-red-50 border border-red-200 hover:border-red-300 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-red-900">
                      {alerts.contasFixasEmAtraso.length} conta(s) fixa(s) em atraso
                    </p>
                    <p className="text-xs text-red-700 mt-0.5">
                      Total vencido: {formatCurrency(alerts.totalContasFixasEmAtraso)}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-red-600 shrink-0" />
              </button>
            )}

            {alerts.ordensMais30Dias.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  requestOsOverdue30dFilter();
                  setCurrentRoute('ordens_servico');
                }}
                className="text-left p-4 rounded-2xl bg-amber-50 border border-amber-200 hover:border-amber-300 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-amber-950">
                      {alerts.ordensMais30Dias.length} OS aberta(s) há mais de 30 dias
                    </p>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Toque para filtrar as ordens sem conclusão
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-amber-700 shrink-0" />
              </button>
            )}

            {alerts.pedidosPecasPendentes.length > 0 && (
              <button
                type="button"
                onClick={() => setCurrentRoute('pedidos_pecas')}
                className="text-left p-4 rounded-2xl bg-sky-50 border border-sky-200 hover:border-sky-300 transition-colors flex items-center justify-between gap-3"
              >
                <div className="flex items-start gap-3">
                  <ShoppingCart className="w-5 h-5 text-cobalt shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-bold text-sky-950">
                      {alerts.pedidosPecasPendentes.length} pedido(s) de peças em aberto
                    </p>
                    <p className="text-xs text-sky-800 mt-0.5">
                      Peças faltantes ou aguardando compra para OS
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-cobalt shrink-0" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="OS em Aberto"
          value={String(osAbertasCount)}
          subtitle={`${ordens.length} ordens cadastradas`}
          icon={ClipboardList}
          accentColor="cobalt"
          onClick={() => setCurrentRoute('ordens_servico')}
        />
        <KpiCard
          title="Prontas p/ Retirada"
          value={String(osProntasCount)}
          subtitle="Aguardando entrega ao cliente"
          icon={CheckCircle2}
          accentColor="cyan"
          onClick={() => setCurrentRoute('ordens_servico')}
        />

        {isAdmin ? (
          <>
            <KpiCard
              title="Faturamento Loja"
              value={formatCurrency(faturamentoLojaRecebido)}
              subtitle={`Saldo loja: ${formatCurrency(saldoLoja)}`}
              icon={DollarSign}
              accentColor="emerald"
              onClick={() => setCurrentRoute('financeiro')}
            />
            <KpiCard
              title="Gastos Pessoais"
              value={formatCurrency(gastosPessoaisPagos)}
              subtitle="Separado do caixa da oficina"
              icon={Wallet}
              accentColor="amber"
              onClick={() => setCurrentRoute('financeiro')}
            />
          </>
        ) : (
          <>
            <KpiCard
              title="Meus Ganhos (Confirmado)"
              value={formatCurrency(employeeStats?.confirmed ?? 0)}
              subtitle={`Previsto em aberto: ${formatCurrency(employeeStats?.predicted ?? 0)}`}
              icon={Award}
              accentColor="emerald"
              onClick={() => setCurrentRoute('comissoes')}
            />
            <KpiCard
              title="Peças no Estoque"
              value={String(pecas.length)}
              subtitle={
                pecasEstoqueBaixo.length > 0
                  ? `${pecasEstoqueBaixo.length} abaixo do mínimo`
                  : 'Estoque em dia'
              }
              icon={Package}
              accentColor={pecasEstoqueBaixo.length > 0 ? 'red' : 'violet'}
              onClick={() => setCurrentRoute('estoque')}
            />
          </>
        )}
      </div>

      {/* Admin Secondary KPIs */}
      {isAdmin && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KpiCard
            title="Vendas Balcão (Hoje)"
            value={formatCurrency(totalVendasHoje)}
            subtitle={`No mês: ${formatCurrency(totalVendasMes)}`}
            icon={ShoppingBag}
            accentColor="emerald"
            onClick={() => setCurrentRoute('vendas')}
          />
          <KpiCard
            title="Base de Clientes"
            value={String(clientes.length)}
            subtitle="Clientes PF e PJ ativos"
            icon={Users}
            accentColor="cobalt"
            onClick={() => setCurrentRoute('clientes')}
          />
          <KpiCard
            title="Peças em Estoque"
            value={String(pecas.length)}
            subtitle={
              pecasEstoqueBaixo.length > 0
                ? `${pecasEstoqueBaixo.length} item(ns) precisando reposição`
                : 'Todos itens acima do mínimo'
            }
            icon={Package}
            accentColor={pecasEstoqueBaixo.length > 0 ? 'red' : 'emerald'}
            onClick={() => setCurrentRoute('estoque')}
          />
        </div>
      )}

      {/* Charts */}
      <div className={`grid grid-cols-1 ${isAdmin ? 'lg:grid-cols-2' : ''} gap-5`}>
        <OsStatusDistributionChart ordens={ordens} />
        {isAdmin && (
          <FinanceScopeChartCard
            faturamentoLoja={faturamentoLojaRecebido}
            despesasLoja={despesasLojaPagas}
            gastosPessoais={gastosPessoaisPagos}
          />
        )}
      </div>

      {/* Admin Team Rendimento Preview + Recent Open OS */}
      <div className={`grid grid-cols-1 ${isAdmin ? 'lg:grid-cols-2' : ''} gap-5`}>
        {isAdmin && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Rendimento da Equipe</h3>
                <p className="text-xs text-slate-500">
                  Resumo de OS geradas, finalizadas e comissão
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCurrentRoute('comissoes')}
                className="text-xs font-bold text-cobalt hover:text-cobalt-dark"
              >
                Ver completo
              </button>
            </div>
            {teamPerformance.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                Nenhum funcionário ou técnico atribuído em OS ainda.
              </p>
            ) : (
              <div className="space-y-3">
                {teamPerformance.slice(0, 4).map((t) => (
                  <div
                    key={t.key}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-slate-900 truncate">{t.nome}</p>
                      <p className="text-xs text-slate-500">
                        {t.cargo} • {formatPercent(t.comissaoPadraoPercent)}% •{' '}
                        {t.osFinalizadasCount} finalizadas
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono-num text-xs font-bold text-emerald-700">
                        Ganho: {formatCurrency(t.comissaoConfirmada)}
                      </div>
                      <div className="font-mono-num text-[11px] text-slate-500">
                        Loja: {formatCurrency(t.totalGeradoLojaFinalizado)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">OS em Andamento</h3>
              <p className="text-xs text-slate-500">Últimas ordens na bancada</p>
            </div>
            <button
              type="button"
              onClick={() => setCurrentRoute('ordens_servico')}
              className="text-xs font-bold text-cobalt hover:text-cobalt-dark"
            >
              Ver todas
            </button>
          </div>
          {recentOpenOrdens.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              Nenhuma ordem de serviço em aberto no momento.
            </p>
          ) : (
            <div className="space-y-2.5">
              {recentOpenOrdens.map((os) => {
                const statusMeta =
                  STATUS_OS_META[(os.status as StatusOSCode) || 'ABERTA'] ??
                  STATUS_OS_META.ABERTA;
                return (
                  <div
                    key={os.id || os.numero_os}
                    className="p-3 rounded-xl border border-slate-200 hover:border-cobalt/40 transition-colors flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-num text-xs font-bold text-cobalt">
                          #{os.numero_os}
                        </span>
                        <span className="text-sm font-bold text-slate-900 truncate">
                          {os.equipamento}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">
                        {os.cliente_nome}
                        {os.tecnico_nome ? ` • Téc: ${os.tecnico_nome}` : ''}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${statusMeta.badgeBg} ${statusMeta.badgeText}`}
                      >
                        {statusMeta.shortLabel}
                      </span>
                      <div className="font-mono-num text-xs font-bold text-slate-900 mt-1">
                        {formatCurrency(os.valor_total)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
