import React, { useMemo, useState } from 'react';
import {
  Edit3,
  ExternalLink,
  Plus,
  Search,
  Tag,
  Trash2,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useWorkshop } from '../context/WorkshopContext';
import { CotacaoPrecoDto } from '../types/models';
import { formatCurrency, parseDoubleInput } from '../utils/formatters';

export const ComparativoPrecosPage: React.FC = () => {
  const { isAdmin, cotacoes, pecas, isSubmitting, saveCotacao, deleteCotacao } = useWorkshop();

  const [query, setQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<CotacaoPrecoDto | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CotacaoPrecoDto | null>(null);

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = q
      ? cotacoes.filter(
          (c) =>
            c.produto_nome.toLowerCase().includes(q) ||
            c.fornecedor.toLowerCase().includes(q) ||
            c.codigo_sku.toLowerCase().includes(q)
        )
      : cotacoes;

    const map = new Map<string, CotacaoPrecoDto[]>();
    for (const c of filtered) {
      const key = c.produto_nome.trim();
      const arr = map.get(key) ?? [];
      arr.push(c);
      map.set(key, arr);
    }

    return Array.from(map.entries()).map(([produto, items]) => {
      const sorted = [...items].sort(
        (a, b) => a.preco_unitario + a.frete - (b.preco_unitario + b.frete)
      );
      return { produto, items: sorted };
    });
  }, [cotacoes, query]);

  const openNew = (preset?: Partial<CotacaoPrecoDto>) => {
    setEditing({
      produto_nome: '',
      codigo_sku: '',
      fornecedor: '',
      preco_unitario: 0,
      frete: 0,
      prazo_entrega_dias: 3,
      observacoes: '',
      ...preset
    });
    setModalOpen(true);
  };

  const externalTerm = encodeURIComponent(query.trim() || 'componentes eletronicos cftv');

  return (
    <div className="space-y-5">
      {/* Search + External search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Pesquisar peça ou fornecedor..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
          />
        </div>

        <button
          type="button"
          onClick={() => openNew({ produto_nome: query.trim() })}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nova Cotação
        </button>
      </div>

      {/* External Reference Buttons */}
      <div className="flex flex-wrap gap-2">
        <a
          href={`https://lista.mercadolivre.com.br/${externalTerm}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          <ExternalLink className="w-3.5 h-3.5 text-amber-500" />
          Mercado Livre
        </a>
        <a
          href={`https://www.google.com/search?tbm=shop&q=${externalTerm}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          <ExternalLink className="w-3.5 h-3.5 text-cobalt" />
          Google Shopping
        </a>
        <a
          href={`https://www.alldatasheet.com/view.jsp?Searchword=${externalTerm}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
        >
          <ExternalLink className="w-3.5 h-3.5 text-cyanTech" />
          Datasheet
        </a>
      </div>

      {/* Grouped Quotations */}
      {grouped.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
          Nenhuma cotação cadastrada. Adicione preços de fornecedores para comparar o melhor custo total.
        </div>
      ) : (
        <div className="space-y-4">
          {grouped.map(({ produto, items }) => {
            const best = items[0];
            const worst = items[items.length - 1];
            const bestTotal = best.preco_unitario + best.frete;
            const worstTotal = worst.preco_unitario + worst.frete;
            const savings = Math.max(0, worstTotal - bestTotal);

            const stockMatch = pecas.find(
              (p) =>
                p.nome.trim().toLowerCase() === produto.toLowerCase() ||
                (best.codigo_sku &&
                  p.codigo_sku.trim().toLowerCase() === best.codigo_sku.trim().toLowerCase())
            );

            return (
              <div
                key={produto}
                className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Tag className="w-4 h-4 text-cobalt" />
                    <h3 className="text-base font-bold text-slate-900">{produto}</h3>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    {items.length > 1 && savings > 0 && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                        Economia: {formatCurrency(savings)}
                      </span>
                    )}
                    {isAdmin && stockMatch && stockMatch.preco_venda > 0 && (
                      <span className="px-2.5 py-1 rounded-full bg-cobalt-light text-cobalt font-bold">
                        Margem c/ melhor cotação: {formatCurrency(stockMatch.preco_venda - bestTotal)}
                      </span>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  {items.map((item, idx) => {
                    const total = item.preco_unitario + item.frete;
                    const isBest = idx === 0;
                    return (
                      <div
                        key={item.id || `${item.fornecedor}-${idx}`}
                        className={`p-3 rounded-xl border flex flex-wrap items-center justify-between gap-3 ${
                          isBest ? 'bg-emerald-50/70 border-emerald-300' : 'bg-slate-50 border-slate-200'
                        }`}
                      >
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-900">
                              {item.fornecedor}
                            </span>
                            {isBest && (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                                MELHOR PREÇO
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Unit: {formatCurrency(item.preco_unitario)} • Frete:{' '}
                            {formatCurrency(item.frete)} • Prazo: {item.prazo_entrega_dias} dia(s)
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <div className="font-mono-num text-sm font-bold text-slate-900">
                            {formatCurrency(total)}
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setEditing({ ...item });
                              setModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(item)}
                            className="p-1.5 rounded-lg border border-red-200 bg-white text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Reference in Stock */}
      {pecas.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Referência no Seu Estoque</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {pecas.slice(0, 6).map((p) => (
              <div
                key={p.id || p.nome}
                className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">{p.nome}</div>
                  <div className="text-[11px] text-slate-500">
                    Venda: {formatCurrency(p.preco_venda)}
                    {isAdmin && p.preco_custo > 0 ? ` • Custo: ${formatCurrency(p.preco_custo)}` : ''}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    openNew({
                      produto_nome: p.nome,
                      codigo_sku: p.codigo_sku,
                      fornecedor: p.fornecedor
                    })
                  }
                  className="px-2.5 py-1.5 rounded-lg bg-cobalt text-white text-xs font-bold hover:bg-cobalt-dark shrink-0"
                >
                  Cotar
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {modalOpen && editing && (
        <CotacaoFormModal
          initial={editing}
          submitting={isSubmitting}
          onClose={() => setModalOpen(false)}
          onSave={async (payload) => {
            const ok = await saveCotacao(payload);
            if (ok) setModalOpen(false);
          }}
        />
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Remover Cotação"
        message={`Excluir cotação de "${deleteTarget?.fornecedor ?? ''}" para "${
          deleteTarget?.produto_nome ?? ''
        }"?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deleteCotacao(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

const CotacaoFormModal: React.FC<{
  initial: CotacaoPrecoDto;
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: CotacaoPrecoDto) => Promise<void>;
}> = ({ initial, submitting, onClose, onSave }) => {
  const [form, setForm] = useState<CotacaoPrecoDto>(initial);
  const [unitRaw, setUnitRaw] = useState(String(initial.preco_unitario || ''));
  const [freteRaw, setFreteRaw] = useState(String(initial.frete || ''));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.produto_nome.trim() || !form.fornecedor.trim()) return;
    await onSave({
      ...form,
      preco_unitario: parseDoubleInput(unitRaw),
      frete: parseDoubleInput(freteRaw)
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">
            {form.id ? 'Editar Cotação' : 'Nova Cotação de Preço'}
          </h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nome do Produto / Peça *
            </label>
            <input
              type="text"
              required
              value={form.produto_nome}
              onChange={(e) => setForm((f) => ({ ...f, produto_nome: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Fornecedor *
              </label>
              <input
                type="text"
                required
                value={form.fornecedor}
                onChange={(e) => setForm((f) => ({ ...f, fornecedor: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">SKU</label>
              <input
                type="text"
                value={form.codigo_sku}
                onChange={(e) => setForm((f) => ({ ...f, codigo_sku: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
              />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Unitário (R$)
              </label>
              <input
                type="text"
                value={unitRaw}
                onChange={(e) => setUnitRaw(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Frete (R$)</label>
              <input
                type="text"
                value={freteRaw}
                onChange={(e) => setFreteRaw(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Prazo (dias)
              </label>
              <input
                type="number"
                min={0}
                value={form.prazo_entrega_dias}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    prazo_entrega_dias: Math.max(0, Number(e.target.value) || 0)
                  }))
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Observações</label>
            <textarea
              rows={2}
              value={form.observacoes}
              onChange={(e) => setForm((f) => ({ ...f, observacoes: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Cotação'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
