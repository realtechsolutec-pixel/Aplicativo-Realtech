import React, { useMemo, useState } from 'react';
import {
  Ban,
  CheckCircle2,
  CreditCard,
  History,
  MessageCircle,
  Minus,
  Package,
  Plus,
  Receipt,
  Search,
  ShoppingBag,
  ShoppingCart,
  Trash2,
  User
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { KpiCard } from '../components/KpiCard';
import { SaleReceiptModal } from '../components/SaleReceiptModal';
import { useWorkshop } from '../context/WorkshopContext';
import {
  PAYMENT_METHODS,
  PecaEstoqueDto,
  STATUS_VENDA_META,
  StatusVendaCode,
  VendaDto
} from '../types/models';
import { formatCurrency, formatDateTimeBr, parseDoubleInput } from '../utils/formatters';
import { buildSaleWhatsAppMessage, openWhatsAppWeb } from '../utils/receipt';

interface CartItem {
  key: string;
  peca_id: string | null;
  codigo_sku: string;
  nome: string;
  quantidade: number;
  preco_unitario: number;
  maxEstoque: number | null;
}

export const VendasPage: React.FC = () => {
  const {
    session,
    clientes,
    pecas,
    funcionarios,
    vendas,
    configuracaoOficina,
    totalVendasHoje,
    totalVendasMes,
    isSubmitting,
    showToast,
    registrarVenda,
    cancelarVenda
  } = useWorkshop();

  const [activeTab, setActiveTab] = useState<'PDV' | 'HISTORICO'>('PDV');

  // PDV Catalog & Cart
  const [catalogSearch, setCatalogSearch] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [avulsoOpen, setAvulsoOpen] = useState(false);
  const [avulsoNome, setAvulsoNome] = useState('');
  const [avulsoPrecoRaw, setAvulsoPrecoRaw] = useState('');
  const [avulsoQtd, setAvulsoQtd] = useState(1);

  // Checkout fields
  const [selectedClienteId, setSelectedClienteId] = useState<string>('');
  const [clienteNome, setClienteNome] = useState('Consumidor Final');
  const [clienteTelefone, setClienteTelefone] = useState('');
  const [selectedVendedorId, setSelectedVendedorId] = useState<string>('');
  const [vendedorNome, setVendedorNome] = useState(session?.fullName || '');
  const [formaPagamento, setFormaPagamento] = useState<string>('PIX');
  const [descontoRaw, setDescontoRaw] = useState('0');
  const [pagamentoPendente, setPagamentoPendente] = useState(false);
  const [observacoes, setObservacoes] = useState('');

  // History filters & modals
  const [historySearch, setHistorySearch] = useState('');
  const [historyStatus, setHistoryStatus] = useState<'ALL' | StatusVendaCode>('ALL');
  const [receiptTarget, setReceiptTarget] = useState<VendaDto | null>(null);
  const [cancelTarget, setCancelTarget] = useState<VendaDto | null>(null);

  const filteredPecas = useMemo(() => {
    const q = catalogSearch.trim().toLowerCase();
    return pecas.filter(
      (p) =>
        !q ||
        p.nome.toLowerCase().includes(q) ||
        p.codigo_sku.toLowerCase().includes(q) ||
        p.categoria.toLowerCase().includes(q)
    );
  }, [catalogSearch, pecas]);

  const activeSales = useMemo(
    () => vendas.filter((v) => v.status !== 'CANCELADA'),
    [vendas]
  );

  const ticketMedioVendas = useMemo(() => {
    if (!activeSales.length) return 0;
    return activeSales.reduce((sum, v) => sum + (v.valor_total || 0), 0) / activeSales.length;
  }, [activeSales]);

  const filteredVendas = useMemo(() => {
    const q = historySearch.trim().toLowerCase();
    return vendas.filter((v) => {
      if (historyStatus !== 'ALL' && v.status !== historyStatus) return false;
      if (!q) return true;
      const itemsText = (v.itens || []).map((i) => i.nome.toLowerCase()).join(' ');
      return (
        String(v.numero_venda).includes(q) ||
        (v.cliente_nome || '').toLowerCase().includes(q) ||
        (v.vendedor_nome || '').toLowerCase().includes(q) ||
        (v.forma_pagamento || '').toLowerCase().includes(q) ||
        itemsText.includes(q)
      );
    });
  }, [historySearch, historyStatus, vendas]);

  const subtotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.quantidade * item.preco_unitario, 0),
    [cart]
  );
  const desconto = Math.max(0, parseDoubleInput(descontoRaw));
  const totalFinal = Math.max(0, subtotal - desconto);

  const addStockItemToCart = (peca: PecaEstoqueDto) => {
    if (!peca.id) return;
    if (peca.quantidade <= 0) {
      showToast(`"${peca.nome}" está sem saldo em estoque.`, 'error');
      return;
    }
    setCart((prev) => {
      const existing = prev.find((i) => i.peca_id === peca.id);
      if (existing) {
        if (existing.quantidade >= peca.quantidade) {
          showToast(
            `Quantidade máxima em estoque (${peca.quantidade} un) atingida para "${peca.nome}".`,
            'error'
          );
          return prev;
        }
        return prev.map((i) =>
          i.peca_id === peca.id
            ? { ...i, quantidade: i.quantidade + 1, maxEstoque: peca.quantidade }
            : i
        );
      }
      return [
        ...prev,
        {
          key: `stock-${peca.id}`,
          peca_id: peca.id!,
          codigo_sku: peca.codigo_sku || '',
          nome: peca.nome,
          quantidade: 1,
          preco_unitario: peca.preco_venda > 0 ? peca.preco_venda : peca.preco_custo,
          maxEstoque: peca.quantidade
        }
      ];
    });
  };

  const handleAddAvulso = (e: React.FormEvent) => {
    e.preventDefault();
    const preco = Math.max(0, parseDoubleInput(avulsoPrecoRaw));
    if (!avulsoNome.trim() || avulsoQtd <= 0) return;
    setCart((prev) => [
      ...prev,
      {
        key: `avulso-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        peca_id: null,
        codigo_sku: 'AVULSO',
        nome: avulsoNome.trim(),
        quantidade: avulsoQtd,
        preco_unitario: preco,
        maxEstoque: null
      }
    ]);
    setAvulsoNome('');
    setAvulsoPrecoRaw('');
    setAvulsoQtd(1);
    setAvulsoOpen(false);
  };

  const updateCartQty = (key: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.key !== key) return item;
          const next = item.quantidade + delta;
          if (next <= 0) return null;
          if (item.maxEstoque !== null && next > item.maxEstoque) {
            showToast(`Saldo disponível em estoque: ${item.maxEstoque} un.`, 'error');
            return item;
          }
          return { ...item, quantidade: next };
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleSelectCliente = (id: string) => {
    setSelectedClienteId(id);
    if (!id) {
      setClienteNome('Consumidor Final');
      setClienteTelefone('');
      return;
    }
    const found = clientes.find((c) => c.id === id);
    if (found) {
      setClienteNome(found.nome);
      setClienteTelefone(found.telefone || '');
    }
  };

  const handleSelectVendedor = (id: string) => {
    setSelectedVendedorId(id);
    if (!id) {
      setVendedorNome(session?.fullName || '');
      return;
    }
    const found = funcionarios.find((f) => f.id === id);
    if (found) {
      setVendedorNome(found.nome);
    }
  };

  const handleFinalizeSale = async () => {
    if (cart.length === 0) {
      showToast('Adicione pelo menos 1 produto para finalizar a venda.', 'error');
      return;
    }

    const saved = await registrarVenda({
      cliente_id: selectedClienteId || null,
      cliente_nome: clienteNome.trim() || 'Consumidor Final',
      cliente_telefone: clienteTelefone.trim(),
      vendedor_id: selectedVendedorId || null,
      vendedor_nome: vendedorNome.trim() || session?.fullName || '',
      forma_pagamento: formaPagamento,
      desconto,
      pagamento_pendente: pagamentoPendente,
      observacoes: observacoes.trim(),
      itens: cart.map((item) => ({
        peca_id: item.peca_id,
        codigo_sku: item.codigo_sku,
        nome: item.nome,
        quantidade: item.quantidade,
        preco_unitario: item.preco_unitario
      }))
    });

    if (saved) {
      setCart([]);
      setDescontoRaw('0');
      setObservacoes('');
      setPagamentoPendente(false);
      setSelectedClienteId('');
      setClienteNome('Consumidor Final');
      setClienteTelefone('');
      setReceiptTarget(saved);
    }
  };

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Vendas Hoje"
          value={formatCurrency(totalVendasHoje)}
          subtitle="Total faturado no dia"
          icon={ShoppingBag}
          accentColor="emerald"
        />
        <KpiCard
          title="Vendas no Mês"
          value={formatCurrency(totalVendasMes)}
          subtitle="Integrado ao Financeiro"
          icon={CreditCard}
          accentColor="cobalt"
        />
        <KpiCard
          title="Vendas Realizadas"
          value={String(activeSales.length)}
          subtitle={`${vendas.filter((v) => v.status === 'CANCELADA').length} cancelada(s)`}
          icon={Receipt}
          accentColor="cyan"
        />
        <KpiCard
          title="Ticket Médio (Vendas)"
          value={formatCurrency(ticketMedioVendas)}
          subtitle="Por cupom / nota emitida"
          icon={CheckCircle2}
          accentColor="violet"
        />
      </div>

      {/* Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex bg-white border border-slate-200 p-1 rounded-xl shadow-sm">
          <button
            type="button"
            onClick={() => setActiveTab('PDV')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'PDV'
                ? 'bg-cobalt text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            Nova Venda (PDV)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('HISTORICO')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
              activeTab === 'HISTORICO'
                ? 'bg-cobalt text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <History className="w-4 h-4" />
            Histórico & Notas ({vendas.length})
          </button>
        </div>

        <p className="text-xs text-slate-500">
          Baixa automática no Estoque + lançamento no Financeiro + emissão de Nota/Cupom.
        </p>
      </div>

      {activeTab === 'PDV' ? (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
          {/* Left: Product Catalog */}
          <div className="xl:col-span-7 bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Produtos do Estoque</h2>
                <p className="text-xs text-slate-500">
                  Selecione itens para dar baixa automática ao concluir a venda
                </p>
              </div>
              <button
                type="button"
                onClick={() => setAvulsoOpen((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700"
              >
                <Plus className="w-3.5 h-3.5" />
                Item Avulso
              </button>
            </div>

            {avulsoOpen && (
              <form
                onSubmit={handleAddAvulso}
                className="p-3.5 rounded-xl bg-sky-50 border border-sky-200 grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end"
              >
                <div className="sm:col-span-5">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Descrição do Item Avulso *
                  </label>
                  <input
                    type="text"
                    required
                    value={avulsoNome}
                    onChange={(e) => setAvulsoNome(e.target.value)}
                    placeholder="Ex: Cabo HDMI 2m / Instalação rápida"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Qtd</label>
                  <input
                    type="number"
                    min={1}
                    value={avulsoQtd}
                    onChange={(e) => setAvulsoQtd(Math.max(1, Number(e.target.value) || 1))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono-num text-xs"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Valor Unit. (R$)
                  </label>
                  <input
                    type="text"
                    required
                    value={avulsoPrecoRaw}
                    onChange={(e) => setAvulsoPrecoRaw(e.target.value)}
                    placeholder="50,00"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono-num text-xs"
                  />
                </div>
                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    className="w-full px-3 py-2 rounded-lg bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold"
                  >
                    Adicionar
                  </button>
                </div>
              </form>
            )}

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={catalogSearch}
                onChange={(e) => setCatalogSearch(e.target.value)}
                placeholder="Buscar produto por nome, SKU ou categoria..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-cobalt outline-none text-sm"
              />
            </div>

            {filteredPecas.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                <Package className="w-9 h-9 mx-auto text-slate-300 mb-2" />
                Nenhuma peça encontrada no estoque com esse filtro.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[540px] overflow-y-auto pr-1">
                {filteredPecas.map((peca) => {
                  const outOfStock = peca.quantidade <= 0;
                  const unitPrice = peca.preco_venda > 0 ? peca.preco_venda : peca.preco_custo;
                  const inCartQty = cart.find((c) => c.peca_id === peca.id)?.quantidade || 0;
                  return (
                    <div
                      key={peca.id || peca.nome}
                      className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                        outOfStock
                          ? 'bg-slate-50 border-slate-200 opacity-65'
                          : 'bg-white border-slate-200 hover:border-cobalt/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {peca.foto_url ? (
                          <img
                            src={peca.foto_url}
                            alt={peca.nome}
                            className="w-11 h-11 rounded-lg object-cover border border-slate-200 shrink-0"
                          />
                        ) : (
                          <div className="w-11 h-11 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                            <Package className="w-5 h-5 text-slate-400" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {peca.nome}
                          </div>
                          <div className="text-[11px] text-slate-500 truncate">
                            {peca.codigo_sku ? `SKU: ${peca.codigo_sku} • ` : ''}
                            Disp:{' '}
                            <span
                              className={`font-mono-num font-bold ${
                                outOfStock
                                  ? 'text-red-600'
                                  : peca.quantidade <= peca.estoque_minimo
                                  ? 'text-amber-600'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {peca.quantidade} un
                            </span>
                          </div>
                          <div className="font-mono-num text-xs font-bold text-cobalt mt-0.5">
                            {formatCurrency(unitPrice)}
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={outOfStock}
                        onClick={() => addStockItemToCart(peca)}
                        className="relative px-3 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:bg-slate-300 disabled:cursor-not-allowed shrink-0"
                      >
                        {inCartQty > 0 ? `+1 (${inCartQty})` : '+ Vender'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right: Cart & Checkout */}
          <div className="xl:col-span-5 bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-cobalt" />
                <h2 className="text-base font-bold text-slate-900">
                  Carrinho da Venda ({cart.reduce((s, i) => s + i.quantidade, 0)} un)
                </h2>
              </div>
              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={() => setCart([])}
                  className="text-xs font-semibold text-red-600 hover:text-red-700"
                >
                  Limpar
                </button>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="py-8 text-center border border-dashed border-slate-200 rounded-xl text-xs text-slate-500">
                Selecione peças ou adicione itens avulsos ao lado para montar o cupom de venda.
              </div>
            ) : (
              <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div
                    key={item.key}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 truncate">{item.nome}</div>
                      <div className="text-[11px] text-slate-500 font-mono-num">
                        {formatCurrency(item.preco_unitario)} un • Sub:{' '}
                        <span className="font-bold text-slate-800">
                          {formatCurrency(item.quantidade * item.preco_unitario)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => updateCartQty(item.key, -1)}
                        className="w-7 h-7 rounded-lg border border-slate-300 bg-white flex items-center justify-center hover:bg-slate-100"
                        aria-label="Diminuir quantidade"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-7 text-center font-mono-num text-xs font-bold">
                        {item.quantidade}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateCartQty(item.key, 1)}
                        className="w-7 h-7 rounded-lg border border-slate-300 bg-white flex items-center justify-center hover:bg-slate-100"
                        aria-label="Aumentar quantidade"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setCart((p) => p.filter((c) => c.key !== item.key))}
                        className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 ml-1"
                        aria-label="Remover item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Customer & Payment */}
            <div className="space-y-3 pt-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cliente Cadastrado
                  </label>
                  <select
                    value={selectedClienteId}
                    onChange={(e) => handleSelectCliente(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  >
                    <option value="">Consumidor Final (Avulso)</option>
                    {clientes.map((c) => (
                      <option key={c.id || c.nome} value={c.id || ''}>
                        {c.nome}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Vendedor / Atendente
                  </label>
                  <select
                    value={selectedVendedorId}
                    onChange={(e) => handleSelectVendedor(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  >
                    <option value="">{session?.fullName || 'Operador Atual'}</option>
                    {funcionarios
                      .filter((f) => f.ativo)
                      .map((f) => (
                        <option key={f.id || f.email} value={f.id || ''}>
                          {f.nome} ({f.cargo})
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nome na Nota
                  </label>
                  <input
                    type="text"
                    value={clienteNome}
                    onChange={(e) => setClienteNome(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    WhatsApp / Telefone
                  </label>
                  <input
                    type="text"
                    value={clienteTelefone}
                    onChange={(e) => setClienteTelefone(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Forma de Pagamento
                  </label>
                  <select
                    value={formaPagamento}
                    onChange={(e) => setFormaPagamento(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs"
                  >
                    {PAYMENT_METHODS.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Desconto (R$)
                  </label>
                  <input
                    type="text"
                    value={descontoRaw}
                    onChange={(e) => setDescontoRaw(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-xs"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={pagamentoPendente}
                  onChange={(e) => setPagamentoPendente(e.target.checked)}
                  className="rounded border-slate-300 text-cobalt"
                />
                Lançar como "A Receber (Pendente)" no Financeiro (Crediário/Fiado)
              </label>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Observações da Nota (opcional)
                </label>
                <input
                  type="text"
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Ex: Garantia de balcão 90 dias..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                />
              </div>

              {/* Total box */}
              <div className="p-4 rounded-xl bg-bench-navy text-white flex items-center justify-between gap-3">
                <div className="text-xs text-slate-300">
                  <div>Subtotal: {formatCurrency(subtotal)}</div>
                  {desconto > 0 && <div>Desconto: -{formatCurrency(desconto)}</div>}
                </div>
                <div className="text-right">
                  <div className="text-[11px] uppercase text-slate-300">Total da Venda</div>
                  <div className="font-mono-num text-2xl font-bold text-white">
                    {formatCurrency(totalFinal)}
                  </div>
                </div>
              </div>

              <button
                type="button"
                disabled={isSubmitting || cart.length === 0}
                onClick={handleFinalizeSale}
                className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-sm font-bold shadow-sm disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Receipt className="w-4 h-4" />
                {isSubmitting ? 'Registrando venda...' : 'Finalizar Venda & Emitir Nota / Cupom'}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* History Tab */
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                placeholder="Buscar venda por número, cliente, vendedor ou produto..."
                className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-cobalt outline-none text-sm"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {(['ALL', 'CONCLUIDA', 'PENDENTE', 'CANCELADA'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setHistoryStatus(st)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                    historyStatus === st
                      ? 'bg-cobalt text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {st === 'ALL' ? 'Todas' : STATUS_VENDA_META[st].label}
                </button>
              ))}
            </div>
          </div>

          {filteredVendas.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
              Nenhuma venda registrada ainda. Use a aba "Nova Venda (PDV)" para realizar sua primeira venda.
            </div>
          ) : (
            <div className="space-y-3">
              {filteredVendas.map((venda) => {
                const meta =
                  STATUS_VENDA_META[(venda.status as StatusVendaCode) || 'CONCLUIDA'] ??
                  STATUS_VENDA_META.CONCLUIDA;
                const isCanceled = venda.status === 'CANCELADA';
                return (
                  <div
                    key={venda.id || venda.numero_venda}
                    className={`bg-white border rounded-2xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                      isCanceled ? 'border-red-200 opacity-75' : 'border-slate-200'
                    }`}
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono-num text-xs font-bold px-2.5 py-0.5 rounded-lg bg-cobalt-light text-cobalt">
                          Venda #{venda.numero_venda}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${meta.badgeBg} ${meta.badgeText}`}
                        >
                          {meta.label}
                        </span>
                        <span className="text-xs text-slate-500">
                          {formatDateTimeBr(venda.data_venda || venda.created_at)}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-700">
                        <span className="inline-flex items-center gap-1 font-bold text-slate-900">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          {venda.cliente_nome || 'Consumidor Final'}
                        </span>
                        <span>Pagamento: {venda.forma_pagamento}</span>
                        {venda.vendedor_nome && <span>Vendedor: {venda.vendedor_nome}</span>}
                      </div>

                      <div className="text-xs text-slate-500 truncate">
                        {(venda.itens || [])
                          .map((i) => `${i.quantidade}x ${i.nome}`)
                          .join(' • ')}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between md:justify-end gap-3 shrink-0">
                      <div className="text-right mr-2">
                        <div className="font-mono-num text-base font-bold text-slate-900">
                          {formatCurrency(venda.valor_total)}
                        </div>
                        {venda.desconto > 0 && (
                          <div className="text-[11px] text-slate-500">
                            Desc: -{formatCurrency(venda.desconto)}
                          </div>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => setReceiptTarget(venda)}
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cobalt-light hover:bg-cobalt text-cobalt hover:text-white text-xs font-bold transition-colors"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        Nota / Cupom
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          openWhatsAppWeb(
                            venda.cliente_telefone,
                            buildSaleWhatsAppMessage(venda, configuracaoOficina)
                          )
                        }
                        className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white text-xs font-bold transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        WhatsApp
                      </button>

                      {!isCanceled && venda.id && (
                        <button
                          type="button"
                          onClick={() => setCancelTarget(venda)}
                          className="inline-flex items-center gap-1 px-2.5 py-2 rounded-xl border border-red-200 text-red-600 hover:bg-red-50 text-xs font-semibold"
                          title="Cancelar venda e devolver itens ao estoque"
                        >
                          <Ban className="w-3.5 h-3.5" />
                          Cancelar
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      <SaleReceiptModal
        venda={receiptTarget}
        storeConfig={configuracaoOficina}
        onClose={() => setReceiptTarget(null)}
      />

      <ConfirmModal
        open={Boolean(cancelTarget)}
        title="Cancelar Venda e Estornar Estoque"
        message={`Deseja cancelar a Venda #${cancelTarget?.numero_venda ?? ''}? Os produtos serão devolvidos automaticamente ao estoque e o lançamento financeiro será removido.`}
        confirmLabel="Confirmar Cancelamento"
        onCancel={() => setCancelTarget(null)}
        onConfirm={async () => {
          if (cancelTarget?.id) {
            await cancelarVenda(cancelTarget.id);
          }
          setCancelTarget(null);
        }}
      />
    </div>
  );
};
