import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Camera,
  Edit3,
  FileText,
  Minus,
  Package,
  Plus,
  Search,
  ShoppingCart,
  Sparkles,
  Trash2,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { PhotoLightbox } from '../components/PhotoLightbox';
import { useWorkshop } from '../context/WorkshopContext';
import {
  isEstoqueBaixo,
  PART_CATEGORIES,
  PecaEstoqueDto,
  PedidoPecaDto
} from '../types/models';
import { formatCurrency, parseDoubleInput } from '../utils/formatters';
import {
  CompressionPresetCode,
  IMAGE_COMPRESSION_PRESETS
} from '../utils/imageCompressor';
import { PedidoPecaFormModal } from './PedidosPecasPage';

function buildPlaceholderAiSpec(peca: PecaEstoqueDto): string {
  return [
    `FICHA TÉCNICA — ${peca.nome.toUpperCase()}`,
    `Categoria: ${peca.categoria}`,
    peca.codigo_sku ? `Código/SKU: ${peca.codigo_sku}` : null,
    peca.fornecedor ? `Fornecedor principal: ${peca.fornecedor}` : null,
    `Aplicação recomendada: Reposição em equipamentos eletrônicos e sistemas de segurança compatíveis com as especificações nominais do fabricante.`,
    `Boas práticas de bancada: Conferir polaridade, tensão de trabalho, corrente máxima e isolação antes da energização final.`
  ]
    .filter(Boolean)
    .join('\n');
}

export const EstoquePage: React.FC = () => {
  const {
    session,
    isAdmin,
    pecas,
    pecasEstoqueBaixo,
    ordens,
    isSubmitting,
    savePeca,
    adjustPecaQuantity,
    deletePeca,
    savePedidoPeca
  } = useWorkshop();

  const [query, setQuery] = useState('');
  const [categoriaFilter, setCategoriaFilter] = useState('TODAS');
  const [onlyLowStock, setOnlyLowStock] = useState(false);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<PecaEstoqueDto | null>(null);
  const [specPeca, setSpecPeca] = useState<PecaEstoqueDto | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PecaEstoqueDto | null>(null);
  const [pedidoTargetPeca, setPedidoTargetPeca] = useState<PecaEstoqueDto | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return pecas.filter((p) => {
      if (onlyLowStock && !isEstoqueBaixo(p)) return false;
      if (categoriaFilter !== 'TODAS' && p.categoria !== categoriaFilter) return false;
      if (!q) return true;
      return (
        p.nome.toLowerCase().includes(q) ||
        p.codigo_sku.toLowerCase().includes(q) ||
        p.fornecedor.toLowerCase().includes(q) ||
        p.localizacao.toLowerCase().includes(q)
      );
    });
  }, [categoriaFilter, onlyLowStock, pecas, query]);

  const openNew = () => {
    setEditing({
      codigo_sku: '',
      nome: '',
      categoria: PART_CATEGORIES[0],
      fornecedor: '',
      localizacao: '',
      quantidade: 0,
      estoque_minimo: 2,
      preco_custo: 0,
      preco_venda: 0,
      foto_url: '',
      descricao_detalhada: ''
    });
    setFormOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Low stock banner */}
      {pecasEstoqueBaixo.length > 0 && (
        <div className="p-4 rounded-2xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5 text-red-900">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs sm:text-sm font-bold">
                {pecasEstoqueBaixo.length} peça(s) em nível crítico de estoque
              </p>
              <p className="text-xs text-red-700">
                Solicite reposição para evitar paradas na bancada.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOnlyLowStock((prev) => !prev)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-colors ${
              onlyLowStock
                ? 'bg-red-700 text-white'
                : 'bg-white border border-red-300 text-red-700 hover:bg-red-100'
            }`}
          >
            {onlyLowStock ? 'Mostrando Baixo (Limpar)' : 'Filtrar Estoque Baixo'}
          </button>
        </div>
      )}

      {/* Search & New */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar peça por nome, SKU, gaveta ou fornecedor..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
          />
        </div>
        <button
          type="button"
          onClick={openNew}
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm transition-colors"
        >
          <Plus className="w-4 h-4" />
          Nova Peça
        </button>
      </div>

      {/* Category Chips */}
      <div className="flex flex-wrap gap-1.5">
        {['TODAS', ...PART_CATEGORIES].map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCategoriaFilter(cat)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              categoriaFilter === cat
                ? 'bg-bench-navy text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {cat === 'TODAS' ? 'Todas Categorias' : cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center text-sm text-slate-500">
          Nenhuma peça encontrada no estoque.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((peca) => {
            const baixo = isEstoqueBaixo(peca);
            return (
              <div
                key={peca.id || peca.nome}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col justify-between gap-3"
              >
                <div className="flex gap-3">
                  {peca.foto_url ? (
                    <button
                      type="button"
                      onClick={() => setLightboxUrl(peca.foto_url)}
                      className="w-16 h-16 rounded-xl overflow-hidden border border-slate-200 shrink-0 hover:ring-2 hover:ring-cobalt"
                    >
                      <img
                        src={peca.foto_url}
                        alt={peca.nome}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ) : (
                    <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 text-slate-400">
                      <Package className="w-6 h-6" />
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {peca.codigo_sku && (
                        <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                          {peca.codigo_sku}
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          baixo ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {baixo ? 'BAIXO' : 'OK'}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 mt-1 line-clamp-2">
                      {peca.nome}
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                      {peca.categoria}
                      {peca.localizacao ? ` • Gaveta: ${peca.localizacao}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-500">
                      Venda / Mín: {peca.estoque_minimo}
                    </div>
                    <div className="font-mono-num text-sm font-bold text-slate-900">
                      {formatCurrency(peca.preco_venda)}
                      {isAdmin && peca.preco_custo > 0 && (
                        <span className="text-[11px] font-normal text-slate-500 ml-1.5">
                          (Custo: {formatCurrency(peca.preco_custo)})
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => adjustPecaQuantity(peca, -1)}
                      className="w-8 h-8 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 flex items-center justify-center text-slate-700"
                      aria-label="Diminuir quantidade"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="font-mono-num w-8 text-center text-sm font-bold text-slate-900">
                      {peca.quantidade}
                    </span>
                    <button
                      type="button"
                      onClick={() => adjustPecaQuantity(peca, 1)}
                      className="w-8 h-8 rounded-lg bg-cobalt hover:bg-cobalt-dark text-white flex items-center justify-center"
                      aria-label="Aumentar quantidade"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSpecPeca(peca)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      Ficha Técnica
                    </button>
                    <button
                      type="button"
                      onClick={() => setPedidoTargetPeca(peca)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 hover:bg-amber-100 text-xs font-semibold"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      Pedir
                    </button>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        setEditing({ ...peca });
                        setFormOpen(true);
                      }}
                      className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
                      aria-label="Editar peça"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(peca)}
                      className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
                      aria-label="Excluir peça"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {formOpen && editing && (
        <PecaFormModal
          initial={editing}
          isAdmin={isAdmin}
          submitting={isSubmitting}
          onClose={() => setFormOpen(false)}
          onSave={async (payload, file) => {
            const ok = await savePeca(payload, file);
            if (ok) setFormOpen(false);
          }}
        />
      )}

      {specPeca && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
            <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
              <h3 className="text-base font-bold">Ficha Técnica — {specPeca.nome}</h3>
              <button
                type="button"
                onClick={() => setSpecPeca(null)}
                className="p-1.5 rounded-lg hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <pre className="whitespace-pre-wrap text-xs text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200 font-sans leading-relaxed">
                {specPeca.descricao_detalhada?.trim() || buildPlaceholderAiSpec(specPeca)}
              </pre>
              {!specPeca.descricao_detalhada?.trim() && (
                <button
                  type="button"
                  onClick={async () => {
                    const generated = buildPlaceholderAiSpec(specPeca);
                    await savePeca({ ...specPeca, descricao_detalhada: generated });
                    setSpecPeca({ ...specPeca, descricao_detalhada: generated });
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cobalt text-white text-xs font-bold hover:bg-cobalt-dark"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  Salvar Ficha Técnica Padrão no Cadastro
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {pedidoTargetPeca && (
        <PedidoPecaFormModal
          initial={{
            peca_id: pedidoTargetPeca.id ?? null,
            nome_peca: pedidoTargetPeca.nome,
            codigo_sku: pedidoTargetPeca.codigo_sku,
            quantidade: Math.max(
              1,
              pedidoTargetPeca.estoque_minimo - pedidoTargetPeca.quantidade + 1
            ),
            motivo: 'FALTANTE',
            status: 'PENDENTE',
            prioridade: isEstoqueBaixo(pedidoTargetPeca) ? 'ALTA' : 'NORMAL',
            solicitado_por: session?.fullName || '',
            fornecedor_sugerido: pedidoTargetPeca.fornecedor,
            observacoes: ''
          }}
          ordens={ordens}
          submitting={isSubmitting}
          onClose={() => setPedidoTargetPeca(null)}
          onSave={async (payload: PedidoPecaDto) => {
            const ok = await savePedidoPeca(payload);
            if (ok) setPedidoTargetPeca(null);
          }}
        />
      )}

      <PhotoLightbox url={lightboxUrl} onClose={() => setLightboxUrl(null)} />

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Excluir Peça"
        message={`Deseja excluir "${deleteTarget?.nome ?? ''}" do estoque?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deletePeca(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

const PecaFormModal: React.FC<{
  initial: PecaEstoqueDto;
  isAdmin: boolean;
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: PecaEstoqueDto, localFile: File | null) => Promise<void>;
}> = ({ initial, isAdmin, submitting, onClose, onSave }) => {
  const { compressionPreset, setCompressionPreset } = useWorkshop();

  const [form, setForm] = useState<PecaEstoqueDto>(initial);
  const [custoRaw, setCustoRaw] = useState(String(initial.preco_custo || ''));
  const [vendaRaw, setVendaRaw] = useState(String(initial.preco_venda || ''));
  const [localFile, setLocalFile] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    await onSave(
      {
        ...form,
        preco_custo: isAdmin ? parseDoubleInput(custoRaw) : form.preco_custo,
        preco_venda: parseDoubleInput(vendaRaw)
      },
      localFile
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">
            {form.id ? 'Editar Peça' : 'Nova Peça no Estoque'}
          </h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nome da Peça *
            </label>
            <input
              type="text"
              required
              value={form.nome}
              onChange={(e) => setForm((f) => ({ ...f, nome: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">SKU</label>
              <input
                type="text"
                value={form.codigo_sku}
                onChange={(e) => setForm((f) => ({ ...f, codigo_sku: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Categoria</label>
              <select
                value={form.categoria}
                onChange={(e) => setForm((f) => ({ ...f, categoria: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                {PART_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Quantidade</label>
              <input
                type="number"
                min={0}
                value={form.quantidade}
                onChange={(e) =>
                  setForm((f) => ({ ...f, quantidade: Math.max(0, Number(e.target.value) || 0) }))
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Estoque Mínimo
              </label>
              <input
                type="number"
                min={0}
                value={form.estoque_minimo}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    estoque_minimo: Math.max(0, Number(e.target.value) || 0)
                  }))
                }
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
          </div>

          <div className={`grid ${isAdmin ? 'grid-cols-2' : 'grid-cols-1'} gap-3`}>
            {isAdmin && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Preço Custo (R$)
                </label>
                <input
                  type="text"
                  value={custoRaw}
                  onChange={(e) => setCustoRaw(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Preço Venda (R$)
              </label>
              <input
                type="text"
                value={vendaRaw}
                onChange={(e) => setVendaRaw(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Fornecedor</label>
              <input
                type="text"
                value={form.fornecedor}
                onChange={(e) => setForm((f) => ({ ...f, fornecedor: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Localização / Gaveta
              </label>
              <input
                type="text"
                value={form.localizacao}
                onChange={(e) => setForm((f) => ({ ...f, localizacao: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
          </div>

          {/* Photo upload with WebP preset */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700">
                <Camera className="w-4 h-4 text-cobalt" />
                Foto da Peça (WebP)
              </span>
              <select
                value={compressionPreset}
                onChange={(e) => setCompressionPreset(e.target.value as CompressionPresetCode)}
                className="px-2 py-1 rounded-lg border border-slate-300 bg-white text-[11px] font-semibold"
              >
                {Object.values(IMAGE_COMPRESSION_PRESETS).map((p) => (
                  <option key={p.code} value={p.code}>
                    {p.shortLabel}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-3">
              <label className="px-3 py-2 rounded-xl bg-cobalt text-white text-xs font-bold cursor-pointer hover:bg-cobalt-dark">
                Selecionar Foto
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setLocalFile(e.target.files?.[0] ?? null)}
                  className="hidden"
                />
              </label>
              <span className="text-xs text-slate-600 truncate">
                {localFile
                  ? localFile.name
                  : form.foto_url
                  ? 'Foto já vinculada no Supabase'
                  : 'Nenhuma foto selecionada'}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Descrição / Ficha Técnica
            </label>
            <textarea
              rows={2}
              value={form.descricao_detalhada}
              onChange={(e) => setForm((f) => ({ ...f, descricao_detalhada: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Peça'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
