import React, { useEffect, useState } from 'react';
import { Award, CheckCircle2, DollarSign, Save, Target, TrendingUp } from 'lucide-react';
import { KpiCard } from '../components/KpiCard';
import { useWorkshop } from '../context/WorkshopContext';
import { formatCurrency, parseDoubleInput } from '../utils/formatters';

export const MetasPage: React.FC = () => {
  const {
    metaDiaria,
    faturamentoLojaRecebido,
    aReceberPendenteLoja,
    ticketMedioRealOs,
    isSubmitting,
    saveMetaDiaria
  } = useWorkshop();

  const [metaMensalRaw, setMetaMensalRaw] = useState(String(metaDiaria.meta_mensal));
  const [custosFixosRaw, setCustosFixosRaw] = useState(String(metaDiaria.custos_fixos_mensais));
  const [diasUteisRaw, setDiasUteisRaw] = useState(String(metaDiaria.dias_uteis_mes));
  const [diasRestantesRaw, setDiasRestantesRaw] = useState(String(metaDiaria.dias_uteis_restantes));
  const [ticketRaw, setTicketRaw] = useState(String(metaDiaria.ticket_medio_estimado));

  useEffect(() => {
    setMetaMensalRaw(String(metaDiaria.meta_mensal));
    setCustosFixosRaw(String(metaDiaria.custos_fixos_mensais));
    setDiasUteisRaw(String(metaDiaria.dias_uteis_mes));
    setDiasRestantesRaw(String(metaDiaria.dias_uteis_restantes));
    setTicketRaw(String(metaDiaria.ticket_medio_estimado));
  }, [metaDiaria]);

  const metaMensal = Math.max(0, parseDoubleInput(metaMensalRaw));
  const custosFixos = Math.max(0, parseDoubleInput(custosFixosRaw));
  const diasUteis = Math.max(1, Math.round(parseDoubleInput(diasUteisRaw) || 22));
  const diasRestantes = Math.max(1, Math.round(parseDoubleInput(diasRestantesRaw) || 1));
  const ticketEst = Math.max(1, parseDoubleInput(ticketRaw) || 1);

  const realizado = faturamentoLojaRecebido;
  const faltam = Math.max(0, metaMensal - realizado);
  const pct = metaMensal > 0 ? Math.min(100, Math.round((realizado / metaMensal) * 100)) : 0;

  const metaDiariaIdeal = metaMensal / diasUteis;
  const metaAjustadaHoje = faltam / diasRestantes;
  const equilibrioDiario = custosFixos / diasUteis;
  const osNecessariasDia = Math.ceil(metaAjustadaHoje / ticketEst);
  const breakEvenAtingido = realizado >= custosFixos;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveMetaDiaria({
      ...metaDiaria,
      meta_mensal: metaMensal,
      custos_fixos_mensais: custosFixos,
      dias_uteis_mes: diasUteis,
      dias_uteis_restantes: diasRestantes,
      ticket_medio_estimado: ticketEst
    });
  };

  return (
    <div className="space-y-6">
      {/* Progress Banner */}
      <div className="bg-bench-dark text-white rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-300">
              Progresso da Meta Mensal (Loja)
            </span>
            <h2 className="font-display text-2xl font-bold mt-1">
              {formatCurrency(realizado)}{' '}
              <span className="text-sm font-normal text-slate-300">
                de {formatCurrency(metaMensal)} ({pct}%)
              </span>
            </h2>
          </div>

          <div
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold ${
              breakEvenAtingido
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                : 'bg-amber-500/20 text-amber-200 border border-amber-400/30'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            {breakEvenAtingido
              ? 'Ponto de equilíbrio atingido!'
              : `Faltam ${formatCurrency(Math.max(0, custosFixos - realizado))} p/ pagar custos fixos`}
          </div>
        </div>

        <div className="h-3.5 w-full rounded-full bg-white/15 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-cobalt to-cyan-400 transition-all duration-500"
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
          <span>Faltam para a meta: {formatCurrency(faltam)}</span>
          <span>A receber (Loja): {formatCurrency(aReceberPendenteLoja)}</span>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="Meta Diária Ideal"
          value={formatCurrency(metaDiariaIdeal)}
          subtitle={`Base ${diasUteis} dias úteis`}
          icon={Target}
          accentColor="cobalt"
        />
        <KpiCard
          title="Meta Ajustada Hoje"
          value={formatCurrency(metaAjustadaHoje)}
          subtitle={`~${osNecessariasDia} OS/dia pelos próximos ${diasRestantes} dias`}
          icon={TrendingUp}
          accentColor="cyan"
        />
        <KpiCard
          title="Equilíbrio Diário"
          value={formatCurrency(equilibrioDiario)}
          subtitle={`Custos fixos: ${formatCurrency(custosFixos)}`}
          icon={DollarSign}
          accentColor="amber"
        />
        <KpiCard
          title="Ticket Médio Real"
          value={formatCurrency(ticketMedioRealOs)}
          subtitle="Calculado pelas suas OS"
          icon={Award}
          accentColor="emerald"
        />
      </div>

      {/* Form */}
      <form
        onSubmit={handleSave}
        className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900">Parâmetros de Meta da Oficina</h3>
            <p className="text-xs text-slate-500">
              Ajuste os valores mensais para recalcular sua meta diária em tempo real.
            </p>
          </div>
          {ticketMedioRealOs > 0 && (
            <button
              type="button"
              onClick={() => setTicketRaw(ticketMedioRealOs.toFixed(2))}
              className="px-3 py-1.5 rounded-xl bg-cobalt-light text-cobalt text-xs font-bold hover:bg-cobalt hover:text-white transition-colors"
            >
              Usar Ticket Médio Real das OS ({formatCurrency(ticketMedioRealOs)})
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Meta de Faturamento Mensal (R$)
            </label>
            <input
              type="text"
              value={metaMensalRaw}
              onChange={(e) => setMetaMensalRaw(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Custos Fixos Mensais (R$)
            </label>
            <input
              type="text"
              value={custosFixosRaw}
              onChange={(e) => setCustosFixosRaw(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Ticket Médio Estimado (R$)
            </label>
            <input
              type="text"
              value={ticketRaw}
              onChange={(e) => setTicketRaw(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Dias Úteis no Mês
            </label>
            <input
              type="number"
              min={1}
              max={31}
              value={diasUteisRaw}
              onChange={(e) => setDiasUteisRaw(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Dias Úteis Restantes
            </label>
            <input
              type="number"
              min={1}
              max={31}
              value={diasRestantesRaw}
              onChange={(e) => setDiasRestantesRaw(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm disabled:opacity-60"
          >
            <Save className="w-4 h-4" />
            {isSubmitting ? 'Salvando...' : 'Salvar Metas'}
          </button>
        </div>
      </form>
    </div>
  );
};
