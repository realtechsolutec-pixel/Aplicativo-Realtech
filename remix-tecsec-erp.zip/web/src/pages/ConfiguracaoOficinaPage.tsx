import React, { useEffect, useState } from 'react';
import {
  Camera,
  Copy,
  Edit3,
  Plus,
  Save,
  ShieldCheck,
  Trash2,
  UserPlus,
  Users,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useWorkshop } from '../context/WorkshopContext';
import { ConfiguracaoOficinaDto, FuncionarioDto } from '../types/models';
import { formatPercent, parseDoubleInput } from '../utils/formatters';
import {
  CompressionPresetCode,
  IMAGE_COMPRESSION_PRESETS
} from '../utils/imageCompressor';
import { EditComissaoModal } from './ComissoesPage';

export const ConfiguracaoOficinaPage: React.FC = () => {
  const {
    session,
    configuracaoOficina,
    funcionarios,
    compressionPreset,
    setCompressionPreset,
    isSubmitting,
    showToast,
    saveConfiguracaoOficina,
    createFuncionario,
    updateFuncionarioPerfil,
    toggleFuncionarioAtivo,
    deleteFuncionario
  } = useWorkshop();

  const [cfg, setCfg] = useState<ConfiguracaoOficinaDto>(configuracaoOficina);
  const [addFuncOpen, setAddFuncOpen] = useState(false);
  const [editingFunc, setEditingFunc] = useState<FuncionarioDto | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FuncionarioDto | null>(null);

  useEffect(() => {
    setCfg(configuracaoOficina);
  }, [configuracaoOficina]);

  const handleSaveCfg = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveConfiguracaoOficina(cfg);
  };

  const handleCopyCode = async () => {
    if (!session?.workshopOwnerId) return;
    try {
      await navigator.clipboard.writeText(session.workshopOwnerId);
      showToast('Código da Oficina copiado!', 'success');
    } catch {
      showToast('Não foi possível copiar o código.', 'error');
    }
  };

  const limitReached = funcionarios.length >= 4;

  return (
    <div className="space-y-6">
      {/* Live Header Preview */}
      <div className="bg-bench-dark text-white rounded-2xl p-5 shadow-sm space-y-1.5">
        <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-300">
          Prévia do Cabeçalho da OS e Comprovantes
        </div>
        <h2 className="font-display text-xl font-bold">
          {cfg.nome_loja || 'RTerp Eletrônica & Segurança'}
        </h2>
        <p className="text-xs text-slate-300">
          {[cfg.cnpj && `CNPJ: ${cfg.cnpj}`, cfg.telefone && `Tel: ${cfg.telefone}`, cfg.email]
            .filter(Boolean)
            .join(' • ') || 'Configure CNPJ, telefone, e-mail e endereço abaixo'}
        </p>
        {cfg.endereco && <p className="text-xs text-slate-400">{cfg.endereco}</p>}
      </div>

      {/* Store Config Form */}
      <form
        onSubmit={handleSaveCfg}
        className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4"
      >
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-cobalt" />
          <h3 className="text-base font-bold text-slate-900">Dados da Loja e Ordem de Serviço</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nome Fantasia / Oficina
            </label>
            <input
              type="text"
              value={cfg.nome_loja}
              onChange={(e) => setCfg((c) => ({ ...c, nome_loja: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">CNPJ</label>
            <input
              type="text"
              value={cfg.cnpj}
              onChange={(e) => setCfg((c) => ({ ...c, cnpj: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Telefone</label>
            <input
              type="text"
              value={cfg.telefone}
              onChange={(e) => setCfg((c) => ({ ...c, telefone: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail</label>
            <input
              type="email"
              value={cfg.email}
              onChange={(e) => setCfg((c) => ({ ...c, email: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Endereço</label>
            <input
              type="text"
              value={cfg.endereco}
              onChange={(e) => setCfg((c) => ({ ...c, endereco: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Garantia Padrão (dias)
            </label>
            <input
              type="number"
              min={0}
              value={cfg.garantia_padrao_dias}
              onChange={(e) =>
                setCfg((c) => ({
                  ...c,
                  garantia_padrao_dias: Math.max(0, Number(e.target.value) || 0)
                }))
              }
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Rodapé / Termos da OS
            </label>
            <textarea
              rows={2}
              value={cfg.rodape_os}
              onChange={(e) => setCfg((c) => ({ ...c, rodape_os: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm disabled:opacity-60"
          >
            <Save className="w-4 h-4" />
            {isSubmitting ? 'Salvando...' : 'Salvar Dados da Loja'}
          </button>
        </div>
      </form>

      {/* WebP Compression Settings */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <Camera className="w-5 h-5 text-cobalt" />
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Compactação de Imagens (Supabase Storage)
            </h3>
            <p className="text-xs text-slate-500">
              Todas as fotos enviadas em OS e Estoque são convertidas e compactadas em WebP antes do upload.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {(Object.keys(IMAGE_COMPRESSION_PRESETS) as CompressionPresetCode[]).map((code) => {
            const p = IMAGE_COMPRESSION_PRESETS[code];
            const selected = compressionPreset === code;
            return (
              <button
                key={code}
                type="button"
                onClick={() => setCompressionPreset(code)}
                className={`text-left p-3.5 rounded-xl border transition-all ${
                  selected
                    ? 'bg-cobalt-light/50 border-cobalt ring-2 ring-cobalt/20'
                    : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="text-xs font-bold text-slate-900">{p.label}</div>
                <div className="text-[11px] text-slate-600 mt-1">{p.description}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Employees (Max 4) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-cobalt" />
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Equipe & Acessos Operacionais ({funcionarios.length}/4 acessos)
              </h3>
              <p className="text-xs text-slate-500">
                Funcionários não acessam Financeiro, Metas ou Custos. Máximo de 4 acessos.
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={limitReached}
            onClick={() => setAddFuncOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <UserPlus className="w-4 h-4" />
            {limitReached ? 'Limite 4/4 Atingido' : 'Cadastrar Funcionário'}
          </button>
        </div>

        {/* Workshop code */}
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-[11px] font-bold uppercase text-slate-500">
              Código da Oficina (para vínculo no Login do Funcionário)
            </div>
            <div className="font-mono text-xs font-bold text-slate-900 truncate mt-0.5">
              {session?.workshopOwnerId}
            </div>
          </div>
          <button
            type="button"
            onClick={handleCopyCode}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100"
          >
            <Copy className="w-3.5 h-3.5" />
            Copiar Código
          </button>
        </div>

        <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-200 text-xs text-sky-900">
          <span className="font-bold">Arquitetura Multi-Loja (SaaS):</span> Isolamento por{' '}
          <code className="font-mono text-[11px]">owner_id</code> com RLS otimizado (InitPlan), bloqueio atômico de sequência por loja e retry automático — preparado para atender mais de{' '}
          <strong>200 contas ADM simultâneas</strong> com até 4 funcionários cada.
        </div>

        {funcionarios.length === 0 ? (
          <p className="text-xs text-slate-500 text-center py-6">
            Nenhum funcionário cadastrado ainda.
          </p>
        ) : (
          <div className="space-y-3">
            {funcionarios.map((fn) => (
              <div
                key={fn.id || fn.email}
                className="p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-bold text-slate-900">{fn.nome}</span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cobalt-light text-cobalt">
                      {fn.cargo} • {formatPercent(fn.comissao_percentual)}% mão de obra
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        fn.ativo ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {fn.ativo ? 'Ativo' : 'Bloqueado'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{fn.email}</p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingFunc(fn)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    Editar % / Função
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleFuncionarioAtivo(fn)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    {fn.ativo ? 'Desativar' : 'Reativar'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(fn)}
                    className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {addFuncOpen && (
        <AddFuncionarioModal
          submitting={isSubmitting}
          onClose={() => setAddFuncOpen(false)}
          onCreate={async (params) => {
            const ok = await createFuncionario(params);
            if (ok) setAddFuncOpen(false);
          }}
        />
      )}

      {editingFunc && (
        <EditComissaoModal
          func={editingFunc}
          submitting={isSubmitting}
          onClose={() => setEditingFunc(null)}
          onSave={async (cargo, pct) => {
            const ok = await updateFuncionarioPerfil(editingFunc, cargo, pct);
            if (ok) setEditingFunc(null);
          }}
        />
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Remover Funcionário"
        message={`Remover "${deleteTarget?.nome ?? ''}" da equipe?`}
        confirmLabel="Remover"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deleteFuncionario(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

const AddFuncionarioModal: React.FC<{
  submitting: boolean;
  onClose: () => void;
  onCreate: (params: {
    nome: string;
    email: string;
    password: string;
    cargo: string;
    comissaoPercentual: number;
  }) => Promise<void>;
}> = ({ submitting, onClose, onCreate }) => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [cargo, setCargo] = useState('Técnico');
  const [pctRaw, setPctRaw] = useState('60');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim() || !email.trim() || password.length < 6) return;
    await onCreate({
      nome: nome.trim(),
      email: email.trim(),
      password,
      cargo: cargo.trim() || 'Técnico',
      comissaoPercentual: Math.min(100, Math.max(0, parseDoubleInput(pctRaw)))
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">Novo Acesso de Funcionário</h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Nome *</label>
            <input
              type="text"
              required
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail *</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Senha inicial (mín. 6 caracteres) *
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Função</label>
              <select
                value={cargo}
                onChange={(e) => {
                  const val = e.target.value;
                  setCargo(val);
                  if (val === 'Atendente') setPctRaw('80');
                  if (val === 'Técnico') setPctRaw('60');
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm"
              >
                <option value="Técnico">Técnico</option>
                <option value="Atendente">Atendente</option>
                <option value="Técnico + Atendente">Técnico + Atendente</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Comissão M.O (%)
              </label>
              <input
                type="text"
                value={pctRaw}
                onChange={(e) => setPctRaw(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono-num text-sm"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              <Plus className="w-3.5 h-3.5" />
              {submitting ? 'Criando...' : 'Criar Acesso'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
