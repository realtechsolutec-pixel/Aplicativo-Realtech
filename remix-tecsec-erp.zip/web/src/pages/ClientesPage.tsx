import React, { useMemo, useState } from 'react';
import {
  Building2,
  Edit3,
  Mail,
  MapPin,
  Phone,
  Plus,
  Search,
  Trash2,
  User,
  X
} from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';
import { useWorkshop } from '../context/WorkshopContext';
import { ClienteDto, TipoCliente } from '../types/models';

export const ClientesPage: React.FC = () => {
  const { clientes, ordens, isSubmitting, saveCliente, deleteCliente } = useWorkshop();

  const [query, setQuery] = useState('');
  const [tipoFilter, setTipoFilter] = useState<'TODOS' | TipoCliente>('TODOS');
  const [editing, setEditing] = useState<ClienteDto | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<ClienteDto | null>(null);

  const osCountByClienteId = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of ordens) {
      if (o.cliente_id) {
        map.set(o.cliente_id, (map.get(o.cliente_id) ?? 0) + 1);
      }
    }
    return map;
  }, [ordens]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return clientes.filter((c) => {
      if (tipoFilter !== 'TODOS' && c.tipo !== tipoFilter) return false;
      if (!q) return true;
      return (
        c.nome.toLowerCase().includes(q) ||
        c.telefone.toLowerCase().includes(q) ||
        c.documento.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q)
      );
    });
  }, [clientes, query, tipoFilter]);

  const openNew = () => {
    setEditing({
      nome: '',
      tipo: 'PF',
      documento: '',
      telefone: '',
      email: '',
      endereco: '',
      observacoes: ''
    });
    setModalOpen(true);
  };

  const openEdit = (c: ClienteDto) => {
    setEditing({ ...c });
    setModalOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar cliente por nome, telefone, CPF/CNPJ..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cobalt/30 focus:border-cobalt"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(['TODOS', 'PF', 'PJ'] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTipoFilter(t)}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-colors ${
                tipoFilter === t
                  ? 'bg-bench-navy text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {t === 'TODOS' ? 'Todos' : t === 'PF' ? 'Pessoa Física' : 'Empresa (PJ)'}
            </button>
          ))}
          <button
            type="button"
            onClick={openNew}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            Novo Cliente
          </button>
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-sm font-semibold text-slate-700">Nenhum cliente encontrado.</p>
          <p className="text-xs text-slate-500 mt-1">
            Cadastre seus clientes PF ou PJ para vincular às Ordens de Serviço.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((c) => {
            const osCount = c.id ? osCountByClienteId.get(c.id) ?? 0 : 0;
            const isPj = c.tipo === 'PJ';
            return (
              <div
                key={c.id || c.nome}
                className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm hover:border-cobalt/40 transition-colors flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                          isPj ? 'bg-violet-100 text-violet-700' : 'bg-cobalt-light text-cobalt'
                        }`}
                      >
                        {isPj ? <Building2 className="w-4 h-4" /> : <User className="w-4 h-4" />}
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-sm font-bold text-slate-900 truncate">{c.nome}</h3>
                        <span className="inline-block text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                          {isPj ? 'PJ' : 'PF'}
                          {c.documento ? ` • ${c.documento}` : ''}
                        </span>
                      </div>
                    </div>

                    <span className="font-mono-num text-[11px] font-bold px-2 py-1 rounded-lg bg-sky-50 text-sky-700 shrink-0">
                      {osCount} OS
                    </span>
                  </div>

                  <div className="mt-3 space-y-1 text-xs text-slate-600">
                    {c.telefone && (
                      <div className="flex items-center gap-1.5">
                        <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{c.telefone}</span>
                      </div>
                    )}
                    {c.email && (
                      <div className="flex items-center gap-1.5 truncate">
                        <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{c.email}</span>
                      </div>
                    )}
                    {c.endereco && (
                      <div className="flex items-center gap-1.5 truncate">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{c.endereco}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => openEdit(c)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    Editar
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(c)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-200 text-xs font-semibold text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Excluir
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && editing && (
        <ClienteFormModal
          initial={editing}
          submitting={isSubmitting}
          onClose={() => setModalOpen(false)}
          onSave={async (payload) => {
            const ok = await saveCliente(payload);
            if (ok) setModalOpen(false);
          }}
        />
      )}

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Excluir Cliente"
        message={`Deseja realmente excluir "${deleteTarget?.nome ?? ''}"?`}
        confirmLabel="Excluir"
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget?.id) deleteCliente(deleteTarget.id);
          setDeleteTarget(null);
        }}
      />
    </div>
  );
};

interface ClienteFormModalProps {
  initial: ClienteDto;
  submitting: boolean;
  onClose: () => void;
  onSave: (payload: ClienteDto) => Promise<void>;
}

const ClienteFormModal: React.FC<ClienteFormModalProps> = ({
  initial,
  submitting,
  onClose,
  onSave
}) => {
  const [form, setForm] = useState<ClienteDto>(initial);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.nome.trim()) return;
    await onSave(form);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 bg-bench-navy text-white flex items-center justify-between">
          <h3 className="text-base font-bold">
            {form.id ? 'Editar Cliente' : 'Novo Cliente'}
          </h3>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100">
            {(['PF', 'PJ'] as TipoCliente[]).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setForm((f) => ({ ...f, tipo: t }))}
                className={`py-2 rounded-lg text-xs font-bold transition-colors ${
                  form.tipo === t ? 'bg-cobalt text-white shadow-sm' : 'text-slate-600'
                }`}
              >
                {t === 'PF' ? 'Pessoa Física (PF)' : 'Pessoa Jurídica (PJ)'}
              </button>
            ))}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nome / Razão Social *
            </label>
            <input
              type="text"
              required
              value={form.nome}
              onChange={(e) => setForm((f) => ({ ...f, nome: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Telefone / WhatsApp
              </label>
              <input
                type="text"
                value={form.telefone}
                onChange={(e) => setForm((f) => ({ ...f, telefone: e.target.value }))}
                placeholder="(11) 99999-9999"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {form.tipo === 'PJ' ? 'CNPJ' : 'CPF'}
              </label>
              <input
                type="text"
                value={form.documento}
                onChange={(e) => setForm((f) => ({ ...f, documento: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Endereço</label>
            <input
              type="text"
              value={form.endereco}
              onChange={(e) => setForm((f) => ({ ...f, endereco: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Observações</label>
            <textarea
              rows={2}
              value={form.observacoes}
              onChange={(e) => setForm((f) => ({ ...f, observacoes: e.target.value }))}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-bold disabled:opacity-60"
            >
              {submitting ? 'Salvando...' : 'Salvar Cliente'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
