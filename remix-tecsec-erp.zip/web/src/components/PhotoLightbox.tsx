import React from 'react';
import { X } from 'lucide-react';

interface PhotoLightboxProps {
  url: string | null;
  caption?: string;
  onClose: () => void;
}

export const PhotoLightbox: React.FC<PhotoLightboxProps> = ({ url, caption, onClose }) => {
  if (!url) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-950/90 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <div className="w-full max-w-4xl flex items-center justify-between mb-3 text-white">
        <span className="text-sm font-medium truncate pr-4">{caption || 'Visualização de Foto'}</span>
        <button
          type="button"
          onClick={onClose}
          className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          aria-label="Fechar foto"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
      <div
        className="max-w-4xl max-h-[82vh] overflow-hidden rounded-2xl border border-white/15 bg-black shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <img src={url} alt={caption || 'Foto do equipamento'} className="max-h-[82vh] w-auto object-contain" />
      </div>
    </div>
  );
};
