import React, { useState } from 'react';
import { Copy, MessageCircle, Printer, ShieldCheck, X } from 'lucide-react';
import {
  ConfiguracaoOficinaDto,
  OrdemServicoDto,
  STATUS_OS_META,
  StatusOSCode
} from '../types/models';
import {
  addDaysToDateBr,
  formatCurrency,
  formatDateTimeBr,
  nowIsoTimestamp
} from '../utils/formatters';
import {
  buildOsWhatsAppMessage,
  buildThermalText,
  buildWarrantyWhatsAppMessage,
  openWhatsAppWeb,
  RECEIPT_KIND_LABELS,
  ReceiptFormat,
  ReceiptKind
} from '../utils/receipt';
import { useWorkshop } from '../context/WorkshopContext';

interface ReceiptModalProps {
  os: OrdemServicoDto | null;
  storeConfig: ConfiguracaoOficinaDto;
  initialKind?: ReceiptKind;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  os,
  storeConfig,
  initialKind = 'ENTRADA',
  onClose
}) => {
  const { showToast } = useWorkshop();
  const [kind, setKind] = useState<ReceiptKind>(initialKind);
  const [format, setFormat] = useState<ReceiptFormat>('PDF_A4');

  if (!os) return null;

  const thermalText = buildThermalText(os, kind, storeConfig);
  const baseDelivery = os.data_saida || nowIsoTimestamp();
  const validUntil = addDaysToDateBr(baseDelivery, os.garantia_dias);
  const statusLabel = STATUS_OS_META[(os.status as StatusOSCode) || 'ABERTA']?.label ?? os.status;

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(thermalText);
      showToast('Texto do cupom copiado para a área de transferência.', 'success');
    } catch {
      showToast('Não foi possível copiar automaticamente.', 'error');
    }
  };

  const handleWhatsApp = () => {
    const msg =
      kind === 'GARANTIA'
        ? buildWarrantyWhatsAppMessage(os, storeConfig)
        : buildOsWhatsAppMessage(os, storeConfig);
    openWhatsAppWeb(os.cliente_telefone, msg);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-3xl max-h-[92vh] flex flex-col bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 bg-bench-navy text-white">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-base font-bold">
                Comprovante / Garantia — OS #{os.numero_os}
              </h3>
              <p className="text-xs text-slate-300">{os.cliente_nome}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-200 transition-colors"
            aria-label="Fechar comprovante"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selectors */}
        <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5">
            {(['ENTRADA', 'SAIDA', 'GARANTIA'] as ReceiptKind[]).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => setKind(k)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                  kind === k
                    ? 'bg-cobalt text-white shadow-sm'
                    : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {RECEIPT_KIND_LABELS[k]}
              </button>
            ))}
          </div>

          <div className="flex gap-1.5 bg-slate-200/70 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setFormat('PDF_A4')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                format === 'PDF_A4' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Documento A4 / PDF
            </button>
            <button
              type="button"
              onClick={() => setFormat('TERMICA_80MM')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                format === 'TERMICA_80MM' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Térmica 80mm
            </button>
          </div>
        </div>

        {/* Preview Area */}
        <div className="flex-1 overflow-y-auto p-5 bg-slate-100">
          <div id="receipt-print-area">
            {format === 'TERMICA_80MM' ? (
              <div className="mx-auto max-w-sm bg-amber-50/40 border border-slate-300 rounded-xl p-4 shadow-sm">
                <pre className="font-mono text-xs leading-relaxed text-slate-900 whitespace-pre-wrap">
                  {thermalText}
                </pre>
              </div>
            ) : (
              <div className="mx-auto max-w-2xl bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-5 text-slate-900">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-950">
                      {storeConfig.nome_loja || 'RTerp Eletrônica & Segurança'}
                    </h4>
                    {storeConfig.cnpj && (
                      <p className="text-xs text-slate-600">CNPJ: {storeConfig.cnpj}</p>
                    )}
                    {storeConfig.telefone && (
                      <p className="text-xs text-slate-600">Tel: {storeConfig.telefone}</p>
                    )}
                    {storeConfig.endereco && (
                      <p className="text-xs text-slate-600">{storeConfig.endereco}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-3 py-1 rounded-full bg-cobalt-light text-cobalt text-xs font-bold uppercase">
                      {RECEIPT_KIND_LABELS[kind]}
                    </span>
                    <div className="mt-1 font-mono-num text-xl font-bold text-slate-950">
                      OS #{os.numero_os}
                    </div>
                    <p className="text-xs text-slate-500">{statusLabel}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold uppercase text-slate-500">Cliente</span>
                    <p className="text-sm font-bold text-slate-900 mt-0.5">{os.cliente_nome}</p>
                    {os.cliente_telefone && (
                      <p className="text-slate-600">Tel/Whats: {os.cliente_telefone}</p>
                    )}
                  </div>
                  <div>
                    <span className="font-bold uppercase text-slate-500">Atendimento</span>
                    <p className="text-slate-700 mt-0.5">
                      Entrada: {formatDateTimeBr(os.data_entrada)}
                    </p>
                    {(kind === 'SAIDA' || kind === 'GARANTIA') && (
                      <p className="text-slate-700">Entrega: {formatDateTimeBr(baseDelivery)}</p>
                    )}
                    {os.tecnico_nome && (
                      <p className="text-slate-800 font-semibold">
                        Técnico Resp.: {os.tecnico_nome}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="p-3 rounded-xl border border-slate-200">
                    <span className="font-bold uppercase text-slate-500">Equipamento</span>
                    <p className="text-sm font-semibold text-slate-900 mt-0.5">
                      {os.categoria_equipamento} — {os.equipamento}
                    </p>
                    <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-slate-600">
                      {os.marca_modelo && <span>Modelo: {os.marca_modelo}</span>}
                      {os.numero_serie && <span>Nº Série: {os.numero_serie}</span>}
                      {kind === 'ENTRADA' && os.acessorios_entregues && (
                        <span>Acessórios: {os.acessorios_entregues}</span>
                      )}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 space-y-2">
                    <div>
                      <span className="font-bold uppercase text-slate-500">
                        {kind === 'GARANTIA' ? 'Serviço Coberto pela Garantia' : 'Defeito Relatado'}
                      </span>
                      <p className="text-slate-800 mt-0.5">
                        {kind === 'GARANTIA'
                          ? os.diagnostico_tecnico?.trim() || os.defeito_relatado
                          : os.defeito_relatado}
                      </p>
                    </div>
                    {kind !== 'GARANTIA' && os.diagnostico_tecnico && (
                      <div>
                        <span className="font-bold uppercase text-slate-500">
                          Diagnóstico / Serviço Executado
                        </span>
                        <p className="text-slate-800 mt-0.5">{os.diagnostico_tecnico}</p>
                      </div>
                    )}
                    {os.pecas_utilizadas && (
                      <div>
                        <span className="font-bold uppercase text-slate-500">Peças Utilizadas</span>
                        <p className="text-slate-800 mt-0.5">{os.pecas_utilizadas}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-bench-navy text-white">
                  <div className="text-xs space-y-0.5">
                    {kind === 'SAIDA' && (
                      <>
                        <p className="text-slate-300">
                          Mão de obra: {formatCurrency(os.valor_mao_obra)} • Peças:{' '}
                          {formatCurrency(os.valor_pecas)}
                          {os.desconto > 0 ? ` • Desconto: -${formatCurrency(os.desconto)}` : ''}
                        </p>
                      </>
                    )}
                    <p className="text-cyan-300 font-semibold">
                      Garantia: {os.garantia_dias} dias{' '}
                      {kind !== 'ENTRADA' ? `(válida até ${validUntil})` : ''}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] uppercase text-slate-300">
                      {kind === 'ENTRADA' ? 'Orçamento Estimado' : 'Valor Total'}
                    </span>
                    <div className="font-mono-num text-xl font-bold text-white">
                      {formatCurrency(os.valor_total)}
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-600 leading-relaxed border-t border-slate-200 pt-3">
                  {kind === 'GARANTIA'
                    ? 'TERMO DE GARANTIA: Esta garantia cobre exclusivamente os serviços e peças substituídas descritos acima. Não cobre mau uso, umidade, queda, descarga elétrica ou violação de lacre.'
                    : storeConfig.rodape_os}
                </p>

                <div className="pt-6 flex justify-center">
                  <div className="w-72 border-t border-slate-400 pt-1.5 text-center text-xs text-slate-700">
                    Assinatura: {os.cliente_nome}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-200 bg-white flex flex-wrap items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={handleCopyText}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <Copy className="w-4 h-4" />
            Copiar Texto
          </button>
          <button
            type="button"
            onClick={handleWhatsApp}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            Enviar via WhatsApp
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-semibold transition-colors"
          >
            <Printer className="w-4 h-4" />
            Imprimir / Salvar PDF
          </button>
        </div>
      </div>
    </div>
  );
};
