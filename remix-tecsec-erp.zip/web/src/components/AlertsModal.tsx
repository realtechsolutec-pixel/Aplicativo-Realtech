import React from 'react';
import {
  AlertCircle,
  Bell,
  Clock,
  DollarSign,
  PackageSearch,
  ShoppingCart,
  Wrench,
  X
} from 'lucide-react';
import { useWorkshop } from '../context/WorkshopContext';
import { formatCurrency } from '../utils/formatters';

interface AlertsModalProps {
  open: boolean;
  onClose: () => void;
}

export const AlertsModal: React.FC<AlertsModalProps> = ({ open, onClose }) => {
  const {
    alerts,
    canAccessFinanceiro,
    setCurrentRoute,
    requestFinanceOverdue30dFilter,
    requestFinanceContasFixasTab,
    requestOsOverdue30dFilter
  } = useWorkshop();

  if (!open) return null;

  const hasAny = alerts.activeAlertsCount > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[88vh] flex flex-col bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 bg-bench-navy text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cobalt flex items-center justify-center">
              <Bell className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold">Central de Alertas RTerp</h3>
              <p className="text-xs text-slate-300">
                {alerts.activeAlertsCount} alerta(s) ativo(s) exigindo atenção
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-200 transition-colors"
            aria-label="Fechar alertas"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {!hasAny && (
            <div className="text-center py-10 px-4 rounded-2xl bg-emerald-50 border border-emerald-200">
              <p className="text-sm font-bold text-emerald-800">
                Tudo em dia! Nenhum alerta pendente no momento.
              </p>
              <p className="mt-1 text-xs text-emerald-700">
                Sem OS atrasadas +30 dias, sem contas vencidas e estoque monitorado.
              </p>
            </div>
          )}

          {canAccessFinanceiro && alerts.contasReceberMais30Dias.length > 0 && (
            <div className="rounded-2xl border border-red-200 bg-red-50/70 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 text-red-800 font-bold text-sm">
                  <DollarSign className="w-4 h-4" />
                  <span>
                    Contas a Receber +30 dias ({alerts.contasReceberMais30Dias.length}) —{' '}
                    {formatCurrency(alerts.totalContasReceber30Dias)}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    requestFinanceOverdue30dFilter();
                    setCurrentRoute('financeiro');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold transition-colors"
                >
                  Ver no Financeiro
                </button>
              </div>
              <ul className="space-y-1.5 text-xs text-red-900">
                {alerts.contasReceberMais30Dias.slice(0, 5).map((item) => (
                  <li key={item.transacao.id || item.transacao.descricao} className="flex justify-between gap-2">
                    <span className="truncate font-medium">
                      • {item.transacao.descricao} (+{item.diasEmAtraso}d sem receber)
                    </span>
                    <span className="font-mono-num font-bold shrink-0">
                      {formatCurrency(item.transacao.valor)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {canAccessFinanceiro && alerts.contasFixasEmAtraso.length > 0 && (
            <div className="rounded-2xl border border-red-200 bg-red-50/70 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 text-red-800 font-bold text-sm">
                  <AlertCircle className="w-4 h-4" />
                  <span>
                    Contas Fixas em Atraso ({alerts.contasFixasEmAtraso.length}) —{' '}
                    {formatCurrency(alerts.totalContasFixasEmAtraso)}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    requestFinanceContasFixasTab();
                    setCurrentRoute('financeiro');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold transition-colors"
                >
                  Abrir Contas Fixas
                </button>
              </div>
              <ul className="space-y-1.5 text-xs text-red-900">
                {alerts.contasFixasEmAtraso.slice(0, 5).map((item) => (
                  <li key={item.transacao.id || item.transacao.descricao} className="flex justify-between gap-2">
                    <span className="truncate font-medium">
                      • {item.transacao.descricao} (atrasada {item.diasEmAtraso}d)
                    </span>
                    <span className="font-mono-num font-bold shrink-0">
                      {formatCurrency(item.transacao.valor)}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {alerts.ordensMais30Dias.length > 0 && (
            <div className="rounded-2xl border border-amber-200 bg-amber-50/80 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
                  <Clock className="w-4 h-4" />
                  <span>OS +30 dias sem conclusão ({alerts.ordensMais30Dias.length})</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    requestOsOverdue30dFilter();
                    setCurrentRoute('ordens_servico');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold transition-colors"
                >
                  Filtrar OS +30d
                </button>
              </div>
              <ul className="space-y-1.5 text-xs text-amber-950">
                {alerts.ordensMais30Dias.slice(0, 5).map((item) => (
                  <li key={item.os.id || item.os.numero_os} className="flex justify-between gap-2">
                    <span className="truncate font-medium">
                      • OS #{item.os.numero_os} — {item.os.cliente_nome} ({item.os.equipamento})
                    </span>
                    <span className="font-mono-num font-bold shrink-0">{item.diasEmAberto}d aberta</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {alerts.pedidosPecasPendentes.length > 0 && (
            <div className="rounded-2xl border border-sky-200 bg-sky-50/80 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 text-sky-900 font-bold text-sm">
                  <ShoppingCart className="w-4 h-4" />
                  <span>Pedidos de Peças Pendentes ({alerts.pedidosPecasPendentes.length})</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCurrentRoute('pedidos_pecas');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-cobalt hover:bg-cobalt-dark text-white text-xs font-semibold transition-colors"
                >
                  Ver Pedidos
                </button>
              </div>
              <ul className="space-y-1 text-xs text-sky-950">
                {alerts.pedidosPecasPendentes.slice(0, 5).map((p) => (
                  <li key={p.id || p.nome_peca} className="truncate">
                    • {p.nome_peca} ({p.quantidade} un.) {p.numero_os ? `— OS #${p.numero_os}` : ''}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {alerts.pecasEstoqueBaixoCount > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <PackageSearch className="w-4 h-4 text-red-600" />
                  <span>
                    {alerts.pecasEstoqueBaixoCount} peça(s) com estoque igual ou abaixo do mínimo
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCurrentRoute('estoque');
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  Abrir Estoque
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
