import React, { useState } from 'react';
import {
  Award,
  Bell,
  ClipboardList,
  DollarSign,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  RefreshCw,
  Settings,
  ShoppingBag,
  ShoppingCart,
  Tag,
  Target,
  Users,
  X
} from 'lucide-react';
import { useWorkshop } from '../context/WorkshopContext';
import { AppRoute } from '../types/models';
import { AlertsModal } from './AlertsModal';

interface NavItem {
  route: AppRoute;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  adminOnly?: boolean;
  badgeCount?: number;
}

export const LayoutShell: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    session,
    isAdmin,
    currentRoute,
    setCurrentRoute,
    alerts,
    isLoading,
    refreshAll,
    signOut,
    toast,
    clearToast,
    configuracaoOficina
  } = useWorkshop();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);

  const navItems: NavItem[] = [
    { route: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { route: 'vendas', label: 'Vendas (PDV)', icon: ShoppingBag },
    { route: 'clientes', label: 'Clientes', icon: Users },
    {
      route: 'ordens_servico',
      label: 'Ordens de Serviço',
      icon: ClipboardList,
      badgeCount: alerts.ordensMais30Dias.length
    },
    {
      route: 'comissoes',
      label: isAdmin ? 'Rendimento & Comissões' : 'Meus Ganhos',
      icon: Award
    },
    {
      route: 'pedidos_pecas',
      label: 'Pedido de Peças',
      icon: ShoppingCart,
      badgeCount: alerts.pedidosPecasPendentes.length
    },
    {
      route: 'estoque',
      label: 'Estoque',
      icon: Package,
      badgeCount: alerts.pecasEstoqueBaixoCount
    },
    { route: 'precos', label: 'Comparar Preços', icon: Tag },
    {
      route: 'financeiro',
      label: 'Financeiro',
      icon: DollarSign,
      adminOnly: true,
      badgeCount: alerts.financeiroAlertsCount
    },
    { route: 'metas', label: 'Meta Diária', icon: Target, adminOnly: true },
    { route: 'config_oficina', label: 'Config. da Loja', icon: Settings, adminOnly: true }
  ];

  const visibleItems = navItems.filter((item) => !item.adminOnly || isAdmin);
  const currentTitle = visibleItems.find((i) => i.route === currentRoute)?.label ?? 'RTerp';

  const handleNavClick = (route: AppRoute) => {
    setCurrentRoute(route);
    setMobileMenuOpen(false);
  };

  const SidebarContent = (
    <div className="flex flex-col h-full bg-bench-dark text-white">
      {/* Brand header */}
      <div className="px-4 py-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <img
            src="/rterp-logo.png"
            alt="RTerp"
            className="w-10 h-10 rounded-xl object-cover border border-white/15 shrink-0"
          />
          <div className="min-w-0">
            <div className="font-display font-bold text-base tracking-tight text-white truncate">
              RTerp
            </div>
            <div className="text-[11px] text-slate-400 truncate">
              {configuracaoOficina.nome_loja || 'Eletrônica & Segurança'}
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMobileMenuOpen(false)}
          className="lg:hidden p-1.5 rounded-lg text-slate-300 hover:bg-white/10"
          aria-label="Fechar menu"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* User profile pill */}
      <div className="px-4 py-3 border-b border-white/10">
        <div className="rounded-xl bg-white/5 border border-white/10 px-3 py-2.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-white truncate">
              {session?.fullName || 'Usuário'}
            </span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase shrink-0 ${
                isAdmin ? 'bg-cobalt text-white' : 'bg-cyanTech text-white'
              }`}
            >
              {isAdmin ? 'Admin' : 'Operacional'}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 truncate mt-0.5">{session?.email}</div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const active = currentRoute === item.route;
          return (
            <button
              key={item.route}
              type="button"
              onClick={() => handleNavClick(item.route)}
              className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                active
                  ? 'bg-cobalt text-white shadow-sm'
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="flex items-center gap-2.5 min-w-0">
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </span>
              {typeof item.badgeCount === 'number' && item.badgeCount > 0 && (
                <span
                  className={`font-mono-num px-1.5 py-0.5 rounded-full text-[10px] font-bold shrink-0 ${
                    active ? 'bg-white text-cobalt' : 'bg-red-600 text-white'
                  }`}
                >
                  {item.badgeCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom account action + Realtech Soluções credit */}
      <div className="px-4 py-4 border-t border-white/10 space-y-3">
        <button
          type="button"
          onClick={() => signOut()}
          className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white/10 hover:bg-red-600/80 text-white text-xs font-semibold transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sair da Conta
        </button>
        <p className="text-center text-[11px] font-medium text-slate-400">
          Desenvolvido por Realtech Soluções
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-bench-bg text-slate-900">
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">
        {SidebarContent}
      </aside>

      {/* Mobile slide-over drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] h-full z-50 shadow-2xl">
            {SidebarContent}
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200 px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50"
              aria-label="Abrir menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 truncate">
                {currentTitle}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setAlertsOpen(true)}
              className="relative p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 transition-colors"
              aria-label="Central de Alertas"
              title="Central de Alertas"
            >
              <Bell className="w-4 h-4" />
              {alerts.activeAlertsCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-600 text-white font-mono-num text-[10px] font-bold flex items-center justify-center">
                  {alerts.activeAlertsCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => refreshAll()}
              disabled={isLoading}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors disabled:opacity-60"
              title="Sincronizar com Supabase"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-cobalt' : ''}`} />
              <span className="hidden sm:inline">Sincronizar</span>
            </button>
          </div>
        </header>

        {isLoading && (
          <div className="h-0.5 w-full bg-cobalt-light overflow-hidden">
            <div className="h-full w-1/3 bg-cobalt animate-pulse" />
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">{children}</main>
      </div>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-4 right-4 z-50 max-w-sm w-[calc(100vw-2rem)]">
          <div
            className={`flex items-start justify-between gap-3 px-4 py-3 rounded-2xl shadow-xl border text-sm font-medium ${
              toast.tone === 'error'
                ? 'bg-red-600 text-white border-red-700'
                : toast.tone === 'success'
                ? 'bg-bench-navy text-white border-slate-800'
                : 'bg-cobalt text-white border-cobalt-dark'
            }`}
          >
            <span>{toast.text}</span>
            <button
              type="button"
              onClick={clearToast}
              className="p-0.5 rounded hover:bg-white/20 shrink-0"
              aria-label="Fechar aviso"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      <AlertsModal open={alertsOpen} onClose={() => setAlertsOpen(false)} />
    </div>
  );
};
