import React from 'react';
import { OrdemServicoDto, STATUS_OS_META, STATUS_OS_ORDER } from '../types/models';
import { formatCurrency } from '../utils/formatters';

export const OsStatusDistributionChart: React.FC<{ ordens: OrdemServicoDto[] }> = ({ ordens }) => {
  const counts = STATUS_OS_ORDER.map((code) => ({
    meta: STATUS_OS_META[code],
    count: ordens.filter((o) => o.status === code).length
  }));
  const maxCount = Math.max(1, ...counts.map((c) => c.count));

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
      <div className="flex items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-900">Status das Ordens de Serviço</h3>
          <p className="text-xs text-slate-500">Distribuição operacional da bancada</p>
        </div>
        <span className="font-mono-num text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
          Total: {ordens.length}
        </span>
      </div>

      <div className="space-y-3">
        {counts.map(({ meta, count }) => {
          const pct = Math.round((count / maxCount) * 100);
          return (
            <div key={meta.code} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700">{meta.label}</span>
                <span className="font-mono-num font-bold text-slate-900">{count}</span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${count === 0 ? 0 : Math.max(6, pct)}%`,
                    backgroundColor: meta.barColor
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface FinanceScopeChartCardProps {
  faturamentoLoja: number;
  despesasLoja: number;
  gastosPessoais: number;
}

export const FinanceScopeChartCard: React.FC<FinanceScopeChartCardProps> = ({
  faturamentoLoja,
  despesasLoja,
  gastosPessoais
}) => {
  const maxVal = Math.max(1, faturamentoLoja, despesasLoja, gastosPessoais);
  const rows = [
    { label: 'Receitas Loja (Recebido)', value: faturamentoLoja, color: '#059669' },
    { label: 'Despesas Loja (Pago)', value: despesasLoja, color: '#DC2626' },
    { label: 'Gastos Pessoais (Pago)', value: gastosPessoais, color: '#D97706' }
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
      <div className="mb-4">
        <h3 className="text-base font-bold text-slate-900">Comparativo Financeiro (Loja vs Pessoal)</h3>
        <p className="text-xs text-slate-500">Visão consolidada do caixa separado</p>
      </div>
      <div className="space-y-4">
        {rows.map((row) => {
          const pct = Math.round((row.value / maxVal) * 100);
          return (
            <div key={row.label} className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-700">{row.label}</span>
                <span className="font-mono-num font-bold text-slate-900">
                  {formatCurrency(row.value)}
                </span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${row.value <= 0 ? 0 : Math.max(4, pct)}%`,
                    backgroundColor: row.color
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
