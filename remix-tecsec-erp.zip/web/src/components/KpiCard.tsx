import React from 'react';
import { LucideIcon } from 'lucide-react';

interface KpiCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  accentColor?: 'cobalt' | 'cyan' | 'emerald' | 'amber' | 'red' | 'violet';
  onClick?: () => void;
}

const ACCENT_CLASSES: Record<NonNullable<KpiCardProps['accentColor']>, { bg: string; text: string }> = {
  cobalt: { bg: 'bg-cobalt-light', text: 'text-cobalt' },
  cyan: { bg: 'bg-cyanTech-light', text: 'text-cyanTech' },
  emerald: { bg: 'bg-emerald-100', text: 'text-emerald-700' },
  amber: { bg: 'bg-amber-100', text: 'text-amber-700' },
  red: { bg: 'bg-red-100', text: 'text-red-700' },
  violet: { bg: 'bg-violet-100', text: 'text-violet-700' }
};

export const KpiCard: React.FC<KpiCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  accentColor = 'cobalt',
  onClick
}) => {
  const accent = ACCENT_CLASSES[accentColor];
  const Tag = onClick ? 'button' : 'div';

  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={`w-full text-left bg-white border border-slate-200 rounded-2xl p-4 shadow-sm transition-all ${
        onClick ? 'hover:border-cobalt/50 hover:shadow-md active:scale-[0.99] cursor-pointer' : ''
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-3">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
          {title}
        </span>
        <span className={`w-8 h-8 rounded-xl flex items-center justify-center ${accent.bg} ${accent.text}`}>
          <Icon className="w-4 h-4" />
        </span>
      </div>
      <div className="font-mono-num text-xl sm:text-2xl font-bold text-slate-900 truncate">
        {value}
      </div>
      {subtitle && (
        <p className="mt-1 text-xs text-slate-500 truncate">{subtitle}</p>
      )}
    </Tag>
  );
};
