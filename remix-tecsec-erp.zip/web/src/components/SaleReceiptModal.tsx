import React, { useState } from 'react';
import { Copy, MessageCircle, Printer, Receipt, X } from 'lucide-react';
import {
  ConfiguracaoOficinaDto,
  STATUS_VENDA_META,
  StatusVendaCode,
  VendaDto
} from '../types/models';
import { formatCurrency, formatDateTimeBr } from '../utils/formatters';
import {
  buildSaleThermalText,
  buildSaleWhatsAppMessage,
  openWhatsAppWeb,
  ReceiptFormat
} from '../utils/receipt';
import { useWorkshop } from '../context/WorkshopContext';

interface SaleReceiptModalProps {
  venda: VendaDto | null;
  storeConfig: ConfiguracaoOficinaDto;
  onClose: () => void;
}

export const SaleReceiptModal: React.FC<SaleReceiptModalProps> = ({
  venda,
  storeConfig,
  onClose
}) => {
  const { showToast } = useWorkshop();
  const [format, setFormat] = useState<ReceiptFormat>('PDF_A4');

  if (!venda) return null;

  const thermalText = buildSaleThermalText(venda, storeConfig);
  const statusMeta =
    STATUS_VENDA_META[(venda.status as StatusVendaCode) || 'CONCLUIDA'] ??
    STATUS_VENDA_META.CONCLUIDA;

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(thermalText);
      showToast('Cupom de venda copiado para a área de transferência.', 'success');
    } catch {
      showToast('Não foi possível copiar automaticamente.', 'error');
    }
  };

  const handleWhatsApp = () => {
    const msg = buildSaleWhatsAppMessage(venda, storeConfig);
    openWhatsAppWeb(venda.cliente_telefone, msg);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-3xl max-h-[92vh] flex flex-col bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 bg-bench-navy text-white">
          <div className="flex items-center gap-2.5">
            <Receipt className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-base font-bold">
                Nota / Cupom de Venda #{venda.numero_venda}
              </h3>
              <p className="text-xs text-slate-300">
                {venda.cliente_nome || 'Consumidor Final'} • {venda.forma_pagamento}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-200 transition-colors"
            aria-label="Fechar nota de venda"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Format switcher */}
        <div className="px-5 py-3 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
          <span
            className={`px-3 py-1 rounded-full text-xs font-bold ${statusMeta.badgeBg} ${statusMeta.badgeText}`}
          >
            Status: {statusMeta.label}
          </span>

          <div className="flex gap-1.5 bg-slate-200/70 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setFormat('PDF_A4')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                format === 'PDF_A4' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Nota A4 / PDF
            </button>
            <button
              type="button"
              onClick={() => setFormat('TERMICA_80MM')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                format === 'TERMICA_80MM' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600'
              }`}
            >
              Cupom Térmica 80mm
            </button>
          </div>
        </div>

        {/* Printable area */}
        <div className="flex-1 overflow-y-auto p-5 bg-slate-100">
          <div id="receipt-print-area">
            {format === 'TERMICA_80MM' ? (
              <div className="mx-auto max-w-sm bg-amber-50/40 border border-slate-300 rounded-xl p-4 shadow-sm">
                <pre className="font-mono text-xs leading-relaxed text-slate-900 whitespace-pre-wrap">
                  {thermalText}
                </pre>
              </div>
            ) : (
              <div className="mx-auto max-w-2xl bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-5 text-slate-900">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-950">
                      {storeConfig.nome_loja || 'RTerp Eletrônica & Segurança'}
                    </h4>
                    {storeConfig.cnpj && (
                      <p className="text-xs text-slate-600">CNPJ: {storeConfig.cnpj}</p>
                    )}
                    {storeConfig.telefone && (
                      <p className="text-xs text-slate-600">Tel: {storeConfig.telefone}</p>
                    )}
                    {storeConfig.endereco && (
                      <p className="text-xs text-slate-600">{storeConfig.endereco}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-3 py-1 rounded-full bg-cobalt-light text-cobalt text-xs font-bold uppercase">
                      Nota de Venda (Sem Valor Fiscal)
                    </span>
                    <div className="mt-1 font-mono-num text-xl font-bold text-slate-950">
                      Venda #{venda.numero_venda}
                    </div>
                    <p className="text-xs text-slate-500">
                      {formatDateTimeBr(venda.data_venda || venda.created_at)}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold uppercase text-slate-500">Cliente</span>
                    <p className="text-sm font-bold text-slate-900 mt-0.5">
                      {venda.cliente_nome || 'Consumidor Final'}
                    </p>
                    {venda.cliente_telefone && (
                      <p className="text-slate-600">Tel/Whats: {venda.cliente_telefone}</p>
                    )}
                  </div>
                  <div>
                    <span className="font-bold uppercase text-slate-500">Pagamento & Vendedor</span>
                    <p className="text-slate-800 font-semibold mt-0.5">
                      Forma: {venda.forma_pagamento}
                    </p>
                    {venda.vendedor_nome && (
                      <p className="text-slate-700">Vendedor: {venda.vendedor_nome}</p>
                    )}
                  </div>
                </div>

                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase">
                      <tr>
                        <th className="py-2.5 px-3">Item</th>
                        <th className="py-2.5 px-3 text-right">Qtd</th>
                        <th className="py-2.5 px-3 text-right">Unitário</th>
                        <th className="py-2.5 px-3 text-right">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(venda.itens || []).map((item, idx) => (
                        <tr key={`${item.peca_id || idx}-${item.nome}`}>
                          <td className="py-2.5 px-3">
                            <div className="font-semibold text-slate-900">{item.nome}</div>
                            {item.codigo_sku && (
                              <div className="font-mono text-[10px] text-slate-500">
                                SKU: {item.codigo_sku}
                              </div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-num">
                            {item.quantidade}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-num">
                            {formatCurrency(item.preco_unitario)}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono-num font-bold text-slate-900">
                            {formatCurrency(item.subtotal)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-bench-navy text-white">
                  <div className="text-xs space-y-0.5 text-slate-300">
                    <p>Subtotal: {formatCurrency(venda.subtotal)}</p>
                    {venda.desconto > 0 && <p>Desconto: -{formatCurrency(venda.desconto)}</p>}
                    <p className="text-cyan-300 font-semibold">
                      {(venda.itens || []).reduce((acc, i) => acc + i.quantidade, 0)} unidade(s)
                      baixadas do estoque
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] uppercase text-slate-300">Valor Total</span>
                    <div className="font-mono-num text-xl font-bold text-white">
                      {formatCurrency(venda.valor_total)}
                    </div>
                  </div>
                </div>

                {venda.observacoes && (
                  <p className="text-xs text-slate-600 border-t border-slate-200 pt-3">
                    Observações: {venda.observacoes}
                  </p>
                )}

                <p className="text-[11px] text-slate-500 text-center border-t border-slate-200 pt-3">
                  Documento auxiliar de venda (sem valor fiscal) • {storeConfig.nome_loja || 'RTerp'}
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-200 bg-white flex flex-wrap items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={handleCopyText}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
          >
            <Copy className="w-4 h-4" />
            Copiar Cupom
          </button>
          <button
            type="button"
            onClick={handleWhatsApp}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            Enviar WhatsApp
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cobalt hover:bg-cobalt-dark text-white text-xs font-semibold transition-colors"
          >
            <Printer className="w-4 h-4" />
            Imprimir / Salvar PDF
          </button>
        </div>
      </div>
    </div>
  );
};
