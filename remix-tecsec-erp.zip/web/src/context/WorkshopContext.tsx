import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  AppRoute,
  ClienteDto,
  ConfiguracaoOficinaDto,
  CotacaoPrecoDto,
  DEFAULT_CONFIG_OFICINA,
  DEFAULT_META_DIARIA,
  FuncionarioDto,
  isEstoqueBaixo,
  MetaDiariaDto,
  OrdemServicoDto,
  OsViewMode,
  PecaEstoqueDto,
  PedidoPecaDto,
  PedidoPecaStatusCode,
  RegistrarVendaInput,
  StatusOSCode,
  TransacaoFinanceiraDto,
  UserRole,
  UserSession,
  VendaDto
} from '../types/models';
import { computeWorkshopAlerts, WorkshopAlerts } from '../utils/alerts';
import { findFuncionarioForSession } from '../utils/commission';
import { formatBytes, nowIsoTimestamp, todayIsoDate } from '../utils/formatters';
import { CompressionPresetCode } from '../utils/imageCompressor';
import * as api from '../services/workshopApi';
import { SupabaseHttpError } from '../services/supabaseClient';

export interface ToastMessage {
  id: number;
  text: string;
  tone: 'info' | 'success' | 'error';
}

interface WorkshopContextValue {
  session: UserSession | null;
  authChecking: boolean;
  authLoading: boolean;
  authError: string | null;
  authInfo: string | null;
  isLoading: boolean;
  isSubmitting: boolean;
  currentRoute: AppRoute;
  setCurrentRoute: (route: AppRoute) => void;
  osViewMode: OsViewMode;
  setOsViewMode: (mode: OsViewMode) => void;
  compressionPreset: CompressionPresetCode;
  setCompressionPreset: (preset: CompressionPresetCode) => void;
  toast: ToastMessage | null;
  showToast: (text: string, tone?: ToastMessage['tone']) => void;
  clearToast: () => void;
  clearAuthFeedback: () => void;

  // Data
  clientes: ClienteDto[];
  ordens: OrdemServicoDto[];
  pecas: PecaEstoqueDto[];
  transacoes: TransacaoFinanceiraDto[];
  configuracaoOficina: ConfiguracaoOficinaDto;
  metaDiaria: MetaDiariaDto;
  cotacoes: CotacaoPrecoDto[];
  funcionarios: FuncionarioDto[];
  pedidosPecas: PedidoPecaDto[];
  vendas: VendaDto[];

  // Derived metrics
  isAdmin: boolean;
  canAccessFinanceiro: boolean;
  alerts: WorkshopAlerts;
  osAbertasCount: number;
  osProntasCount: number;
  pecasEstoqueBaixo: PecaEstoqueDto[];
  faturamentoLojaRecebido: number;
  despesasLojaPagas: number;
  saldoLoja: number;
  aReceberPendenteLoja: number;
  aPagarPendenteLoja: number;
  gastosPessoaisPagos: number;
  gastosPessoaisPendentes: number;
  ticketMedioRealOs: number;
  nextNumeroOs: number;
  totalVendasHoje: number;
  totalVendasMes: number;

  // One-shot nav requests
  financeContasFixasTabRequested: boolean;
  financeOverdue30dFilterRequested: boolean;
  osOverdue30dFilterRequested: boolean;
  requestFinanceContasFixasTab: () => void;
  requestFinanceOverdue30dFilter: () => void;
  clearFinanceNavRequests: () => void;
  requestOsOverdue30dFilter: () => void;
  clearOsNavRequests: () => void;

  // Auth actions
  signIn: (email: string, password: string, role: UserRole) => Promise<void>;
  signUpOwner: (fullName: string, email: string, password: string) => Promise<void>;
  signUpEmployee: (
    fullName: string,
    email: string,
    password: string,
    workshopCode: string
  ) => Promise<void>;
  signOut: () => Promise<void>;

  // Sync & CRUD actions
  refreshAll: () => Promise<void>;
  saveCliente: (cliente: ClienteDto) => Promise<boolean>;
  deleteCliente: (id: string) => Promise<void>;
  saveOrdemServico: (os: OrdemServicoDto, localFiles?: File[]) => Promise<OrdemServicoDto | null>;
  updateOsStatus: (os: OrdemServicoDto, newStatus: StatusOSCode) => Promise<void>;
  deleteOrdemServico: (id: string) => Promise<void>;
  lancarOsNoFinanceiro: (os: OrdemServicoDto) => Promise<void>;
  savePeca: (peca: PecaEstoqueDto, localFile?: File | null) => Promise<boolean>;
  adjustPecaQuantity: (peca: PecaEstoqueDto, delta: number) => Promise<void>;
  deletePeca: (id: string) => Promise<void>;
  saveTransacao: (tx: TransacaoFinanceiraDto) => Promise<boolean>;
  toggleTransacaoStatus: (tx: TransacaoFinanceiraDto) => Promise<void>;
  deleteTransacao: (id: string) => Promise<void>;
  saveConfiguracaoOficina: (cfg: ConfiguracaoOficinaDto) => Promise<boolean>;
  createFuncionario: (params: {
    nome: string;
    email: string;
    password: string;
    cargo: string;
    comissaoPercentual: number;
  }) => Promise<boolean>;
  updateFuncionarioPerfil: (
    func: FuncionarioDto,
    cargo: string,
    comissaoPercentual: number
  ) => Promise<boolean>;
  toggleFuncionarioAtivo: (func: FuncionarioDto) => Promise<void>;
  deleteFuncionario: (id: string) => Promise<void>;
  saveMetaDiaria: (meta: MetaDiariaDto) => Promise<boolean>;
  saveCotacao: (cotacao: CotacaoPrecoDto) => Promise<boolean>;
  deleteCotacao: (id: string) => Promise<void>;
  savePedidoPeca: (pedido: PedidoPecaDto) => Promise<boolean>;
  updatePedidoPecaStatus: (pedido: PedidoPecaDto, nextStatus: PedidoPecaStatusCode) => Promise<void>;
  deletePedidoPeca: (id: string) => Promise<void>;
  registrarVenda: (input: RegistrarVendaInput) => Promise<VendaDto | null>;
  cancelarVenda: (id: string) => Promise<boolean>;
}

const WorkshopContext = createContext<WorkshopContextValue | null>(null);

export function WorkshopProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<UserSession | null>(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authInfo, setAuthInfo] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentRoute, setCurrentRouteState] = useState<AppRoute>('dashboard');
  const [osViewMode, setOsViewMode] = useState<OsViewMode>('LISTA');
  const [compressionPreset, setCompressionPresetState] = useState<CompressionPresetCode>(() =>
    api.loadStoredPreset()
  );
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const [clientes, setClientes] = useState<ClienteDto[]>([]);
  const [ordens, setOrdens] = useState<OrdemServicoDto[]>([]);
  const [pecas, setPecas] = useState<PecaEstoqueDto[]>([]);
  const [transacoes, setTransacoes] = useState<TransacaoFinanceiraDto[]>([]);
  const [configuracaoOficina, setConfiguracaoOficina] =
    useState<ConfiguracaoOficinaDto>(DEFAULT_CONFIG_OFICINA);
  const [metaDiaria, setMetaDiaria] = useState<MetaDiariaDto>(DEFAULT_META_DIARIA);
  const [cotacoes, setCotacoes] = useState<CotacaoPrecoDto[]>([]);
  const [funcionarios, setFuncionarios] = useState<FuncionarioDto[]>([]);
  const [pedidosPecas, setPedidosPecas] = useState<PedidoPecaDto[]>([]);
  const [vendas, setVendas] = useState<VendaDto[]>([]);

  const [financeContasFixasTabRequested, setFinanceContasFixasTabRequested] = useState(false);
  const [financeOverdue30dFilterRequested, setFinanceOverdue30dFilterRequested] = useState(false);
  const [osOverdue30dFilterRequested, setOsOverdue30dFilterRequested] = useState(false);

  const isAdmin = session?.role === 'ADMIN';
  const canAccessFinanceiro = session?.role === 'ADMIN';

  const showToast = useCallback((text: string, tone: ToastMessage['tone'] = 'info') => {
    setToast({ id: Date.now(), text, tone });
  }, []);

  const clearToast = useCallback(() => setToast(null), []);
  const clearAuthFeedback = useCallback(() => {
    setAuthError(null);
    setAuthInfo(null);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 4200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const resetDomainData = useCallback(() => {
    setClientes([]);
    setOrdens([]);
    setPecas([]);
    setTransacoes([]);
    setConfiguracaoOficina(DEFAULT_CONFIG_OFICINA);
    setMetaDiaria(DEFAULT_META_DIARIA);
    setCotacoes([]);
    setFuncionarios([]);
    setPedidosPecas([]);
    setVendas([]);
    setCurrentRouteState('dashboard');
  }, []);

  const handleError = useCallback(
    (err: unknown, fallback: string) => {
      if (err instanceof SupabaseHttpError && err.unauthorized) {
        api.saveStoredSession(null);
        setSession(null);
        resetDomainData();
        setAuthError('Sessão expirada. Faça login novamente.');
        return;
      }
      const message = err instanceof Error ? err.message : fallback;
      showToast(message || fallback, 'error');
    },
    [resetDomainData, showToast]
  );

  const refreshAll = useCallback(
    async (explicitSession?: UserSession | null) => {
      const active = explicitSession ?? session;
      if (!active) return;
      const canFin = active.role === 'ADMIN';
      setIsLoading(true);
      try {
        const tasks = await Promise.allSettled([
          api.fetchClientes(),
          api.fetchOrdensServico(),
          api.fetchPecas(),
          api.fetchConfiguracaoOficina(),
          api.fetchCotacoes(),
          api.fetchPedidosPecas(),
          api.fetchFuncionarios(),
          api.fetchVendas(),
          canFin ? api.fetchTransacoes() : Promise.resolve([] as TransacaoFinanceiraDto[]),
          canFin ? api.fetchMetaDiaria() : Promise.resolve(null)
        ]);

        const [cRes, osRes, pRes, cfgRes, cotRes, pedRes, fRes, vRes, txRes, mRes] = tasks;

        if (cRes.status === 'fulfilled') setClientes(cRes.value);
        if (osRes.status === 'fulfilled') setOrdens(osRes.value);
        if (pRes.status === 'fulfilled') setPecas(pRes.value);
        if (cfgRes.status === 'fulfilled' && cfgRes.value) setConfiguracaoOficina(cfgRes.value);
        if (cotRes.status === 'fulfilled') setCotacoes(cotRes.value);
        if (pedRes.status === 'fulfilled') setPedidosPecas(pedRes.value);
        if (fRes.status === 'fulfilled') setFuncionarios(fRes.value);
        if (vRes.status === 'fulfilled') setVendas(vRes.value);

        if (canFin) {
          if (txRes.status === 'fulfilled') setTransacoes(txRes.value);
          if (mRes.status === 'fulfilled' && mRes.value) setMetaDiaria(mRes.value);
        } else {
          setTransacoes([]);
          setMetaDiaria(DEFAULT_META_DIARIA);
        }

        const firstRejected = tasks.find((t) => t.status === 'rejected') as
          | PromiseRejectedResult
          | undefined;
        if (firstRejected) {
          handleError(firstRejected.reason, 'Alguns dados não puderam ser sincronizados.');
        }
      } finally {
        setIsLoading(false);
      }
    },
    [handleError, session]
  );

  useEffect(() => {
    let active = true;
    (async () => {
      const valid = await api.getValidSession();
      if (!active) return;
      setSession(valid);
      setAuthChecking(false);
      if (valid) {
        await refreshAll(valid);
      }
    })();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setCurrentRoute = useCallback(
    (route: AppRoute) => {
      const adminOnly: AppRoute[] = ['financeiro', 'metas', 'config_oficina'];
      if (adminOnly.includes(route) && !isAdmin) {
        showToast('Acesso restrito ao proprietário.', 'error');
        return;
      }
      setCurrentRouteState(route);
    },
    [isAdmin, showToast]
  );

  const setCompressionPreset = useCallback((preset: CompressionPresetCode) => {
    setCompressionPresetState(preset);
    api.saveStoredPreset(preset);
  }, []);

  const signIn = useCallback(
    async (email: string, password: string, role: UserRole) => {
      if (!email.trim() || !password) {
        setAuthError('Informe e-mail e senha para entrar.');
        return;
      }
      setAuthLoading(true);
      setAuthError(null);
      setAuthInfo(null);
      try {
        const logged = await api.signInWithEmail(email, password, role);
        setSession(logged);
        setCurrentRouteState('dashboard');
        await refreshAll(logged);
      } catch (err) {
        setAuthError(err instanceof Error ? err.message : 'Falha ao fazer login.');
      } finally {
        setAuthLoading(false);
      }
    },
    [refreshAll]
  );

  const signUpOwner = useCallback(
    async (fullName: string, email: string, password: string) => {
      if (!fullName.trim() || !email.trim() || password.length < 6) {
        setAuthError('Preencha nome, e-mail válido e senha com pelo menos 6 caracteres.');
        return;
      }
      setAuthLoading(true);
      setAuthError(null);
      setAuthInfo(null);
      try {
        const status = await api.signUpOwner(fullName, email, password);
        if (status === 'CONFIRM_EMAIL') {
          setAuthInfo('Cadastro criado! Confirme o link enviado ao seu e-mail para entrar.');
        } else {
          const logged = api.loadStoredSession();
          setSession(logged);
          if (logged) await refreshAll(logged);
        }
      } catch (err) {
        setAuthError(err instanceof Error ? err.message : 'Não foi possível criar a conta.');
      } finally {
        setAuthLoading(false);
      }
    },
    [refreshAll]
  );

  const signUpEmployee = useCallback(
    async (fullName: string, email: string, password: string, workshopCode: string) => {
      if (!fullName.trim() || !email.trim() || password.length < 6 || !workshopCode.trim()) {
        setAuthError(
          'Informe seu nome, o Código da Oficina, e-mail válido e senha (mín. 6 caracteres).'
        );
        return;
      }
      setAuthLoading(true);
      setAuthError(null);
      setAuthInfo(null);
      try {
        const status = await api.signUpEmployee(fullName, email, password, workshopCode);
        if (status === 'CONFIRM_EMAIL') {
          setAuthInfo(
            'Acesso de funcionário criado! Confirme o link enviado ao seu e-mail para entrar.'
          );
        } else {
          const logged = api.loadStoredSession();
          setSession(logged);
          if (logged) await refreshAll(logged);
        }
      } catch (err) {
        setAuthError(
          err instanceof Error ? err.message : 'Não foi possível vincular a conta de funcionário.'
        );
      } finally {
        setAuthLoading(false);
      }
    },
    [refreshAll]
  );

  const signOut = useCallback(async () => {
    await api.signOutSession();
    setSession(null);
    resetDomainData();
  }, [resetDomainData]);

  // Derived metrics
  const alerts = useMemo(
    () =>
      computeWorkshopAlerts({
        ordens,
        transacoes,
        pedidosPecas,
        pecas,
        canAccessFinanceiro
      }),
    [ordens, transacoes, pedidosPecas, pecas, canAccessFinanceiro]
  );

  const osAbertasCount = useMemo(
    () => ordens.filter((o) => o.status !== 'ENTREGUE').length,
    [ordens]
  );
  const osProntasCount = useMemo(
    () => ordens.filter((o) => o.status === 'PRONTA').length,
    [ordens]
  );
  const pecasEstoqueBaixo = useMemo(() => pecas.filter(isEstoqueBaixo), [pecas]);

  const faturamentoLojaRecebido = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'LOJA' && t.tipo === 'RECEBER' && t.status === 'PAGO')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const despesasLojaPagas = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'LOJA' && t.tipo === 'PAGAR' && t.status === 'PAGO')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const saldoLoja = faturamentoLojaRecebido - despesasLojaPagas;

  const aReceberPendenteLoja = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'LOJA' && t.tipo === 'RECEBER' && t.status === 'PENDENTE')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const aPagarPendenteLoja = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'LOJA' && t.tipo === 'PAGAR' && t.status === 'PENDENTE')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const gastosPessoaisPagos = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'PESSOAL' && t.tipo === 'PAGAR' && t.status === 'PAGO')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const gastosPessoaisPendentes = useMemo(
    () =>
      transacoes
        .filter((t) => t.escopo === 'PESSOAL' && t.tipo === 'PAGAR' && t.status === 'PENDENTE')
        .reduce((sum, t) => sum + t.valor, 0),
    [transacoes]
  );

  const ticketMedioRealOs = useMemo(() => {
    const valued = ordens.filter((o) => o.valor_total > 0);
    if (!valued.length) return 0;
    return valued.reduce((sum, o) => sum + o.valor_total, 0) / valued.length;
  }, [ordens]);

  const nextNumeroOs = useMemo(() => {
    if (!ordens.length) return 1001;
    return Math.max(...ordens.map((o) => o.numero_os || 1000)) + 1;
  }, [ordens]);

  const totalVendasHoje = useMemo(() => {
    const todayPrefix = todayIsoDate();
    return vendas
      .filter((v) => v.status !== 'CANCELADA' && (v.data_venda || v.created_at || '').startsWith(todayPrefix))
      .reduce((sum, v) => sum + (v.valor_total || 0), 0);
  }, [vendas]);

  const totalVendasMes = useMemo(() => {
    const monthPrefix = todayIsoDate().slice(0, 7);
    return vendas
      .filter((v) => v.status !== 'CANCELADA' && (v.data_venda || v.created_at || '').startsWith(monthPrefix))
      .reduce((sum, v) => sum + (v.valor_total || 0), 0);
  }, [vendas]);

  // Nav requests
  const requestFinanceContasFixasTab = useCallback(() => {
    setFinanceContasFixasTabRequested(true);
    setFinanceOverdue30dFilterRequested(false);
  }, []);

  const requestFinanceOverdue30dFilter = useCallback(() => {
    setFinanceOverdue30dFilterRequested(true);
    setFinanceContasFixasTabRequested(false);
  }, []);

  const clearFinanceNavRequests = useCallback(() => {
    setFinanceContasFixasTabRequested(false);
    setFinanceOverdue30dFilterRequested(false);
  }, []);

  const requestOsOverdue30dFilter = useCallback(() => {
    setOsOverdue30dFilterRequested(true);
    setOsViewMode('LISTA');
  }, []);

  const clearOsNavRequests = useCallback(() => {
    setOsOverdue30dFilterRequested(false);
  }, []);

  // CRUD actions
  const saveCliente = useCallback(
    async (cliente: ClienteDto): Promise<boolean> => {
      setIsSubmitting(true);
      try {
        const saved = await api.saveCliente(cliente);
        setClientes((prev) =>
          (cliente.id
            ? prev.map((c) => (c.id === saved.id ? saved : c))
            : [...prev, saved]
          ).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
        );
        showToast('Cliente salvo no Supabase.', 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar cliente.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const deleteCliente = useCallback(
    async (id: string) => {
      setIsSubmitting(true);
      try {
        await api.deleteCliente(id);
        setClientes((prev) => prev.filter((c) => c.id !== id));
        showToast('Cliente removido.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao remover cliente.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const saveOrdemServico = useCallback(
    async (os: OrdemServicoDto, localFiles: File[] = []): Promise<OrdemServicoDto | null> => {
      setIsSubmitting(true);
      try {
        const uploadedUrls: string[] = [];
        let origBytes = 0;
        let compBytes = 0;

        for (const file of localFiles) {
          const uploaded = await api.uploadImageToSupabase(file, 'os', compressionPreset);
          uploadedUrls.push(uploaded.publicUrl);
          origBytes += uploaded.originalBytes;
          compBytes += uploaded.compressedBytes;
        }

        const matchingFunc = findFuncionarioForSession(session, funcionarios);
        let attributedOs = { ...os };
        if (!attributedOs.id) {
          const creator = attributedOs.criado_por_nome?.trim() || session?.fullName || '';
          if (!attributedOs.tecnico_nome?.trim() && session) {
            attributedOs = {
              ...attributedOs,
              tecnico_id: matchingFunc?.id ?? null,
              tecnico_nome: matchingFunc?.nome ?? session.fullName,
              tecnico_email: matchingFunc?.email ?? session.email,
              criado_por_nome: creator,
              comissao_percentual:
                attributedOs.comissao_percentual > 0
                  ? attributedOs.comissao_percentual
                  : (matchingFunc?.comissao_percentual ?? 0)
            };
          } else {
            attributedOs.criado_por_nome = creator;
          }
          attributedOs.numero_os = nextNumeroOs;
        }

        attributedOs.fotos_urls = [...(attributedOs.fotos_urls ?? []), ...uploadedUrls];

        const saved = await api.saveOrdemServico(attributedOs);
        setOrdens((prev) =>
          (os.id
            ? prev.map((o) => (o.id === saved.id ? saved : o))
            : [saved, ...prev]
          ).sort((a, b) => b.numero_os - a.numero_os)
        );

        let note = '';
        if (uploadedUrls.length > 0 && origBytes > 0) {
          const pct = Math.min(99, Math.max(0, Math.round(((origBytes - compBytes) / origBytes) * 100)));
          note = ` • Fotos WebP: ${formatBytes(origBytes)} → ${formatBytes(compBytes)} (-${pct}%)`;
        }
        showToast(`OS #${saved.numero_os} salva${note}`, 'success');
        return saved;
      } catch (err) {
        handleError(err, 'Erro ao salvar Ordem de Serviço.');
        return null;
      } finally {
        setIsSubmitting(false);
      }
    },
    [compressionPreset, funcionarios, handleError, nextNumeroOs, session, showToast]
  );

  const updateOsStatus = useCallback(
    async (os: OrdemServicoDto, newStatus: StatusOSCode) => {
      await saveOrdemServico({
        ...os,
        status: newStatus,
        data_saida:
          newStatus === 'ENTREGUE' && !os.data_saida ? nowIsoTimestamp() : os.data_saida
      });
    },
    [saveOrdemServico]
  );

  const deleteOrdemServico = useCallback(
    async (id: string) => {
      setIsSubmitting(true);
      try {
        await api.deleteOrdemServico(id);
        setOrdens((prev) => prev.filter((o) => o.id !== id));
        showToast('Ordem de Serviço excluída.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao excluir Ordem de Serviço.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const lancarOsNoFinanceiro = useCallback(
    async (os: OrdemServicoDto) => {
      if (!canAccessFinanceiro) {
        showToast('Acesso ao módulo Financeiro restrito ao proprietário.', 'error');
        return;
      }
      setIsSubmitting(true);
      try {
        const saved = await api.saveTransacao({
          os_id: os.id ?? null,
          descricao: `OS #${os.numero_os} - ${os.equipamento} (${os.cliente_nome})`,
          categoria: 'Ordem de Serviço',
          tipo: 'RECEBER',
          escopo: 'LOJA',
          status: os.status === 'ENTREGUE' ? 'PAGO' : 'PENDENTE',
          valor: os.valor_total,
          forma_pagamento: 'PIX',
          data_vencimento: todayIsoDate(),
          data_pagamento: os.status === 'ENTREGUE' ? todayIsoDate() : null,
          is_conta_fixa: false,
          observacoes: `Lançado automaticamente a partir da OS #${os.numero_os}`
        });
        setTransacoes((prev) => [saved, ...prev]);
        showToast(`OS #${os.numero_os} lançada no Financeiro (Loja).`, 'success');
      } catch (err) {
        handleError(err, 'Erro ao lançar OS no Financeiro.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const savePeca = useCallback(
    async (peca: PecaEstoqueDto, localFile?: File | null): Promise<boolean> => {
      setIsSubmitting(true);
      try {
        let fotoUrl = peca.foto_url;
        let compressionNote = '';
        if (localFile) {
          const uploaded = await api.uploadImageToSupabase(localFile, 'pecas', compressionPreset);
          fotoUrl = uploaded.publicUrl;
          if (uploaded.originalBytes > 0) {
            const pct = Math.min(
              99,
              Math.max(
                0,
                Math.round(
                  ((uploaded.originalBytes - uploaded.compressedBytes) / uploaded.originalBytes) * 100
                )
              )
            );
            compressionNote = ` • WebP: ${formatBytes(uploaded.originalBytes)} → ${formatBytes(uploaded.compressedBytes)} (-${pct}%)`;
          }
        }
        const saved = await api.savePeca({ ...peca, foto_url: fotoUrl });
        setPecas((prev) =>
          (peca.id
            ? prev.map((p) => (p.id === saved.id ? saved : p))
            : [...prev, saved]
          ).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
        );
        showToast(`Peça salva no estoque${compressionNote}`, 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar peça.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [compressionPreset, handleError, showToast]
  );

  const adjustPecaQuantity = useCallback(
    async (peca: PecaEstoqueDto, delta: number) => {
      const nextQty = Math.max(0, peca.quantidade + delta);
      if (nextQty === peca.quantidade) return;
      await savePeca({ ...peca, quantidade: nextQty });
    },
    [savePeca]
  );

  const deletePeca = useCallback(
    async (id: string) => {
      setIsSubmitting(true);
      try {
        await api.deletePeca(id);
        setPecas((prev) => prev.filter((p) => p.id !== id));
        showToast('Peça removida do estoque.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao remover peça.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const saveTransacao = useCallback(
    async (tx: TransacaoFinanceiraDto): Promise<boolean> => {
      if (!canAccessFinanceiro) {
        showToast('Acesso ao módulo Financeiro restrito ao proprietário.', 'error');
        return false;
      }
      setIsSubmitting(true);
      try {
        const saved = await api.saveTransacao(tx);
        setTransacoes((prev) =>
          tx.id ? prev.map((t) => (t.id === saved.id ? saved : t)) : [saved, ...prev]
        );
        showToast('Lançamento financeiro salvo.', 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar lançamento.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const toggleTransacaoStatus = useCallback(
    async (tx: TransacaoFinanceiraDto) => {
      const nextStatus = tx.status === 'PAGO' ? 'PENDENTE' : 'PAGO';
      await saveTransacao({
        ...tx,
        status: nextStatus,
        data_pagamento: nextStatus === 'PAGO' ? todayIsoDate() : null
      });
    },
    [saveTransacao]
  );

  const deleteTransacao = useCallback(
    async (id: string) => {
      if (!canAccessFinanceiro) return;
      setIsSubmitting(true);
      try {
        await api.deleteTransacao(id);
        setTransacoes((prev) => prev.filter((t) => t.id !== id));
        showToast('Lançamento excluído.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao excluir lançamento.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const saveConfiguracaoOficina = useCallback(
    async (cfg: ConfiguracaoOficinaDto): Promise<boolean> => {
      if (!isAdmin) return false;
      setIsSubmitting(true);
      try {
        const saved = await api.saveConfiguracaoOficina(cfg);
        setConfiguracaoOficina(saved);
        showToast('Dados da loja e OS salvos.', 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar configurações da oficina.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, isAdmin, showToast]
  );

  const createFuncionario = useCallback(
    async (params: {
      nome: string;
      email: string;
      password: string;
      cargo: string;
      comissaoPercentual: number;
    }): Promise<boolean> => {
      if (!isAdmin) return false;
      if (funcionarios.length >= 4) {
        showToast('Limite máximo de 4 acessos de funcionários por oficina atingido.', 'error');
        return false;
      }
      setIsSubmitting(true);
      try {
        const saved = await api.createFuncionarioAccount(params);
        setFuncionarios((prev) =>
          [...prev, saved].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'))
        );
        showToast(
          `Funcionário ${saved.nome} cadastrado (${Math.round(saved.comissao_percentual)}% mão de obra).`,
          'success'
        );
        return true;
      } catch (err) {
        handleError(err, 'Erro ao cadastrar funcionário.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [funcionarios.length, handleError, isAdmin, showToast]
  );

  const updateFuncionarioPerfil = useCallback(
    async (
      func: FuncionarioDto,
      cargo: string,
      comissaoPercentual: number
    ): Promise<boolean> => {
      if (!isAdmin) return false;
      setIsSubmitting(true);
      try {
        const saved = await api.updateFuncionarioPerfil(func, cargo, comissaoPercentual);
        setFuncionarios((prev) => prev.map((f) => (f.id === saved.id ? saved : f)));
        showToast(
          `${saved.nome} atualizado: ${saved.cargo} • ${Math.round(saved.comissao_percentual)}% mão de obra.`,
          'success'
        );
        return true;
      } catch (err) {
        handleError(err, 'Erro ao atualizar comissão.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, isAdmin, showToast]
  );

  const toggleFuncionarioAtivo = useCallback(
    async (func: FuncionarioDto) => {
      if (!isAdmin) return;
      setIsSubmitting(true);
      try {
        const saved = await api.toggleFuncionarioAtivo(func);
        setFuncionarios((prev) => prev.map((f) => (f.id === saved.id ? saved : f)));
        showToast(
          saved.ativo ? 'Funcionário reativado.' : 'Acesso do funcionário desativado.',
          'info'
        );
      } catch (err) {
        handleError(err, 'Erro ao alterar status do funcionário.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, isAdmin, showToast]
  );

  const deleteFuncionario = useCallback(
    async (id: string) => {
      if (!isAdmin) return;
      setIsSubmitting(true);
      try {
        await api.deleteFuncionario(id);
        setFuncionarios((prev) => prev.filter((f) => f.id !== id));
        showToast('Funcionário removido da equipe.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao remover funcionário.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, isAdmin, showToast]
  );

  const saveMetaDiaria = useCallback(
    async (meta: MetaDiariaDto): Promise<boolean> => {
      if (!canAccessFinanceiro) return false;
      setIsSubmitting(true);
      try {
        const saved = await api.saveMetaDiaria(meta);
        setMetaDiaria(saved);
        showToast('Meta diária atualizada no Supabase.', 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar metas.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const saveCotacao = useCallback(
    async (cotacao: CotacaoPrecoDto): Promise<boolean> => {
      setIsSubmitting(true);
      try {
        const saved = await api.saveCotacao(cotacao);
        setCotacoes((prev) =>
          cotacao.id ? prev.map((c) => (c.id === saved.id ? saved : c)) : [saved, ...prev]
        );
        showToast('Cotação salva para comparativo.', 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar cotação.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const deleteCotacao = useCallback(
    async (id: string) => {
      setIsSubmitting(true);
      try {
        await api.deleteCotacao(id);
        setCotacoes((prev) => prev.filter((c) => c.id !== id));
        showToast('Cotação removida.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao remover cotação.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const savePedidoPeca = useCallback(
    async (pedido: PedidoPecaDto): Promise<boolean> => {
      setIsSubmitting(true);
      try {
        const enriched: PedidoPecaDto = {
          ...pedido,
          solicitado_por: pedido.solicitado_por?.trim() || session?.fullName || ''
        };
        const saved = await api.savePedidoPeca(enriched);
        setPedidosPecas((prev) =>
          pedido.id ? prev.map((p) => (p.id === saved.id ? saved : p)) : [saved, ...prev]
        );
        showToast(`Pedido de peça (${saved.nome_peca}) salvo na lista.`, 'success');
        return true;
      } catch (err) {
        handleError(err, 'Erro ao salvar pedido de peça.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, session?.fullName, showToast]
  );

  const updatePedidoPecaStatus = useCallback(
    async (pedido: PedidoPecaDto, nextStatus: PedidoPecaStatusCode) => {
      await savePedidoPeca({ ...pedido, status: nextStatus });
    },
    [savePedidoPeca]
  );

  const deletePedidoPeca = useCallback(
    async (id: string) => {
      setIsSubmitting(true);
      try {
        await api.deletePedidoPeca(id);
        setPedidosPecas((prev) => prev.filter((p) => p.id !== id));
        showToast('Pedido de peça removido.', 'success');
      } catch (err) {
        handleError(err, 'Erro ao remover pedido de peça.');
      } finally {
        setIsSubmitting(false);
      }
    },
    [handleError, showToast]
  );

  const registrarVenda = useCallback(
    async (input: RegistrarVendaInput): Promise<VendaDto | null> => {
      setIsSubmitting(true);
      try {
        const saved = await api.registrarVenda(input);
        setVendas((prev) => [saved, ...prev]);

        const [freshPecas, freshTx] = await Promise.allSettled([
          api.fetchPecas(),
          canAccessFinanceiro ? api.fetchTransacoes() : Promise.resolve(null)
        ]);
        if (freshPecas.status === 'fulfilled') {
          setPecas(freshPecas.value);
        }
        if (canAccessFinanceiro && freshTx.status === 'fulfilled' && freshTx.value) {
          setTransacoes(freshTx.value);
        }

        showToast(
          `Venda #${saved.numero_venda} concluída! Estoque atualizado e lançado no Financeiro.`,
          'success'
        );
        return saved;
      } catch (err) {
        handleError(err, 'Erro ao registrar venda.');
        return null;
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const cancelarVenda = useCallback(
    async (id: string): Promise<boolean> => {
      setIsSubmitting(true);
      try {
        const updated = await api.cancelarVenda(id);
        setVendas((prev) => prev.map((v) => (v.id === updated.id ? updated : v)));

        const [freshPecas, freshTx] = await Promise.allSettled([
          api.fetchPecas(),
          canAccessFinanceiro ? api.fetchTransacoes() : Promise.resolve(null)
        ]);
        if (freshPecas.status === 'fulfilled') {
          setPecas(freshPecas.value);
        }
        if (canAccessFinanceiro && freshTx.status === 'fulfilled' && freshTx.value) {
          setTransacoes(freshTx.value);
        }

        showToast(
          `Venda #${updated.numero_venda} cancelada e itens estornados ao estoque.`,
          'info'
        );
        return true;
      } catch (err) {
        handleError(err, 'Erro ao cancelar venda.');
        return false;
      } finally {
        setIsSubmitting(false);
      }
    },
    [canAccessFinanceiro, handleError, showToast]
  );

  const value: WorkshopContextValue = {
    session,
    authChecking,
    authLoading,
    authError,
    authInfo,
    isLoading,
    isSubmitting,
    currentRoute,
    setCurrentRoute,
    osViewMode,
    setOsViewMode,
    compressionPreset,
    setCompressionPreset,
    toast,
    showToast,
    clearToast,
    clearAuthFeedback,
    clientes,
    ordens,
    pecas,
    transacoes,
    configuracaoOficina,
    metaDiaria,
    cotacoes,
    funcionarios,
    pedidosPecas,
    vendas,
    isAdmin,
    canAccessFinanceiro,
    alerts,
    osAbertasCount,
    osProntasCount,
    pecasEstoqueBaixo,
    faturamentoLojaRecebido,
    despesasLojaPagas,
    saldoLoja,
    aReceberPendenteLoja,
    aPagarPendenteLoja,
    gastosPessoaisPagos,
    gastosPessoaisPendentes,
    ticketMedioRealOs,
    nextNumeroOs,
    totalVendasHoje,
    totalVendasMes,
    financeContasFixasTabRequested,
    financeOverdue30dFilterRequested,
    osOverdue30dFilterRequested,
    requestFinanceContasFixasTab,
    requestFinanceOverdue30dFilter,
    clearFinanceNavRequests,
    requestOsOverdue30dFilter,
    clearOsNavRequests,
    signIn,
    signUpOwner,
    signUpEmployee,
    signOut,
    refreshAll,
    saveCliente,
    deleteCliente,
    saveOrdemServico,
    updateOsStatus,
    deleteOrdemServico,
    lancarOsNoFinanceiro,
    savePeca,
    adjustPecaQuantity,
    deletePeca,
    saveTransacao,
    toggleTransacaoStatus,
    deleteTransacao,
    saveConfiguracaoOficina,
    createFuncionario,
    updateFuncionarioPerfil,
    toggleFuncionarioAtivo,
    deleteFuncionario,
    saveMetaDiaria,
    saveCotacao,
    deleteCotacao,
    savePedidoPeca,
    updatePedidoPecaStatus,
    deletePedidoPeca,
    registrarVenda,
    cancelarVenda
  };

  return <WorkshopContext.Provider value={value}>{children}</WorkshopContext.Provider>;
}

export function useWorkshop(): WorkshopContextValue {
  const ctx = useContext(WorkshopContext);
  if (!ctx) {
    throw new Error('useWorkshop deve ser usado dentro de WorkshopProvider.');
  }
  return ctx;
}
